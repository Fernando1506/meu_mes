/*
  ═══════════════════════════════════════════════════════
  10-MODALS.JS
  ═══════════════════════════════════════════════════════
  Templates de modais/formulários usados pelo App.openModal().

  PADRÃO DO PROJETO:
  - Os dados principais ficam em Store.data.
  - Calc concentra regras de negócio e cálculos.
  - Screens monta HTML das telas.
  - Modals monta HTML dos formulários.
  - App coordena navegação, eventos e ações do usuário.

  DICA:
  Procure por 'AJUSTE AQUI' para encontrar pontos comuns de alteração.
*/

// ═══════════════════════════════════════════════════════
      // MODALS
      // ═══════════════════════════════════════════════════════
      /* Modals: templates HTML dos formulários e painéis abertos em modal. */
      var Modals = {
        gasto() {
          return `<div class="sheet-handle"></div>
        <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:24px;">Registrar Gasto</div>
        <div class="form-group"><label class="label">Descrição</label><input id="m-desc" class="form-input" placeholder="Ex: Mercado, Aluguel, Netflix..."></div>
        <div class="form-group"><label class="label">Valor</label><div class="input-money"><span>R$</span><input id="m-valor" class="form-input" type="number" step="0.01" placeholder="0,00"></div></div>
        <input id="m-cat" type="hidden" value="V">
        <div class="grid-2"><div class="form-group"><label class="label">Data</label><input id="m-data" class="form-input" type="date" value="${new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().split("T")[0]}"></div><div class="form-group"><label class="label">Tipo de lançamento</label><select id="m-repete" class="form-select" onchange="App.toggleRecorrenciaFields(this.value)"><option value="avulso">Somente este mês</option><option value="mensal">Repetir por meses</option><option value="parcelado_fixo">Parcelado (N vezes)</option></select></div></div>
        <div class="grid-2 hidden" id="m-repeticao-meses-wrap"><div class="form-group"><label class="label">Quantidade de meses</label><input id="m-repetir-meses" class="form-input" type="number" min="1" value="12"></div><div></div></div>
        <div class="grid-2 hidden" id="m-parcelas-wrap"><div class="form-group"><label class="label">Número de parcelas</label><input id="m-num-parcelas" class="form-input" type="number" min="2" max="120" value="12" placeholder="Ex: 12"></div><div class="form-group"><label class="label" style="opacity:0;">—</label><div class="box box-light" style="padding:10px 12px;font-size:12px;color:var(--grey);line-height:1.5;">Aparecerá como<br><strong style="color:var(--navy);">1/12, 2/12...</strong> em cada mês</div></div></div>
        // Salva um gasto/conta no ciclo ativo.
        <button class="btn btn-primary btn-full btn-lg" onclick="App.saveGasto()">Salvar Gasto</button>`;
        },
        renda() {
          const key = App.getActiveCycleKey
            // Retorna o ciclo financeiro atualmente selecionado.
            ? App.getActiveCycleKey()
            : Calc.cicloAtual();
          const mes = Calc.getCiclo(key);
          const entradas = Calc.entradasNoMes(mes);
          const recs = Store.get("recebimentos") || [];
          const mesLabel = FarolHelpers.monthLabelByKey
            ? FarolHelpers.monthLabelByKey(key)
            : key;
          const isFuturo = key !== Calc.cicloAtual();
          return `<div class="sheet-handle"></div>
        <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:${isFuturo ? "6px" : "24px"};">Registrar Entrada</div>
        ${isFuturo ? `<div style="font-size:12px;color:var(--teal-d);font-weight:700;background:var(--teal-lt);border-radius:8px;padding:6px 12px;margin-bottom:18px;display:inline-block;">Lançando em ${mesLabel}</div>` : ""}
        <div class="form-group"><label class="label">Origem da renda</label><select id="m-renda-origem" class="form-select" onchange="App.toggleRendaOrigem(this.value)">${recs
          .filter((r) => r.tipo !== "extra")
          .map(
            (r) =>
              `<option value="${r.nome}">${r.nome}${r.dia ? ` · dia ${r.dia}` : ""}</option>`,
          )
          .join(
            "",
          )}<option value="Renda extra">Renda extra</option><option value="_novo_">+ Digitar outra origem...</option></select><input id="m-renda-origem-custom" class="form-input mt-8 hidden" placeholder="Nome da origem (ex: Freelance, Bônus...)"></div>
        <div class="form-group"><label class="label">Valor recebido</label><div class="input-money"><span>R$</span><input id="m-renda-valor" class="form-input" type="number" step="0.01" placeholder="0,00" oninput="App.updateRendaSeparationSummary()"></div></div>
        <div class="form-group"><label class="label">Data</label><input id="m-renda-data" class="form-input" type="date" value="${new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().split("T")[0]}"></div>
        <div class="card-soft mb-16">
          <div class="flex justify-between items-center mb-12" style="gap:12px;flex-wrap:wrap;"><div><div style="font-size:14px;font-weight:800;color:var(--navy);">Separações desta entrada</div><div class="text-xs text-grey mt-4">Use para valores que você separa antes de organizar o mês.</div></div><button class="btn btn-ghost btn-sm" type="button" onclick="App.addSeparacaoRow()">+ Adicionar separação</button></div>
          <div id="m-sep-list"></div>
          <div class="grid-2 mt-12"><div class="card-sm"><div class="text-xs text-grey mb-4">Total separado</div><div id="m-renda-sep-total" style="font-weight:800;color:var(--amber);">${Calc.fmt(0)}</div></div><div class="card-sm"><div class="text-xs text-grey mb-4">Base após separação</div><div id="m-renda-base" style="font-weight:800;color:var(--green);">${Calc.fmt(0)}</div></div></div>
        </div>
        <button class="btn btn-primary btn-full btn-lg" onclick="App.saveRenda()">Adicionar entrada</button>
        ${
          entradas.length
            ? `<div class="card mt-20"><div style="font-size:14px;font-weight:700;margin-bottom:12px;">Entradas já lançadas</div>${entradas
                .map(
                  (e, i) =>
                    `<div class="gasto-row"><div><div class="gasto-desc">${FarolHelpers.escapeHtml(e.origem || "Entrada")}</div><div class="gasto-date">${FarolHelpers.formatDate(e.data)}${e.totalSeparado > 0 ? ` · separado ${Calc.fmt(e.totalSeparado)} · base ${Calc.fmt(e.baseAposSeparacao)}` : ""}</div></div><span class="chip chip-f">R</span><div class="gasto-valor">${Calc.fmt(e.valor)}</div><button class="gasto-delete" onclick="App.deleteEntrada('${key}',${i})">×</button></div>${
                      e.totalSeparado > 0
                        ? `<div class="box box-light" style="margin:8px 0 12px 0;padding:12px 14px;">${e.separacoes
                            .map((s) => {
                              const bruto = parseFloat(e.valor) || 0;
                              const raw = parseFloat(s.valor || 0) || 0;
                              const val =
                                s.tipo === "percentual"
                                  ? bruto * (raw / 100)
                                  : raw;
                              return `<div class="text-xs text-grey" style="margin-bottom:4px;"><strong style="color:var(--navy);">${FarolHelpers.escapeHtml(s.nome || "Separação")}</strong> · ${s.tipo === "percentual" ? raw + "%" : Calc.fmt(raw)} · ${Calc.fmt(val)}</div>`;
                            })
                            .join("")}</div>`
                        : ""
                    }`,
                )
                .join("")}</div>`
            : ""
        }`;
        },
        objetivo() {
          return `<div class="sheet-handle"></div>
        <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:24px;">Novo Objetivo</div>
        <div class="form-group"><label class="label">Nome do objetivo</label><input id="m-obj-nome" class="form-input" placeholder="Ex: Quitar cartão, Cofrinho de emergência, Viagem..."></div>
        <div class="form-group"><label class="label">Valor da meta</label><div class="input-money"><span>R$</span><input id="m-obj-valor" class="form-input" type="number" step="0.01" placeholder="0,00"></div></div>
        <div class="grid-2">
          <div class="form-group"><label class="label">Já acumulado</label><div class="input-money"><span>R$</span><input id="m-obj-pago" class="form-input" type="number" step="0.01" placeholder="0,00"></div></div>
          <div class="form-group"><label class="label">Prazo</label><input id="m-obj-prazo" class="form-input" type="month"></div>
        </div>
        <div class="form-group"><label class="label">Prioridade</label><select id="m-obj-prio" class="form-select"><option value="alta">Alta</option><option value="media" selected>Média</option><option value="baixa">Baixa</option></select></div>
        <button class="btn btn-primary btn-full btn-lg" onclick="App.saveObjetivo()">Salvar Objetivo</button>`;
        },
        parcela() {
          const cartoes = Store.get("cartoes") || [];
          return `<div class="sheet-handle"></div>
        <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:24px;">Nova Parcela / Dívida</div>
        <div class="form-group"><label class="label">Nome</label><input id="m-p-nome" class="form-input" placeholder="Ex: Financiamento do carro, Notebook..."></div>
        <div class="grid-2"><div class="form-group"><label class="label">Subcategoria</label><input id="m-p-sub" class="form-input" placeholder="Ex: Financiamento"></div><div class="form-group"><label class="label">Dia do vencimento</label><input id="m-p-dia" class="form-input" type="number" min="1" max="28" placeholder="Ex: 15"></div></div>
        <div class="form-group"><label class="label">Valor mensal</label><div class="input-money"><span>R$</span><input id="m-p-valor" class="form-input" type="number" step="0.01" placeholder="0,00"></div></div>
        <div class="grid-2"><div class="form-group"><label class="label">Data de início</label><input id="m-p-inicio" class="form-input" type="month"></div><div class="form-group"><label class="label">Data de término</label><input id="m-p-fim" class="form-input" type="month"></div></div>
        <div class="form-group">
          <label class="label">Como essa parcela é paga?</label>
          <select id="m-p-origem" class="form-select" onchange="App.toggleParcelaCartaoField(this.value)">
            <option value="separado">Boleto, débito ou pagamento separado</option>
            <option value="cartao">No cartão de crédito</option>
          </select>
        </div>
        <div class="form-group hidden" id="m-p-cartao-wrap">
          <label class="label">Qual cartão?</label>
          <select id="m-p-cartao" class="form-select">
            ${cartoes.length === 0 ? `<option value="">Nenhum cartão cadastrado</option>` : cartoes.map((c) => `<option value="${c.id}">${FarolHelpers.escapeHtml(c.nome)}</option>`).join("")}
          </select>
          <div class="text-xs text-grey mt-8">Essa parcela já está incluída no valor da fatura que você atualiza. Ela não será somada de novo no total do mês — fica aqui só para acompanhar quando termina.</div>
        </div>
        <div class="card-gold mb-16"><span class="eyebrow">exemplo</span><p class="body-text" style="margin:0;font-size:13px;">Começou em janeiro e termina em julho → o sistema calculará automaticamente a parcela atual e o valor restante.</p></div>
        <button class="btn btn-primary btn-full btn-lg" onclick="App.saveParcela()">Salvar Parcela</button>`;
        },
        recebimento() {
          return `<div class="sheet-handle"></div>
        <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:24px;">Novo Recebimento</div>
        <div class="form-group"><label class="label">Nome</label><input id="m-r-nome" class="form-input" placeholder="Ex: Salário, Freelance, Aluguel recebido..."></div>
        <div class="form-group"><label class="label">Tipo</label><select id="m-r-tipo" class="form-select" onchange="App.toggleRecType(this.value)"><option value="fixo">Fixo mensal</option><option value="extra">Renda extra</option></select></div>
        <div class="grid-2" id="m-r-grid-fixo"><div class="form-group"><label class="label">Dia do recebimento</label><input id="m-r-dia" class="form-input" type="number" min="1" max="31" placeholder="Ex: 5"></div><div class="form-group"><label class="label">Valor estimado</label><div class="input-money"><span>R$</span><input id="m-r-valor" class="form-input" type="number" step="0.01" placeholder="0,00"></div></div></div>
        <button class="btn btn-primary btn-full btn-lg" onclick="App.saveRecebimento()">Salvar</button>`;
        },

        cartao(arg) {
          const cartoes = Store.get("cartoes") || [];
          const idx = typeof arg === "number" ? arg : null;
          const c = idx !== null ? cartoes[idx] : null;
          const hoje = new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
            .toISOString()
            .split("T")[0];
          const dataPadraoPorDia = (dia) => {
            const d = Math.min(Math.max(parseInt(dia, 10) || 1, 1), 28);
            const base = new Date();
            return `${base.getFullYear()}-${String(base.getMonth() + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
          };
          const vencimentoValue = c
            ? c.dataVencimento || dataPadraoPorDia(c.diaVencimento)
            : hoje;
          return `<div class="sheet-handle"></div>
        <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:24px;">${c ? "Editar cartão" : "Novo cartão"}</div>
        <input type="hidden" id="m-cart-idx" value="${idx !== null ? idx : ""}">
        <div class="form-group"><label class="label">Nome do cartão (opcional)</label><input id="m-cart-nome" class="form-input" placeholder="Ex: Cartão Nubank, Cartão Inter..." value="${c ? FarolHelpers.escapeHtml(c.nome) : ""}"></div>
        <div class="form-group"><label class="label">Valor atual da fatura</label><div class="input-money"><span>R$</span><input id="m-cart-inicial" class="form-input" type="number" step="0.01" placeholder="0,00" value="${c ? c.faturaAtual || "" : ""}"></div></div>
        <div class="form-group"><label class="label">Vencimento da fatura</label><input id="m-cart-vencimento" class="form-input" type="date" value="${vencimentoValue}"></div>
        <div class="card-gold mb-16"><span class="eyebrow">como funciona</span><p class="body-text" style="margin:0;font-size:13px;">O cartão entra só como impacto no seu dinheiro disponível. Sem limite, sem fechamento, sem controlar cada compra.</p></div>
        <button class="btn btn-primary btn-full btn-lg" onclick="App.saveCartao()">${c ? "Salvar alterações" : "Adicionar cartão"}</button>`;
        },

        faturaUpdate(idx) {
          const cartoes = Store.get("cartoes") || [];
          const c = cartoes[idx];
          if (!c) return "";
          return `<div class="sheet-handle"></div>
        <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:4px;">Atualizar fatura</div>
        <div class="text-sm text-grey mb-20">${FarolHelpers.escapeHtml(c.nome)}</div>
        <input type="hidden" id="m-fat-idx" value="${idx}">
        <div class="card-soft mb-16 text-center">
          <div class="text-xs text-grey mb-4">Valor atual da fatura</div>
          <div style="font-size:26px;font-weight:800;color:var(--navy);">${Calc.fmt(c.faturaAtual || 0)}</div>
        </div>
        <div class="form-group"><label class="label">Novo valor total da fatura</label><div class="input-money"><span>R$</span><input id="m-fat-valor" class="form-input" type="number" step="0.01" placeholder="0,00" value="${c.faturaAtual || 0}"></div></div>
        <p class="text-xs text-grey mb-16">Informe o <strong>total acumulado</strong> até agora, não apenas o que gastou hoje. Ex: se já estava R$ 400 e gastou mais R$ 700 nesta semana, informe R$ 1.100.</p>
        <button class="btn btn-primary btn-full btn-lg" onclick="App.saveFaturaUpdate()">Atualizar valor</button>`;
        },

        faturaVencimento(idx) {
          const cartoes = Store.get("cartoes") || [];
          const c = cartoes[idx];
          if (!c) return "";
          const st = FarolHelpers.cartaoStatus(c);
          // Data pré-preenchida: próximo vencimento calculado
          const proxVencDate = st.proxVencimento;
          const proxVencISO = proxVencDate
            ? `${proxVencDate.getFullYear()}-${String(proxVencDate.getMonth() + 1).padStart(2, "0")}-${String(proxVencDate.getDate()).padStart(2, "0")}`
            : "";
          const jaLancado = c.faturaVencimento && c.faturaVencimento.data;
          const dataAtual = jaLancado ? c.faturaVencimento.data : proxVencISO;
          const valorAtual = jaLancado
            ? parseFloat(c.faturaVencimento.valor) || 0
            : 0;
          return `<div class="sheet-handle"></div>
        <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:4px;">Lançar fatura no vencimento</div>
        <div class="text-sm text-grey mb-20">${FarolHelpers.escapeHtml(c.nome)}</div>
        <input type="hidden" id="m-prev-idx" value="${idx}">
        <div class="form-group"><label class="label">Data do vencimento</label><input id="m-prev-data" class="form-input" type="date" value="${dataAtual}"></div>
        <div class="form-group"><label class="label">Valor da fatura</label><div class="input-money"><span>R$</span><input id="m-prev-valor" class="form-input" type="number" step="0.01" placeholder="0,00" value="${valorAtual > 0 ? valorAtual : ""}"></div></div>
        <p class="text-xs text-grey mb-16">Vai aparecer no mês da data escolhida igual aos outros lançamentos — com badge <strong>previsto</strong> para identificar.</p>
        ${jaLancado ? `<button class="btn btn-ghost btn-full mb-8" onclick="App.clearFaturaVencimento(${idx})">Remover lançamento</button>` : ""}
        <button class="btn btn-primary btn-full btn-lg" onclick="App.saveFaturaVencimento()">Salvar</button>`;
        },

        editarEntradaPrevista(arg) {
          // arg = { key, idx, origem, valor, data }
          if (!arg) return "";
          return `<div class="sheet-handle"></div>
        <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:6px;">Editar entrada prevista</div>
        <div style="font-size:13px;color:var(--grey);margin-bottom:20px;">${FarolHelpers.escapeHtml(arg.origem || "Entrada")} · ${FarolHelpers.monthLabelByKey ? FarolHelpers.monthLabelByKey(arg.key) : arg.key}</div>
        <input type="hidden" id="m-eprev-key" value="${arg.key}">
        <input type="hidden" id="m-eprev-idx" value="${arg.idx}">
        <div class="form-group">
          <label class="label">Valor previsto</label>
          <div class="input-money"><span>R$</span><input id="m-eprev-valor" class="form-input" type="number" step="0.01" value="${parseFloat(arg.valor) || ""}"></div>
        </div>
        <div class="form-group">
          <label class="label">Data</label>
          <input id="m-eprev-data" class="form-input" type="date" value="${arg.data || ""}">
        </div>
        <div style="display:grid;gap:10px;margin-top:4px;">
          <button class="btn btn-primary btn-full btn-lg" onclick="App.salvarEntradaPrevista('somente')">Alterar só este mês</button>
          <button class="btn btn-ghost btn-full" onclick="App.salvarEntradaPrevista('seguintes')">Alterar este e os seguintes</button>
        </div>`;
        },

        separar() {
          const tipos = App.getSeparacaoSuggestions();
          return `<div class="sheet-handle"></div>
        <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:4px;">Separar valor</div>
        <p class="text-sm text-grey mb-20">Guarde uma parte do que sobrou para cofrinho, investimento, objetivo financeiro ou poupança. Esse valor sai do disponível para gastar, mas continua sendo seu patrimônio.</p>
        <div class="form-group">
          <label class="label">Tipo de separação</label>
          <select id="m-csep-select" class="form-select" onchange="App.toggleSepNomeCustomEl(this,'m-csep-custom')">
            <option value="">Selecione…</option>
            ${tipos.map((t) => `<option value="${FarolHelpers.escapeHtml(t)}">${FarolHelpers.escapeHtml(t)}</option>`).join("")}
            <option value="_outro_">Outro…</option>
          </select>
          <input id="m-csep-custom" class="form-input mt-8 hidden" placeholder="Nome do tipo">
        </div>
        <div class="form-group"><label class="label">Valor</label><div class="input-money"><span>R$</span><input id="m-csep-valor" class="form-input" type="number" step="0.01" placeholder="0,00"></div></div>
        <div class="grid-2"><div class="form-group"><label class="label">Data</label><input id="m-csep-data" class="form-input" type="date" value="${new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().split("T")[0]}"></div><div></div></div>
        <button class="btn btn-gold btn-full btn-lg" onclick="App.saveSeparacaoMes()">Separar valor</button>`;
        },
      };

/* MVP: sobrescreve o formulário de gasto para ser ultrarrápido. */
Modals.gasto = function () {
  return `<div class="sheet-handle"></div>
    <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:18px;">Registrar gasto</div>
    <p class="text-sm text-grey mb-16">Preencha só o essencial. Categoria não é obrigatória.</p>
    <div class="form-group"><label class="label">Valor</label><div class="input-money"><span>R$</span><input id="m-valor" class="form-input" type="number" step="0.01" placeholder="0,00" autofocus></div></div>
    <div class="form-group"><label class="label">Descrição <span style="font-weight:400;color:var(--grey);">(opcional)</span></label><input id="m-desc" class="form-input" placeholder="Ex: mercado, gasolina, farmácia"></div>
    <input id="m-cat" type="hidden" value="V">
    <input id="m-data" type="hidden" value="${new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().split("T")[0]}">
    <input id="m-repete" type="hidden" value="avulso">
    <button class="btn btn-primary btn-full btn-lg" onclick="App.saveGasto()">Salvar gasto</button>
    <div class="text-xs text-grey mt-12" style="text-align:center;">Aluguel, internet ou outra conta que se repete todo mês? <a href="#" onclick="event.preventDefault();App.closeModal();App.openModal('compromisso');" style="color:var(--teal-d);font-weight:600;">Cadastre como compromisso fixo</a>.</div>`;
};

/* MVP: modal dedicado para Compromissos Fixos — nome, valor, dia de vencimento
   e prazo opcional. Por padrão o compromisso não tem fim (recorrente todo mês),
   já que esse é o comportamento esperado para aluguel, internet, escola etc. */
Modals.compromisso = function (arg) {
  const fixos = Store.get("gastosFixos") || [];
  const idx = typeof arg === "number" ? arg : null;
  const c = idx !== null ? fixos[idx] : null;
  const hoje = new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
    .toISOString()
    .split("T")[0];
  const temPrazo = !!(c && c.endKey);
  return `<div class="sheet-handle"></div>
    <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:18px;">${c ? "Editar compromisso" : "Novo compromisso fixo"}</div>
    <p class="text-sm text-grey mb-16">Aluguel, internet, escola, financiamento, assinaturas. Cadastre uma vez — o app desconta todo mês automaticamente.</p>
    <input type="hidden" id="m-comp-idx" value="${idx !== null ? idx : ""}">
    <div class="form-group"><label class="label">Nome</label><input id="m-comp-nome" class="form-input" placeholder="Ex: Aluguel, Internet, Escola..." value="${c ? FarolHelpers.escapeHtml(c.descricao) : ""}" autofocus></div>
    <div class="form-group"><label class="label">Valor</label><div class="input-money"><span>R$</span><input id="m-comp-valor" class="form-input" type="number" step="0.01" placeholder="0,00" value="${c ? c.valor : ""}"></div></div>
    <div class="form-group"><label class="label">Dia do vencimento</label><input id="m-comp-dia" class="form-input" type="number" min="1" max="28" placeholder="Ex: 10" value="${c ? c.diaVencimento || "" : ""}"></div>
    <div class="form-group">
      <label class="check-label" style="display:flex;align-items:center;gap:8px;cursor:pointer;">
        <input type="checkbox" id="m-comp-tem-prazo" ${temPrazo ? "checked" : ""} onchange="document.getElementById('m-comp-prazo-wrap').classList.toggle('hidden', !this.checked)">
        <span class="text-sm">Esse compromisso tem data para acabar (ex: financiamento)</span>
      </label>
    </div>
    <div id="m-comp-prazo-wrap" class="form-group ${temPrazo ? "" : "hidden"}">
      <label class="label">Vai até qual mês?</label>
      <input id="m-comp-prazo" class="form-input" type="month" value="${c && c.endKey ? `${c.endKey.split("-")[0]}-${String(Number(c.endKey.split("-")[1]) + 1).padStart(2, "0")}` : ""}">
      <div class="text-xs text-grey mt-4">Sem essa opção marcada, o compromisso continua todo mês sem precisar recadastrar.</div>
    </div>
    <button class="btn btn-primary btn-full btn-lg" onclick="App.saveCompromisso()">${c ? "Salvar alterações" : "Cadastrar compromisso"}</button>`;
};



/* V14 — modais de previsão, edição e ações do extrato */
(function(){
  const hojeISO = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().split('T')[0];
  const esc = (s) => (window.FarolHelpers && FarolHelpers.escapeHtml ? FarolHelpers.escapeHtml(s || '') : String(s || '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])));

  Modals.gasto = function(arg){
    const edit = arg && arg.kind === 'gasto';
    const g = edit ? (arg.item || {}) : {};
    return `<div class="sheet-handle"></div>
      <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:18px;">${edit ? 'Editar gasto' : 'Registrar gasto'}</div>
      <input type="hidden" id="m-edit-kind" value="${edit ? 'gasto' : ''}">
      <input type="hidden" id="m-edit-key" value="${edit ? arg.key : ''}">
      <input type="hidden" id="m-edit-idx" value="${edit ? arg.idx : ''}">
      <div class="form-group"><label class="label">Valor</label><div class="input-money"><span>R$</span><input id="m-valor" class="form-input" type="number" step="0.01" placeholder="0,00" value="${g.valor || ''}" autofocus></div></div>
      <div class="form-group"><label class="label">Descrição</label><input id="m-desc" class="form-input" placeholder="Ex: mercado, gasolina, IPTU" value="${esc(g.descricao || g.desc || '')}"></div>
      <div class="grid-2"><div class="form-group"><label class="label">Data / vencimento</label><input id="m-data" class="form-input" type="date" value="${g.data || hojeISO()}"></div><div class="form-group"><label class="label">Já foi pago?</label><select id="m-gasto-status" class="form-select"><option value="pendente" ${(['pendente','previsto'].includes(g.status || '') || (!g.status && !g.pago)) ? 'selected' : ''}>Não, está a pagar</option><option value="pago" ${(g.status === 'pago' || g.pago) ? 'selected' : ''}>Sim, já paguei</option><option value="cancelado" ${g.status === 'cancelado' ? 'selected' : ''}>Cancelar este gasto</option></select></div></div>
      <div class="card-soft mb-16"><div class="text-xs text-grey">Use <strong>Não, está a pagar</strong> para contas que você lança antes de pagar. Quando pagar, edite ou toque em <strong>Pagar</strong> no extrato.</div></div>
      <input id="m-cat" type="hidden" value="${g.categoria || 'V'}">
      <input id="m-repete" type="hidden" value="avulso">
      <button class="btn btn-primary btn-full btn-lg" onclick="${edit ? 'App.updateGasto()' : 'App.saveGasto()'}">${edit ? 'Salvar alterações' : 'Salvar gasto'}</button>
      ${edit ? '<button class="btn btn-ghost btn-full mt-8" onclick="App.closeModal()">Cancelar</button>' : '<div class="text-xs text-grey mt-12" style="text-align:center;">Conta que se repete? <a href="#" onclick="event.preventDefault();App.closeModal();App.openModal(\'compromisso\');" style="color:var(--teal-d);font-weight:600;">Cadastre como compromisso fixo</a>.</div>'}`;
  };

  Modals.renda = function(arg){
    const edit = arg && arg.kind === 'entrada';
    const e = edit ? (arg.item || {}) : {};
    const key = edit ? arg.key : (App.getActiveCycleKey ? App.getActiveCycleKey() : Calc.cicloAtual());
    const recs = Store.get('recebimentos') || [];
    const mesLabel = FarolHelpers.monthLabelByKey ? FarolHelpers.monthLabelByKey(key) : key;
    const origem = e.origem || '';
    const exists = origem && recs.some(r => r.nome === origem);
    return `<div class="sheet-handle"></div>
      <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:6px;">${edit ? 'Editar entrada' : 'Registrar entrada'}</div>
      <div style="font-size:12px;color:var(--teal-d);font-weight:700;background:var(--teal-lt);border-radius:8px;padding:6px 12px;margin-bottom:18px;display:inline-block;">${mesLabel}</div>
      <input type="hidden" id="m-edit-kind" value="${edit ? 'entrada' : ''}">
      <input type="hidden" id="m-edit-key" value="${edit ? arg.key : ''}">
      <input type="hidden" id="m-edit-idx" value="${edit ? arg.idx : ''}">
      <div class="form-group"><label class="label">Origem</label><select id="m-renda-origem" class="form-select" onchange="App.toggleRendaOrigem(this.value)">
        ${recs.filter(r=>r.tipo!=='extra').map(r=>`<option value="${esc(r.nome)}" ${r.nome===origem?'selected':''}>${esc(r.nome)}${r.dia ? ' · dia '+r.dia : ''}</option>`).join('')}
        <option value="Renda extra" ${origem==='Renda extra'?'selected':''}>Renda extra</option><option value="_novo_" ${(!exists && origem && origem!=='Renda extra')?'selected':''}>+ Digitar outra origem...</option></select>
        <input id="m-renda-origem-custom" class="form-input mt-8 ${(!exists && origem && origem!=='Renda extra')?'':'hidden'}" placeholder="Nome da origem" value="${(!exists && origem && origem!=='Renda extra') ? esc(origem) : ''}"></div>
      <div class="form-group"><label class="label">Valor</label><div class="input-money"><span>R$</span><input id="m-renda-valor" class="form-input" type="number" step="0.01" placeholder="0,00" value="${e.valor || ''}" oninput="App.updateRendaSeparationSummary()"></div></div>
      <div class="grid-2"><div class="form-group"><label class="label">Data</label><input id="m-renda-data" class="form-input" type="date" value="${e.data || hojeISO()}"></div><div class="form-group"><label class="label">Status</label><select id="m-renda-status" class="form-select"><option value="previsto" ${(e.status || 'previsto')==='previsto'?'selected':''}>Previsto</option><option value="confirmado" ${(e.status || '')==='confirmado'?'selected':''}>Confirmado</option><option value="cancelado" ${(e.status || '')==='cancelado'?'selected':''}>Cancelado</option></select></div></div>
      <div class="card-soft mb-16">
        <div style="font-size:14px;font-weight:800;color:var(--navy);margin-bottom:6px;">Separar dinheiro desta entrada</div>
        <div class="text-xs text-grey mb-12">Use para pagar-se primeiro: cofrinho, investimento, poupança ou outra separação. Objetivos ficam separados do total do cofrinho.</div>
        <div id="m-sep-list"></div>
        <button type="button" class="btn btn-ghost btn-full" onclick="App.addSeparacaoRow()">+ Adicionar separação</button>
        <div class="grid-2 mt-12"><div class="card-sm"><div class="text-xs text-grey mb-4">Total separado</div><div id="m-renda-sep-total" style="font-weight:800;color:var(--amber);">${Calc.fmt(0)}</div></div><div class="card-sm"><div class="text-xs text-grey mb-4">Base após separação</div><div id="m-renda-base" style="font-weight:800;color:var(--green);">${Calc.fmt(e.valor || 0)}</div></div></div>
      </div>
      <div class="card-soft mb-16"><div class="text-xs text-grey">Use <strong>Previsto</strong> para planejar o mês seguinte. Quando cair na conta, edite o valor real e mude para <strong>Confirmado</strong>.</div></div>
      <button class="btn btn-primary btn-full btn-lg" onclick="${edit ? 'App.updateEntrada()' : 'App.saveRenda()'}">${edit ? 'Salvar alterações' : 'Adicionar entrada'}</button>`;
  };

  Modals.recebimento = function(arg){
    const recs = Store.get('recebimentos') || [];
    const idx = typeof arg === 'number' ? arg : null;
    const r = idx !== null ? recs[idx] : null;
    return `<div class="sheet-handle"></div>
      <div style="font-size:20px;font-weight:800;color:var(--navy);margin-bottom:18px;">${r ? 'Editar recebimento previsto' : 'Novo recebimento previsto'}</div>
      <input type="hidden" id="m-r-idx" value="${idx !== null ? idx : ''}">
      <div class="form-group"><label class="label">Origem</label><input id="m-r-nome" class="form-input" placeholder="Ex: Salário, Pró-labore" value="${r ? esc(r.nome) : ''}" autofocus></div>
      <div class="grid-2"><div class="form-group"><label class="label">Valor previsto</label><div class="input-money"><span>R$</span><input id="m-r-valor" class="form-input" type="number" step="0.01" value="${r ? (r.valor || '') : ''}" placeholder="0,00"></div></div><div class="form-group"><label class="label">Dia</label><input id="m-r-dia" class="form-input" type="number" min="1" max="31" value="${r ? (r.dia || '') : ''}" placeholder="5"></div></div>
      <div class="grid-2"><div class="form-group"><label class="label">Tipo</label><select id="m-r-tipo" class="form-select"><option value="fixo" ${!r || r.tipo !== 'extra' ? 'selected' : ''}>Recorrente mensal</option><option value="extra" ${r && r.tipo === 'extra' ? 'selected' : ''}>Renda extra</option></select></div><div class="form-group"><label class="label">Status padrão</label><select id="m-r-status" class="form-select"><option value="previsto" ${!r || (r.status || 'previsto')==='previsto'?'selected':''}>Previsto</option><option value="confirmado" ${r && r.status==='confirmado'?'selected':''}>Confirmado</option><option value="cancelado" ${r && r.status==='cancelado'?'selected':''}>Cancelado</option></select></div></div>
      <button class="btn btn-primary btn-full btn-lg" onclick="App.saveRecebimento()">${r ? 'Salvar alterações' : 'Salvar recebimento'}</button>`;
  };
})();
