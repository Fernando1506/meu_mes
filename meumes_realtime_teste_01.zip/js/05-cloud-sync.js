/*
  ═══════════════════════════════════════════════════════
  05-CLOUD-SYNC.JS — REALTIME TESTE
  ═══════════════════════════════════════════════════════
  Primeira versão para o banco meumes-realtime.

  Mudança estrutural:
  - Remove dependência de workspaces/workspace_id.
  - Usa auth.uid() / user_id como isolamento principal.
  - Usa tabelas separadas: ciclos, entradas, gastos_fixos, lancamentos,
    separacoes, objetivos, cartoes, faturas.
  - Não faz delete-all automático em tabelas inteiras.
  - Store continua sendo cache de tela; Supabase passa a ser a fonte da verdade.
*/

(function () {
  const CloudSync = {
    status: "disconnected",
    session: null,
    _syncing: false,
    _cloudPushTimer: null,
    _realtimeChannel: null,
    _lastRealtimeAt: 0,
    ADMIN_EMAIL: "reis150619@gmail.com",

    isConfigured() { return !!supa; },
    isAdmin() { return this.session?.user?.email === this.ADMIN_EMAIL; },

    async getSession() {
      if (!supa) return null;
      const { data } = await supa.auth.getSession();
      this.session = data?.session || null;
      return this.session;
    },

    _uid() { return this.session?.user?.id || null; },

    _mesFromISO(iso) {
      if (!iso) return this._activeMes();
      const d = new Date(String(iso) + "T00:00:00");
      if (Number.isNaN(d.getTime())) return this._activeMes();
      return `${d.getFullYear()}-${d.getMonth()}`;
    },

    _dateFromMes(mes) {
      const [y, m0] = String(mes || this._activeMes()).split("-").map(Number);
      return `${y || new Date().getFullYear()}-${String((m0 || 0) + 1).padStart(2, "0")}-01`;
    },

    _activeMes() {
      if (window.App && App.getActiveCycleKey) return App.getActiveCycleKey();
      const d = new Date();
      return `${d.getFullYear()}-${d.getMonth()}`;
    },

    _normalizaValor(v) { return Number.parseFloat(v || 0) || 0; },

    _categoriaSep(nome, categoria) {
      if (categoria) return categoria;
      const n = String(nome || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
      if (n.includes("imposto") || n.includes("tributo") || n.includes("taxa")) return "imposto";
      if (n.includes("dizimo") || n.includes("devolucao")) return "devolucao";
      if (n.includes("oferta") || n.includes("doacao") || n.includes("ajuda")) return "destinacao";
      if (n.includes("objetivo") || n.includes("meta")) return "objetivo";
      return "cofrinho";
    },

    _gastoMeta(g) {
      const meta = {};
      ["templateId", "recorrencia", "startKey", "endKey", "parcelaNum", "totalParcelas", "repeatMonths", "subcategoria", "skipMonths", "pago_em"].forEach((k) => {
        if (g && g[k] !== undefined) meta[k] = g[k];
      });
      return meta;
    },

    _parseOrigemMeta(origem) {
      if (!origem || !String(origem).startsWith("__meta__")) return {};
      try { return JSON.parse(String(origem).slice(8)); } catch (_) { return {}; }
    },

    _gastoFixoDescricao(g) {
      return "__gf__" + JSON.stringify(g || {});
    },

    _parseGastoFixo(row) {
      if (row?.descricao && String(row.descricao).startsWith("__gf__")) {
        try {
          const parsed = JSON.parse(String(row.descricao).slice(6));
          return { ...parsed, id: row.id, db_id: row.id, valor: this._normalizaValor(row.valor) || this._normalizaValor(parsed.valor) };
        } catch (_) {}
      }
      return {
        id: row.id,
        db_id: row.id,
        descricao: row.descricao || "Compromisso",
        valor: this._normalizaValor(row.valor),
        categoria: row.categoria || "V",
        diaVencimento: row.vencimento || 1,
        recorrencia: "mensal",
        startKey: row.mes_referencia || this._activeMes(),
        endKey: null,
        skipMonths: [],
      };
    },

    async _ensureSession() {
      if (!supa) return false;
      if (!this.session) await this.getSession();
      return !!this.session?.user?.id;
    },

    async _upsertCiclo(mes) {
      const uid = this._uid();
      if (!uid || !mes) return null;
      const { data, error } = await supa
        .from("ciclos")
        .select("id")
        .eq("user_id", uid)
        .eq("mes_referencia", mes)
        .is("deleted_at", null)
        .maybeSingle();
      if (error) throw error;
      if (data?.id) return data.id;
      const { data: created, error: createError } = await supa
        .from("ciclos")
        .insert({ user_id: uid, mes_referencia: mes, nome: mes })
        .select("id")
        .single();
      if (createError) throw createError;
      return created?.id || null;
    },

    async upsertEntrada(mes, fonte) {
      if (!(await this._ensureSession()) || !fonte) return null;
      const uid = this._uid();
      const payload = {
        user_id: uid,
        mes_referencia: mes || this._mesFromISO(fonte.data),
        descricao: fonte.origem || fonte.descricao || "Entrada",
        origem: fonte.origem || "Entrada",
        valor: this._normalizaValor(fonte.valor),
        data_prevista: fonte.status === "previsto" ? (fonte.data || this._dateFromMes(mes)) : null,
        data_recebimento: fonte.status === "confirmado" || fonte.status === "recebido" ? (fonte.data || this._dateFromMes(mes)) : (fonte.data || null),
        status: fonte.status || "previsto",
        updated_at: new Date().toISOString(),
      };
      let row;
      const dbId = fonte.db_id || fonte.id_banco || fonte.entrada_id;
      if (dbId && /^[0-9a-f-]{20,}$/i.test(String(dbId))) {
        const { data, error } = await supa.from("entradas").update(payload).eq("id", dbId).eq("user_id", uid).select("id").single();
        if (error) throw error;
        row = data;
      } else {
        const { data, error } = await supa.from("entradas").insert(payload).select("id").single();
        if (error) throw error;
        row = data;
        fonte.db_id = row.id;
      }

      if (row?.id) {
        await supa.from("separacoes").delete().eq("entrada_id", row.id).eq("user_id", uid);
        const seps = Array.isArray(fonte.separacoes) ? fonte.separacoes.filter((s) => s && s.nome && this._normalizaValor(s.valor) > 0) : [];
        if (seps.length) {
          const { error } = await supa.from("separacoes").insert(seps.map((s) => ({
            user_id: uid,
            mes_referencia: payload.mes_referencia,
            entrada_id: row.id,
            tipo: s.tipo || "valor",
            objetivo: s.nome || "Separação",
            percentual: s.tipo === "percentual" ? this._normalizaValor(s.valor) : null,
            valor: this._normalizaValor(s.valor),
            confirmado: payload.status === "confirmado" || payload.status === "recebido",
          })));
          if (error) throw error;
        }
      }
      return row?.id || null;
    },

    async removeEntrada(id) {
      if (!(await this._ensureSession()) || !id) return false;
      const uid = this._uid();
      await supa.from("separacoes").delete().eq("entrada_id", id).eq("user_id", uid);
      const { error } = await supa.from("entradas").delete().eq("id", id).eq("user_id", uid);
      if (error) throw error;
      return true;
    },

    async upsertLancamento(mes, g) {
      if (!(await this._ensureSession()) || !g) return null;
      const uid = this._uid();
      const dataLanc = g.data || this._dateFromMes(mes);
      const payload = {
        user_id: uid,
        mes_referencia: mes || this._mesFromISO(dataLanc),
        tipo: g.tipo || (g.categoria === "E" ? "essencial" : g.categoria === "P" ? "compromisso" : "variavel"),
        descricao: g.descricao || g.desc || "Gasto",
        categoria: g.categoria || "V",
        valor: this._normalizaValor(g.valor),
        data_lancamento: dataLanc,
        pago: !!(g.pago || g.status === "pago"),
        origem: "__meta__" + JSON.stringify(this._gastoMeta(g)),
        updated_at: new Date().toISOString(),
      };
      const dbId = g.db_id || g.id_banco || (g.id && /^[0-9a-f-]{20,}$/i.test(String(g.id)) ? g.id : null);
      if (dbId) {
        const { data, error } = await supa.from("lancamentos").update(payload).eq("id", dbId).eq("user_id", uid).select("id").single();
        if (error) throw error;
        g.db_id = data.id;
        return data.id;
      }
      const { data, error } = await supa.from("lancamentos").insert(payload).select("id").single();
      if (error) throw error;
      g.db_id = data.id;
      return data.id;
    },

    async removeLancamento(id) {
      if (!(await this._ensureSession()) || !id) return false;
      const { error } = await supa.from("lancamentos").delete().eq("id", id).eq("user_id", this._uid());
      if (error) throw error;
      return true;
    },

    async upsertGastoFixo(g) {
      if (!(await this._ensureSession()) || !g) return null;
      const uid = this._uid();
      const mes = g.startKey || this._activeMes();
      const payload = {
        user_id: uid,
        mes_referencia: mes,
        descricao: this._gastoFixoDescricao(g),
        categoria: g.categoria || "V",
        valor: this._normalizaValor(g.valor),
        vencimento: parseInt(g.diaVencimento || g.vencimento || 1, 10) || 1,
        pago: !!g.pago,
        data_pagamento: g.dataPagamento || null,
        updated_at: new Date().toISOString(),
      };
      const dbId = g.db_id || (g.id && /^[0-9a-f-]{20,}$/i.test(String(g.id)) ? g.id : null);
      if (dbId) {
        const { data, error } = await supa.from("gastos_fixos").update(payload).eq("id", dbId).eq("user_id", uid).select("id").single();
        if (error) throw error;
        g.id = data.id; g.db_id = data.id;
        return data.id;
      }
      const { data, error } = await supa.from("gastos_fixos").insert(payload).select("id").single();
      if (error) throw error;
      g.id = data.id; g.db_id = data.id;
      return data.id;
    },

    async removeGastoFixo(id) {
      if (!(await this._ensureSession()) || !id) return false;
      const { error } = await supa.from("gastos_fixos").delete().eq("id", id).eq("user_id", this._uid());
      if (error) throw error;
      return true;
    },

    async push() {
      if (!(await this._ensureSession())) return { ok: false, msg: "Não autenticado" };
      if (this._syncing) return { ok: true, skipped: true };
      this._syncing = true;
      try {
        this.status = "syncing";
        this.updateUI();
        const ciclos = Store.data.ciclos || {};
        for (const mes of Object.keys(ciclos)) {
          await this._upsertCiclo(mes);
          const ciclo = ciclos[mes] || {};
          const fontes = Array.isArray(ciclo.fontes) ? ciclo.fontes : [];
          for (const fonte of fontes) await this.upsertEntrada(mes, fonte);
          const gastos = Array.isArray(ciclo.gastos) ? ciclo.gastos : [];
          for (const g of gastos) await this.upsertLancamento(mes, g);
        }
        const fixos = Array.isArray(Store.data.gastosFixos) ? Store.data.gastosFixos : [];
        for (const g of fixos) await this.upsertGastoFixo(g);
        this.status = "connected";
        this.updateUI();
        return { ok: true };
      } catch (e) {
        console.error("[realtime push]", e);
        this.status = "error";
        this.updateUI();
        return { ok: false, msg: e.message };
      } finally {
        this._syncing = false;
      }
    },

    async pull() {
      if (!(await this._ensureSession())) return { ok: false, msg: "Não autenticado" };
      try {
        this.status = "syncing";
        this.updateUI();
        const uid = this._uid();
        Store.data.ciclos = {};

        const [{ data: ciclos }, { data: entradas }, { data: seps }, { data: lancs }, { data: fixos }, { data: objetivos }, { data: cartoes }, { data: faturas }] = await Promise.all([
          supa.from("ciclos").select("*").eq("user_id", uid).is("deleted_at", null),
          supa.from("entradas").select("*").eq("user_id", uid).is("deleted_at", null),
          supa.from("separacoes").select("*").eq("user_id", uid).is("deleted_at", null),
          supa.from("lancamentos").select("*").eq("user_id", uid).is("deleted_at", null),
          supa.from("gastos_fixos").select("*").eq("user_id", uid).is("deleted_at", null),
          supa.from("objetivos").select("*").eq("user_id", uid).is("deleted_at", null),
          supa.from("cartoes").select("*").eq("user_id", uid).is("deleted_at", null),
          supa.from("faturas").select("*").eq("user_id", uid).is("deleted_at", null),
        ]);

        const allMes = new Set([...(ciclos || []).map((c) => c.mes_referencia), ...(entradas || []).map((e) => e.mes_referencia), ...(lancs || []).map((l) => l.mes_referencia)]);
        allMes.forEach((mes) => {
          if (!mes) return;
          Store.data.ciclos[mes] = { renda: 0, gastos: [], decisao: "", fontes: [], separacoes: [] };
        });

        (entradas || []).forEach((e) => {
          const mes = e.mes_referencia || this._mesFromISO(e.data_recebimento || e.data_prevista);
          if (!Store.data.ciclos[mes]) Store.data.ciclos[mes] = { renda: 0, gastos: [], decisao: "", fontes: [], separacoes: [] };
          const fonte = {
            id: e.id,
            db_id: e.id,
            origem: e.origem || e.descricao || "Entrada",
            valor: this._normalizaValor(e.valor),
            data: e.data_recebimento || e.data_prevista || this._dateFromMes(mes),
            status: e.status || "previsto",
            separacoes: (seps || []).filter((s) => s.entrada_id === e.id).map((s) => ({
              id: s.id,
              db_id: s.id,
              nome: s.objetivo || "Separação",
              categoria: this._categoriaSep(s.objetivo, s.tipo === "percentual" ? null : s.categoria),
              tipo: s.percentual != null ? "percentual" : (s.tipo || "valor"),
              valor: s.percentual != null ? this._normalizaValor(s.percentual) : this._normalizaValor(s.valor),
              confirmado: !!s.confirmado,
            })),
          };
          Store.data.ciclos[mes].fontes.push(fonte);
        });

        (lancs || []).forEach((l) => {
          const mes = l.mes_referencia || this._mesFromISO(l.data_lancamento);
          if (!Store.data.ciclos[mes]) Store.data.ciclos[mes] = { renda: 0, gastos: [], decisao: "", fontes: [], separacoes: [] };
          const meta = this._parseOrigemMeta(l.origem);
          Store.data.ciclos[mes].gastos.push({
            id: l.id,
            db_id: l.id,
            descricao: l.descricao || "Gasto",
            desc: l.descricao || "Gasto",
            valor: this._normalizaValor(l.valor),
            data: l.data_lancamento || this._dateFromMes(mes),
            categoria: l.categoria || "V",
            tipo: l.tipo || "variavel",
            status: l.pago ? "pago" : (meta.status || "pendente"),
            pago: !!l.pago,
            ...meta,
          });
        });

        Object.values(Store.data.ciclos).forEach((ciclo) => {
          ciclo.renda = window.Calc && Calc.rendaNoMes ? Calc.rendaNoMes(ciclo) : (ciclo.fontes || []).reduce((s, f) => s + this._normalizaValor(f.valor), 0);
        });

        Store.data.gastosFixos = (fixos || []).map((g) => this._parseGastoFixo(g));
        Store.data.objetivos = (objetivos || []).map((o) => ({
          id: o.id,
          db_id: o.id,
          nome: o.nome,
          descricao: o.descricao || "",
          valor: this._normalizaValor(o.valor_meta),
          valorPago: this._normalizaValor(o.valor_atual),
          ativo: o.ativo !== false,
        }));
        Store.data.cartoes = (cartoes || []).map((c) => ({
          id: c.id,
          db_id: c.id,
          nome: c.nome,
          limite: this._normalizaValor(c.limite),
          diaFechamento: c.dia_fechamento || 1,
          diaVencimento: c.dia_vencimento || 10,
          fechamento: c.dia_fechamento || 1,
          vencimento: c.dia_vencimento || 10,
          ativo: c.ativo !== false,
        }));
        Store.data.faturas = faturas || [];
        Store.data.user = Store.data.user || { email: this.session?.user?.email || "" };
        Store.data._pulled = true;
        this.startRealtime();
        this.status = "connected";
        this.updateUI();
        return { ok: true };
      } catch (e) {
        console.error("[realtime pull]", e);
        this.status = "error";
        this.updateUI();
        return { ok: false, msg: e.message };
      }
    },

    startRealtime() {
      if (!supa || !this.session || this._realtimeChannel) return;
      const tables = ["entradas", "gastos_fixos", "lancamentos", "separacoes", "objetivos", "cartoes", "faturas"];
      let channel = supa.channel("meumes-realtime-teste");
      tables.forEach((table) => {
        channel = channel.on("postgres_changes", { event: "*", schema: "public", table }, async () => {
          const now = Date.now();
          if (now - this._lastRealtimeAt < 1200 || this._syncing) return;
          this._lastRealtimeAt = now;
          await this.pull();
          if (window.App && App.go) App.go(App.currentScreen || "meumes");
        });
      });
      channel.subscribe((status) => console.log("[realtime]", status));
      this._realtimeChannel = channel;
    },

    scheduleSync() {
      if (this._syncing) return;
      clearTimeout(this._cloudPushTimer);
      this._cloudPushTimer = setTimeout(() => this.push(), 500);
    },

    async signOut() {
      if (this._realtimeChannel && supa) {
        try { await supa.removeChannel(this._realtimeChannel); } catch (_) {}
      }
      this._realtimeChannel = null;
      if (supa) await supa.auth.signOut();
      this.session = null;
      this.status = "disconnected";
    },

    updateUI() {
      const syncEl = document.getElementById("sidebar-sync-area");
      if (syncEl) syncEl.style.display = "";
      const adminEl = document.getElementById("sidebar-admin-area");
      if (adminEl) adminEl.style.display = this.isAdmin() ? "" : "none";
      const dot = document.getElementById("sidebar-cloud-dot");
      const lbl = document.getElementById("sidebar-cloud-label");
      const statusMap = {
        disconnected: { color: "var(--grey-l)", label: "Não sincronizado" },
        connecting: { color: "var(--amber)", label: "Conectando…" },
        connected: { color: "var(--green)", label: "Realtime conectado" },
        syncing: { color: "var(--teal)", label: "Sincronizando…" },
        error: { color: "var(--red)", label: "Erro de sincronização" },
      };
      const m = statusMap[this.status] || statusMap.disconnected;
      if (dot) dot.style.background = m.color;
      if (lbl) lbl.textContent = m.label;
      const badge = document.getElementById("cloud-status-badge");
      if (badge) badge.textContent = m.label;
    },
  };

  window.CloudSync = CloudSync;
})();
