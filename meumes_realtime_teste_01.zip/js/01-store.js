/*
  ═══════════════════════════════════════════════════════
  01-STORE.JS
  ═══════════════════════════════════════════════════════
  Camada de persistência local. Centraliza leitura/gravação no localStorage e estrutura inicial dos dados.

  PADRÃO DO PROJETO:
  - Os dados principais ficam em Store.data.
  - Calc concentra regras de negócio e cálculos.
  - Screens monta HTML das telas.
  - Modals monta HTML dos formulários.
  - App coordena navegação, eventos e ações do usuário.

  DICA:
  Procure por 'AJUSTE AQUI' para encontrar pontos comuns de alteração.
*/

// ═══════════════════════════════════════════════════════
      // STORE
      // ═══════════════════════════════════════════════════════
      /* Store: estado central e persistência local do aplicativo. */
      var Store = {
        data: {
          user: null,
          recebimentos: [],
          objetivos: [],
          parcelas: [],
          ciclos: {},
          compromisso: "",
          categorias: [
            {
              id: "E",
              nome: "Essencial",
              cor: "var(--cat-e)",
              bg: "var(--cat-e-t)",
            },
            {
              id: "P",
              nome: "Compromissos",
              cor: "var(--cat-p)",
              bg: "var(--cat-p-t)",
            },
            {
              id: "V",
              nome: "Variável",
              cor: "var(--cat-v)",
              bg: "var(--cat-v-t)",
            },
            {
              id: "F",
              nome: "Construção",
              cor: "var(--cat-f)",
              bg: "var(--cat-f-t)",
            },
          ],
          planoContas: {},
          gastosFixos: [],
          modoLancamento: "simples",
          separacaoSugestoes: [
            "Cofrinho de emergência",
            "Investimento",
            "Poupança",
            "Dízimo",
            "Imposto",
            "Oferta",
            "Doação",
            "Ajuda familiar",
          ],
          cartoes: [],
        },
        load() {
          // Não usa mais localStorage — dados vêm do banco
          return this;
        },
        clearLocal() {
          try {
            localStorage.removeItem("farol_v3");
          } catch (e) {}
          this.data = {
            user: null,
            recebimentos: [],
            objetivos: [],
            parcelas: [],
            ciclos: {},
            compromisso: "",
            separacaoSugestoes: [
              "Cofrinho de emergência",
              "Investimento",
              "Objetivo financeiro",
              "Poupança",
              "Dízimo",
              "Imposto",
              "Oferta",
              "Doação",
              "Ajuda familiar",
            ],
            cartoes: [],
            planoContas: {},
            gastosFixos: [],
            modoLancamento: "simples",
            categorias: [
              {
                id: "E",
                nome: "Essencial",
                cor: "var(--cat-e)",
                bg: "var(--cat-e-t)",
              },
              {
                id: "P",
                nome: "Compromissos",
                cor: "var(--cat-p)",
                bg: "var(--cat-p-t)",
              },
              {
                id: "V",
                nome: "Variável",
                cor: "var(--cat-v)",
                bg: "var(--cat-v-t)",
              },
            ],
          };
        },
        save() {
          if (window.CloudSync) window.CloudSync.scheduleSync();
        },
        get(k) {
          return this.data[k];
        },
        set(k, v) {
          this.data[k] = v;
          this.save();
        },
      };
