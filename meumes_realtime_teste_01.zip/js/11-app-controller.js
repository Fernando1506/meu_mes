/*
  ═══════════════════════════════════════════════════════
  11-APP-CONTROLLER.JS
  ═══════════════════════════════════════════════════════
  Controlador principal: navegação, ações dos botões, salvar/excluir dados, modais e eventos.

  PADRÃO DO PROJETO:
  - Os dados principais ficam em Store.data.
  - Calc concentra regras de negócio e cálculos.
  - Screens monta HTML das telas.
  - Modals monta HTML dos formulários.
  - App coordena navegação, eventos e ações do usuário.

  DICA:
  Procure por 'AJUSTE AQUI' para encontrar pontos comuns de alteração.
*/

// ═══════════════════════════════════════════════════════
      // APP CONTROLLER
      // ═══════════════════════════════════════════════════════
      /* App: controlador principal que conecta Store, Calc, Screens, Modals e CloudSync. */
      var App = {
        currentScreen: "dashboard",
        _activityTimer: null,
        _submitLocks: {},
        _lastGoAt: 0,
        INATIVIDADE_MS: 30 * 60 * 1000, // 30 minutos

        // Inicia monitoramento de inatividade
        // Inicia o monitor de inatividade para encerrar sessão automaticamente.
        startActivityMonitor() {
          // Reinicia o temporizador sempre que o usuário interage com a página.
          const reset = () => this._resetActivityTimer();
          ["click", "keydown", "touchstart", "scroll", "mousemove"].forEach(
            (e) => document.addEventListener(e, reset, { passive: true }),
          );
          this._resetActivityTimer();
        },

        _resetActivityTimer() {
          clearTimeout(this._activityTimer);
          this._activityTimer = setTimeout(
            // Desloga o usuário por inatividade e limpa os dados visuais da sessão.
            () => this._autoLogout(),
            this.INATIVIDADE_MS,
          );
        },

        async _autoLogout() {
          // Só desloga se estiver autenticado
          if (!CloudSync.session) return;
          await CloudSync.signOut();
          document.getElementById("app-layout").classList.add("hidden");
          const sc = document.getElementById("screen-content");
          if (sc) sc.innerHTML = "";
          Store.data = {
            user: null,
            recebimentos: [],
            objetivos: [],
            parcelas: [],
            ciclos: {},
            compromisso: "",
            categorias: [
              {
                id: "E",
                nome: "Essencial",
                cor: "var(--cat-e)",
                bg: "var(--cat-e-t)",
              },
              {
                id: "P",
                nome: "Compromissos",
                cor: "var(--cat-p)",
                bg: "var(--cat-p-t)",
              },
              {
                id: "V",
                nome: "Variável",
                cor: "var(--cat-v)",
                bg: "var(--cat-v-t)",
              },
            ],
          };
          try {
            localStorage.removeItem("farol_v3");
          } catch (e) {}
          // Mostra aviso antes do login
          Login.show();
          setTimeout(() => {
            const msg = document.createElement("div");
            msg.style.cssText =
              "position:fixed;top:20px;left:50%;transform:translateX(-50%);background:var(--navy);color:#fff;padding:12px 20px;border-radius:10px;font-size:14px;z-index:9999;text-align:center;";
            msg.textContent =
              "Sessão encerrada por inatividade. Faça login novamente.";
            document.body.appendChild(msg);
            setTimeout(() => msg.remove(), 4000);
          }, 300);
        },
        selectedCat: "",
        activeCycleKey: null,

        // Retorna o ciclo financeiro atualmente selecionado.
        getActiveCycleKey() {
          return this.activeCycleKey || Calc.cicloAtual();
        },

        // Salva alteração em uma entrada prevista, apenas no mês atual ou também nos próximos.
        salvarEntradaPrevista(modo) {
          const key = document.getElementById("m-eprev-key")?.value;
          const idx = parseInt(
            document.getElementById("m-eprev-idx")?.value ?? "-1",
            10,
          );
          const novoValor = parseFloat(
            document.getElementById("m-eprev-valor")?.value || 0,
          );
          const novaData = document.getElementById("m-eprev-data")?.value || "";
          if (!key || idx < 0 || !novoValor)
            return this.toast("Preencha o valor.");

          const ciclos = Store.get("ciclos") || {};

          if (modo === "somente") {
            // Altera só o índice idx no mês key
            if (!ciclos[key]?.fontes?.[idx])
              return this.toast("Entrada não encontrada.");
            ciclos[key].fontes[idx].valor = novoValor;
            if (novaData) ciclos[key].fontes[idx].data = novaData;
            ciclos[key].renda = Calc.rendaNoMes(ciclos[key]);
            Store.set("ciclos", ciclos);
            // Fecha o modal atualmente aberto.
            this.closeModal();
            this.toast("Entrada atualizada para este mês.");
            this.go(this.currentScreen);
            return;
          }

          // modo === "seguintes": altera key e todos os meses futuros que
          // têm uma entrada com a mesma origem no mesmo índice
          const origem = ciclos[key]?.fontes?.[idx]?.origem || "";
          const [yearK, monthK] = key.split("-").map(Number);

          // Itera pelos próximos 24 meses a partir do mês alvo
          for (let i = 0; i <= 24; i++) {
            const d = new Date(yearK, monthK + i, 1);
            const k = `${d.getFullYear()}-${d.getMonth()}`;
            if (!ciclos[k]?.fontes) continue;
            // Encontra entrada com mesma origem (ou mesmo índice se origem igual)
            const fi = ciclos[k].fontes.findIndex((f, fi) =>
              fi === idx ? true : (f.origem || "") === origem,
            );
            if (fi < 0) continue;
            ciclos[k].fontes[fi].valor = novoValor;
            if (novaData) {
              // Mantém o mês/ano do ciclo, só altera o dia
              const partes = (ciclos[k].fontes[fi].data || novaData).split("-");
              const novaPartes = novaData.split("-");
              ciclos[k].fontes[fi].data =
                `${partes[0]}-${partes[1]}-${novaPartes[2]}`;
            }
            ciclos[k].renda = Calc.rendaNoMes(ciclos[k]);
          }

          Store.set("ciclos", ciclos);
          this.closeModal();
          this.toast("Entrada atualizada neste e nos próximos meses.");
          this.go(this.currentScreen);
        },

        getSeparacaoSuggestions() {
          const saved = Store.get("separacaoSugestoes");
          const base = [
            "Cofrinho de emergência",
            "Investimento",
            "Objetivo financeiro",
            "Poupança",
            "Dízimo",
            "Imposto",
            "Oferta",
            "Doação",
            "Ajuda familiar",
          ];
          const merged = Array.from(new Set([...(Array.isArray(saved) ? saved : []), ...base]));
          Store.set("separacaoSugestoes", merged);
          return merged;
        },

        saveSeparacaoSuggestions(nomes) {
          const merged = Array.from(
            new Set([
              ...this.getSeparacaoSuggestions(),
              ...(nomes || []).filter(Boolean),
            ]),
          );
          Store.set("separacaoSugestoes", merged);
        },

        TRIAL_DAYS: 30,

        // Retorna {expired:bool, daysLeft:number} com base na data de criação da conta
        getTrialInfo(session) {
          const createdAt = session?.user?.created_at;
          if (!createdAt) return { expired: false, daysLeft: this.TRIAL_DAYS };
          const created = new Date(createdAt);
          const now = new Date();
          const diffDays = Math.floor((now - created) / (1000 * 60 * 60 * 24));
          const daysLeft = this.TRIAL_DAYS - diffDays;
          return { expired: daysLeft <= 0, daysLeft: Math.max(0, daysLeft) };
        },

        showTrialExpired() {
          document.getElementById("app-layout")?.classList.add("hidden");
          document.getElementById("login-screen")?.classList.add("hidden");
          let el = document.getElementById("trial-expired-screen");
          if (!el) {
            el = document.createElement("div");
            el.id = "trial-expired-screen";
            el.style.cssText =
              "position:fixed;inset:0;z-index:3000;background:var(--navy);display:flex;align-items:center;justify-content:center;padding:24px;";
            document.body.appendChild(el);
          }
          el.innerHTML = `
          <div style="max-width:420px;width:100%;background:#fff;border-radius:var(--r-xl);padding:36px 28px;text-align:center;box-shadow:var(--sh-xl);">
            <div style="width:52px;height:52px;border-radius:14px;background:var(--teal-lt);border:1px solid rgba(13,143,110,.2);display:flex;align-items:center;justify-content:center;margin:0 auto 18px;">
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#0D8F6E" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
            </div>
            <div style="font-size:20px;font-weight:700;color:var(--navy);margin-bottom:8px;">Seu período de teste terminou</div>
            <p style="font-size:14px;color:var(--grey);line-height:1.7;margin-bottom:22px;">Seus dados continuam salvos e seguros. Assine para continuar usando o Meu Mês e acessar tudo de onde você parou.</p>
            <a href="#" class="btn btn-gold btn-full btn-lg" style="border-radius:12px;text-decoration:none;display:flex;">Assinar agora</a>
            <button class="btn btn-ghost btn-full mt-12" style="border-radius:12px;" onclick="App.confirmLogout()">Sair</button>
          </div>`;
          el.classList.remove("hidden");
        },

        // Inicializa eventos, estado e renderização inicial do aplicativo.
        async init() {
          this._initPlanoContas();

          if (CloudSync.isConfigured()) {
            // Listener de sessão
            supa.auth.onAuthStateChange((event, session) => {
              CloudSync.session = session || null;
              if (session) {
                if (CloudSync.status === "disconnected") {
                  CloudSync.status = "connected";
                  CloudSync.updateUI();
                }
              } else {
                CloudSync.status = "disconnected";
                CloudSync.updateUI();
              }
            });

            const session = await CloudSync.getSession();
            if (session) {
              CloudSync.session = session;
              CloudSync.status = "connected";
              CloudSync._syncing = true;
              await CloudSync.pull();
              CloudSync._syncing = false;

              // Verifica trial expirado
              if (Store.data.trialExpired) {
                this.showTrialExpired();
                return;
              }

              // Garante user no Store
              const user = Store.get("user");
              if (!user) {
                const nome =
                  session.user?.user_metadata?.nome ||
                  session.user?.email?.split("@")[0] ||
                  "Usuário";
                Store.set("user", {
                  nome,
                  email: session.user.email,
                  criadoEm: new Date().toISOString(),
                });
              }

              if (Store.get("onboardingDone")) {
                this.startApp();
              } else {
                Ob.start();
              }
              return;
            }
            Login.show();
            return;
          }

          if (CloudSync.status === "connected") {
            try {
              await CloudSync.pull(); // Carrega dados do banco
              console.log("✅ Dados sincronizados do banco");
            } catch (err) {
              console.warn("Erro ao sincronizar:", err);
            }
          }

          // ✅ ADICIONAR ISTO AQUI:

          if (CloudSync.status === "connected") {
            try {
              await CloudSync.pull(); // Carrega dados do banco
              console.log("✅ Dados sincronizados do banco");
            } catch (err) {
              console.warn("Erro ao sincronizar:", err);
            }
          }

          // Fallback: Supabase não configurado — modo local (sem login)
          const user = Store.get("user");
          if (!user) {
            Store.set("user", {
              nome: "Usuário",
              criadoEm: new Date().toISOString(),
            });
          }
          if (Store.get("onboardingDone")) {
            this.startApp();
          } else {
            Ob.start();
          }
        },

        _initPlanoContas() {
          const plano = Store.get("planoContas") || {};
          const defaults = {
            E: [
              "Moradia",
              "Aluguel",
              "Condomínio",
              "Água",
              "Luz",
              "Gás",
              "Internet",
              "Telefone",
              "Alimentação",
              "Mercado",
              "Farmácia",
              "Saúde",
              "Plano de saúde",
              "Transporte",
              "Combustível",
              "Escola",
              "Faculdade",
            ],
            P: [
              "Cartão de crédito",
              "Financiamento",
              "Empréstimo",
              "Carnê",
              "Seguro",
              "Consórcio",
              "Mensalidade",
              "Prestação",
            ],
            V: [
              "Lazer",
              "Restaurante",
              "Delivery",
              "Vestuário",
              "Beleza",
              "Assinatura",
              "Academia",
              "Viagem",
              "Presentes",
              "Eletrônicos",
              "Compras diversas",
            ],
            F: [
              "Cofrinho de emergência",
              "Poupança",
              "Investimento",
              "CDB",
              "Tesouro Direto",
              "Objetivo pessoal",
              "Aposentadoria",
            ],
          };
          let changed = false;
          Object.entries(defaults).forEach(([cat, subs]) => {
            if (!plano[cat] || plano[cat].length === 0) {
              plano[cat] = subs;
              changed = true;
            }
          });
          if (changed) Store.set("planoContas", plano);
        },

        startApp() {
          const user = Store.get("user");
          document.getElementById("app-layout").classList.remove("hidden");
          this.startActivityMonitor();
          this.startPeriodicSync();
          // Pull periódico a cada 5 minutos
          if (!this._periodicPull) {
            this._periodicPull = setInterval(
              async () => {
                if (CloudSync.status === "connected") {
                  await CloudSync.pull();
                  const el = document.getElementById("screen-content");
                  if (el && Screens[this.currentScreen])
                    el.innerHTML = Screens[this.currentScreen]();
                }
              },
              5 * 60 * 1000,
            );
          }
          const nameEl = document.getElementById("sidebar-user-name");
          const userEl = document.getElementById("sidebar-user");
          if (nameEl && user) {
            nameEl.textContent = user.nome;
            userEl.classList.remove("hidden");
          }
          this.activeCycleKey = Calc.cicloAtual();

          const daysLeft = Store.get("trialDaysLeft");
          const badge = document.getElementById("sidebar-trial-badge");
          if (badge && typeof daysLeft === "number") {
            badge.classList.remove("hidden");
            if (daysLeft <= 5) {
              badge.textContent =
                daysLeft <= 0
                  ? "Período de teste encerrado"
                  : `Teste gratuito: ${daysLeft} dia(s) restante(s)`;
              badge.style.color = "var(--amber)";
              badge.style.background = "var(--amb-t)";
              badge.style.borderColor = "rgba(168,94,16,.2)";
            } else {
              badge.textContent = `Teste gratuito: ${daysLeft} dias restantes`;
            }
          }

          this.go("dashboard");
          window.addEventListener(
            "resize",
            () => {
              if (window.innerWidth > 1024) this.closeSidebar();
            },
            { passive: true },
          );
        },

        // Evita duplo clique em ações de salvar/pagar/fechar.
        // O feedback aparece na hora e o botão fica temporariamente bloqueado.
        _beginSubmit(action, label = "Salvando...") {
          this._submitLocks = this._submitLocks || {};
          if (this._submitLocks[action]) return false;
          this._submitLocks[action] = true;
          const btn = document.activeElement && document.activeElement.closest
            ? document.activeElement.closest("button")
            : null;
          if (btn && !btn.dataset.originalText) {
            btn.dataset.originalText = btn.innerHTML;
            btn.disabled = true;
            btn.classList.add("is-saving");
            btn.innerHTML = label;
          }
          setTimeout(() => {
            this._submitLocks[action] = false;
            if (btn) {
              btn.disabled = false;
              btn.classList.remove("is-saving");
              if (btn.dataset.originalText) {
                btn.innerHTML = btn.dataset.originalText;
                delete btn.dataset.originalText;
              }
            }
          }, 1800);
          return true;
        },

        // Troca a tela atual, renderiza o conteúdo e atualiza a navegação.
        go(screen) {
          const now = Date.now();
          if (this.currentScreen === screen && now - this._lastGoAt < 180) return;
          this._lastGoAt = now;
          this.currentScreen = screen;
          const el = document.getElementById("screen-content");
          if (!el || !Screens[screen]) return;
          el.classList.add("is-rendering");
          el.innerHTML = Screens[screen]();
          requestAnimationFrame(() => el.classList.remove("is-rendering"));
          document
            .querySelectorAll(".nav-item")
            .forEach((n) =>
              n.classList.toggle("active", n.dataset.screen === screen),
            );
          document
            .querySelectorAll(".bottom-nav-item")
            .forEach((n) =>
              n.classList.toggle("active", n.dataset.bn === screen),
            );
          const titles = {
            dashboard: "MEU MÊS",
            meumes: "Meu Mês",
            analise: "Análise",
            evolucao: "Evolução",
            objetivos: "Objetivos",
            parcelas: "Parcelas",
            recebimentos: "Recebimentos",
            principios: "Princípios",
            conquistas: "Conquistas",
            decisao: "Decisão",
            introducao: "Visão do produto",
            planoContas: "Plano de Contas",
            cartoes: "Cartão",
            compromissos: "Compromissos",
            reserva: "Cofrinho",
            nuvem: "Sincronização na Nuvem",
            meumesSimples: "Meu Mês",
            suporte: "Suporte",
            admin: "Painel Admin",
            "minha-conta": "Minha Conta",
            mais: "Mais",
          };
          const mTitle = document.getElementById("mobile-title");
          if (mTitle) mTitle.textContent = titles[screen] || "MEU MÊS";
          el.scrollTop = 0;
          window.scrollTo(0, 0);
          if (screen === "nuvem") setTimeout(() => App.loadMembers(), 200);
          if (screen === "admin") setTimeout(() => App.loadAdmin(), 200);
          if (screen === "minha-conta" && Store.get("is_admin"))
            setTimeout(() => App.loadMembers(), 200);
          this.closeSidebar();
        },

        shiftMonth(dir) {
          const cur = this.getActiveCycleKey();
          const [y, m] = cur.split("-").map(Number);
          const d = new Date(y, m, 1);
          d.setMonth(d.getMonth() + dir);
          const newKey = `${d.getFullYear()}-${d.getMonth()}`;
          this.activeCycleKey = newKey;

          // Mantém o usuário na tela atual.
          // Antes, qualquer seta de mês chamava sempre go("meumes"),
          // por isso a seta do card do Dashboard jogava para Meu Mês.
          const screen = this.currentScreen || "meumes";
          this.go(screen === "dashboard" ? "dashboard" : "meumes");
        },

        // Navega pelos meses no Dashboard sem sair da tela inicial.
        shiftDashboardMonth(dir) {
          const cur = this.getActiveCycleKey();
          const [y, m] = cur.split("-").map(Number);
          const d = new Date(y, m, 1);
          d.setMonth(d.getMonth() + dir);
          this.activeCycleKey = `${d.getFullYear()}-${d.getMonth()}`;
          this.go("dashboard");
        },

        // Vai direto para o mês escolhido no carrossel, abrindo a tela de Meu Mês daquele ciclo.
        shiftToCycle(key) {
          this.activeCycleKey = key;
          this.go("meumes");
        },

        // Expande/recolhe o card de mês no carrossel do dashboard, sem trocar de tela.
        openMonthCard(key, el) {
          document.querySelectorAll(".month-card.is-open").forEach((c) => {
            if (c !== el) c.classList.remove("is-open");
          });
          if (el) {
            el.classList.toggle("is-open");
            if (el.classList.contains("is-open")) {
              setTimeout(() => {
                el.scrollIntoView({
                  behavior: "smooth",
                  block: "nearest",
                  inline: "center",
                });
              }, 80);
            }
          }
        },

        // Abre um modal conforme o tipo solicitado.
        openModal(type, arg) {
          if (!Modals[type]) return;
          // Abre imediatamente. Sincronização deve rodar em segundo plano,
          // porque esperar o banco antes de abrir modal deixa o app com sensação lenta.
          this._renderModal(type, arg);
        },

        _renderModal(type, arg) {
          if (!Modals[type]) return;
          const overlay = document.createElement("div");
          overlay.className = "overlay";
          overlay.id = "modal-overlay";
          overlay.onclick = (e) => {
            if (e.target === overlay) this.closeModal();
          };
          const sheet = document.createElement("div");
          sheet.className = "sheet";
          sheet.innerHTML = Modals[type](arg);
          overlay.appendChild(sheet);
          document.getElementById("overlay-container").appendChild(overlay);
          if (type === "renda") {
            setTimeout(() => {
              const seps = arg && arg.item && Array.isArray(arg.item.separacoes) ? arg.item.separacoes : [];
              seps.forEach((sep) => App.addSeparacaoRow(sep));
              App.updateRendaSeparationSummary();
            }, 0);
          }
          setTimeout(() => {
            const inp = sheet.querySelector("input");
            if (inp) inp.focus();
          }, 100);
        },

        closeModal() {
          const o = document.getElementById("modal-overlay");
          if (o) o.remove();
        },

        // Mostra uma mensagem temporária de feedback para o usuário.
        toast(msg, dur = 2500) {
          const t = document.createElement("div");
          t.className = "toast";
          t.textContent = msg;
          document.body.appendChild(t);
          setTimeout(() => t.remove(), dur);
        },

        selectCat(id) {
          this.selectedCat = id;
          document.getElementById("m-cat").value = id;
          document.querySelectorAll(".tipo-btn").forEach((b) => {
            const active = b.dataset.cat === id;
            b.classList.toggle("active", active);
            const letter = b.querySelector(".tipo-letter");
            const cat = Store.get("categorias").find(
              (c) => c.id === b.dataset.cat,
            );
            if (letter)
              letter.style.color = active ? "#fff" : cat?.cor || "#333";
          });
        },

        refreshSubcats(catId) {
          const subcats = (Store.get("planoContas") || {})[catId] || [];
          const sel = document.getElementById("m-subcat");
          if (!sel) return;
          sel.innerHTML =
            subcats.map((i) => `<option value="${i}">${i}</option>`).join("") ||
            '<option value="">—</option>';
        },

        // ─── Tipos de Separação (Plano de Contas) ──────────────
        addSepTipoUI() {
          document.getElementById("sep-tipo-form")?.classList.remove("hidden");
          document.getElementById("sep-tipo-input")?.focus();
        },
        cancelSepTipoUI() {
          document.getElementById("sep-tipo-form")?.classList.add("hidden");
          const inp = document.getElementById("sep-tipo-input");
          if (inp) inp.value = "";
        },
        saveSepTipo() {
          const inp = document.getElementById("sep-tipo-input");
          const nome = (inp?.value || "").trim();
          if (!nome) {
            this.toast("Digite o nome");
            return;
          }
          const tipos = Store.get("separacaoSugestoes") || [];
          if (!tipos.includes(nome)) tipos.push(nome);
          Store.set("separacaoSugestoes", tipos);
          this.toast("Tipo de separação salvo!");
          this.go("planoContas");
        },
        deleteSepTipo(idx) {
          const tipos = Store.get("separacaoSugestoes") || [];
          const nome = FarolHelpers.escapeHtml(tipos[idx] || "este tipo");
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay-confirm";
          overlay.onclick = (e) => {
            if (e.target === overlay) overlay.remove();
          };
          const modal = document.createElement("div");
          modal.className = "modal";
          modal.style.cssText = "width:min(400px,92vw);";
          modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Excluir tipo de separação</div><div class="modal-subtitle">Deseja excluir <strong>${nome}</strong>?</div></div><button class="modal-close" onclick="this.closest('.overlay').remove()">×</button></div><div class="modal-actions"><button class="btn btn-ghost" onclick="this.closest('.overlay').remove()">Cancelar</button><button class="btn btn-danger" onclick="App.confirmDeleteSepTipo(${idx})">Excluir</button></div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
        },
        confirmDeleteSepTipo(idx) {
          document.getElementById("modal-overlay-confirm")?.remove();
          const tipos = Store.get("separacaoSugestoes") || [];
          tipos.splice(idx, 1);
          Store.set("separacaoSugestoes", tipos);
          this.toast("Excluído.");
          this.go("planoContas");
        },

        toggleRecType(v) {
          document
            .getElementById("m-r-grid-fixo")
            ?.classList.toggle("hidden", v === "extra");
        },
        toggleRecorrenciaFields(v) {
          document
            .getElementById("m-repeticao-meses-wrap")
            ?.classList.toggle("hidden", v !== "mensal");
          document
            .getElementById("m-parcelas-wrap")
            ?.classList.toggle("hidden", v !== "parcelado_fixo");
        },
        toggleRendaOrigem(v) {
          const inp = document.getElementById("m-renda-origem-custom");
          if (inp) inp.classList.toggle("hidden", v !== "_novo_");
        },

        addSubcatUI(catId) {
          document
            .getElementById(`subcat-form-${catId}`)
            ?.classList.remove("hidden");
          document.getElementById(`subcat-input-${catId}`)?.focus();
        },
        cancelSubcatUI(catId) {
          document
            .getElementById(`subcat-form-${catId}`)
            ?.classList.add("hidden");
          const inp = document.getElementById(`subcat-input-${catId}`);
          if (inp) inp.value = "";
        },
        saveSubcat(catId) {
          const inp = document.getElementById(`subcat-input-${catId}`);
          const nome = (inp?.value || "").trim();
          if (!nome) {
            this.toast("Digite o nome");
            return;
          }
          const plano = Store.get("planoContas") || {};
          plano[catId] = plano[catId] || [];
          if (!plano[catId].includes(nome)) plano[catId].push(nome);
          Store.set("planoContas", plano);
          this.toast("Subcategoria salva!");
          this.go("planoContas");
        },
        deleteSubcat(catId, idx) {
          const plano = Store.get("planoContas") || {};
          const nome = FarolHelpers.escapeHtml(
            (plano[catId] || [])[idx] || "esta subcategoria",
          );
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay-confirm";
          overlay.onclick = (e) => {
            if (e.target === overlay) overlay.remove();
          };
          const modal = document.createElement("div");
          modal.className = "modal";
          modal.style.cssText = "width:min(400px,92vw);";
          modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Excluir subcategoria</div><div class="modal-subtitle">Deseja excluir <strong>${nome}</strong>?</div></div><button class="modal-close" onclick="this.closest('.overlay').remove()">×</button></div><div class="modal-actions"><button class="btn btn-ghost" onclick="this.closest('.overlay').remove()">Cancelar</button><button class="btn btn-danger" onclick="App.confirmDeleteSubcat('${catId}',${idx})">Excluir</button></div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
        },
        confirmDeleteSubcat(catId, idx) {
          document.getElementById("modal-overlay-confirm")?.remove();
          const plano = Store.get("planoContas") || {};
          if (plano[catId]) plano[catId].splice(idx, 1);
          Store.set("planoContas", plano);
          this.toast("Excluída.");
          this.go("planoContas");
        },

        // Salva (cria ou edita) um Compromisso Fixo a partir do modal dedicado.
        // Por padrão fica sem data de término (recorrente todo mês); só recebe
        // endKey se o usuário marcar explicitamente que tem prazo.
        async saveCompromisso() {
          const idxRaw = document.getElementById("m-comp-idx")?.value;
          const idx =
            idxRaw !== "" && idxRaw != null ? parseInt(idxRaw, 10) : null;
          const nome = document.getElementById("m-comp-nome")?.value?.trim();
          const valor = parseFloat(
            document.getElementById("m-comp-valor")?.value || 0,
          );
          const dia = Math.min(
            Math.max(
              parseInt(document.getElementById("m-comp-dia")?.value || 1, 10) || 1,
              1,
            ),
            28,
          );
          const temPrazo = document.getElementById("m-comp-tem-prazo")?.checked;
          const prazoValue = document.getElementById("m-comp-prazo")?.value || "";

          if (!nome) {
            this.toast("Digite o nome do compromisso");
            return;
          }
          if (!valor || valor <= 0) {
            this.toast("Digite o valor");
            return;
          }

          let endKey = null;
          if (temPrazo && prazoValue) {
            const [y, m] = prazoValue.split("-").map(Number);
            endKey = `${y}-${m - 1}`; // input month é 1-indexed; nosso key é 0-indexed
          }

          const fixos = Store.get("gastosFixos") || [];
          if (idx !== null && fixos[idx]) {
            fixos[idx] = {
              ...fixos[idx],
              descricao: nome,
              valor,
              diaVencimento: dia,
              endKey,
            };
          } else {
            fixos.push({
              id: "fx_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
              descricao: nome,
              valor,
              categoria: "V",
              diaVencimento: dia,
              recorrencia: "mensal",
              startKey: this.getActiveCycleKey(),
              endKey,
              skipMonths: [],
            });
          }
          Store.set("gastosFixos", fixos);
          this.closeModal();
          this.toast(idx !== null ? "Compromisso atualizado!" : "Compromisso cadastrado!");
          this.go(this.currentScreen);
        },

        deleteCompromisso(idx) {
          const fixos = Store.get("gastosFixos") || [];
          if (!fixos[idx]) return;
          if (!confirm(`Excluir "${fixos[idx].descricao}"? Isso para os descontos futuros desse compromisso.`)) return;
          fixos.splice(idx, 1);
          Store.set("gastosFixos", fixos);
          this.toast("Compromisso excluído.");
          this.go(this.currentScreen);
        },

        // Salva um gasto/conta no ciclo ativo.
        saveGasto() {
          if (!this._beginSubmit("saveGasto")) return;
          const desc = document.getElementById("m-desc")?.value?.trim();
          const valor = parseFloat(
            document.getElementById("m-valor")?.value || 0,
          );
          const cat = document.getElementById("m-cat")?.value || "V";
          const data = document.getElementById("m-data")?.value;
          const recorrencia =
            document.getElementById("m-repete")?.value || "avulso";
          const repeatMonths = Math.max(
            parseInt(
              document.getElementById("m-repetir-meses")?.value || "1",
              10,
            ),
            1,
          );
          const numParcelas = Math.max(
            parseInt(
              document.getElementById("m-num-parcelas")?.value || "2",
              10,
            ),
            2,
          );
          const descricaoFinal = desc || "Gasto";
          if (!valor || valor <= 0) {
            this.toast("Digite o valor");
            return;
          }
          const key = this.getActiveCycleKey();
          const ciclos = Store.get("ciclos") || {};
          if (!ciclos[key])
            ciclos[key] = { renda: 0, gastos: [], decisao: "", fontes: [] };
          let templateId = "";
          let startKey = key;
          let endKey = key;
          if (recorrencia === "mensal") {
            templateId = "fx_" + Date.now();
            endKey = FarolHelpers.shiftMonthKey(startKey, repeatMonths - 1);
            const fixos = Store.get("gastosFixos") || [];
            const diaVencimento = parseInt(
              (data || "").split("-")[2] || new Date().getDate(),
              10,
            );
            fixos.push({
              id: templateId,
              descricao: descricaoFinal,
              valor,
              categoria: cat,
              diaVencimento,
              recorrencia: "mensal",
              repeatMonths,
              startKey,
              endKey,
              skipMonths: [],
            });
            Store.set("gastosFixos", fixos);
          }
          if (recorrencia === "parcelado_fixo") {
            templateId = "pfx_" + Date.now();
            endKey = FarolHelpers.shiftMonthKey(startKey, numParcelas - 1);
            const fixos = Store.get("gastosFixos") || [];
            const diaVencimento = parseInt(
              (data || "").split("-")[2] || new Date().getDate(),
              10,
            );
            fixos.push({
              id: templateId,
              descricao: descricaoFinal,
              valor,
              categoria: cat,
              diaVencimento,
              recorrencia: "parcelado_fixo",
              totalParcelas: numParcelas,
              startKey,
              endKey,
              skipMonths: [],
            });
            Store.set("gastosFixos", fixos);
          }
          const defaultDate =
            data ||
            `${key.split("-")[0]}-${String(parseInt(key.split("-")[1]) + 1).padStart(2, "0")}-${String(new Date().getDate()).padStart(2, "0")}`;
          const parcelaAtual = recorrencia === "parcelado_fixo" ? 1 : undefined;
          ciclos[key].gastos.push({
            descricao: descricaoFinal,
            valor,
            categoria: cat,
            data: defaultDate,
            pago: false,
            ...(templateId
              ? {
                  templateId,
                  recorrencia:
                    recorrencia === "parcelado_fixo"
                      ? "parcelado_fixo"
                      : "mensal",
                  startKey,
                  endKey,
                  repeatMonths:
                    recorrencia === "mensal" ? repeatMonths : undefined,
                  totalParcelas:
                    recorrencia === "parcelado_fixo" ? numParcelas : undefined,
                  parcelaNum: parcelaAtual,
                }
              : {}),
          });
          Store.set("ciclos", ciclos);
          this.closeModal();
          this.toast(
            recorrencia === "mensal"
              ? `Repetido por ${repeatMonths} meses!`
              : recorrencia === "parcelado_fixo"
                ? `Parcelado em ${numParcelas}x!`
                : "Gasto registrado!",
          );
          this.go(this.currentScreen);
        },

        // Remove um gasto do ciclo ativo.
        deleteGasto(key, idx) {
          const ciclos = Store.get("ciclos") || {};
          const c = ciclos[key];
          if (!c || !c.gastos || !c.gastos[idx]) return;
          const g = c.gastos[idx];
          if (g.templateId && g.recorrencia === "mensal") {
            this.openRecurringDeleteModal(key, idx, g);
            return;
          }
          if (
            g.templateId &&
            (g.recorrencia === "parcelado" ||
              g.recorrencia === "parcelado_fixo")
          ) {
            this.openParcelMonthDeleteModal(key, idx, g);
            return;
          }
          const nome = FarolHelpers.escapeHtml(
            g.descricao || "este lançamento",
          );
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay-confirm";
          overlay.onclick = (e) => {
            if (e.target === overlay) overlay.remove();
          };
          const modal = document.createElement("div");
          modal.className = "modal";
          modal.style.cssText = "width:min(400px,92vw);";
          modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Excluir lançamento</div><div class="modal-subtitle">Deseja realmente excluir <strong>${nome}</strong>?</div></div><button class="modal-close" onclick="this.closest('.overlay').remove()">×</button></div><div class="modal-actions"><button class="btn btn-ghost" onclick="this.closest('.overlay').remove()">Cancelar</button><button class="btn btn-danger" onclick="App.confirmDeleteGasto('${key}',${idx})">Excluir</button></div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
        },

        confirmDeleteGasto(key, idx) {
          document.getElementById("modal-overlay-confirm")?.remove();
          const ciclos = Store.get("ciclos") || {};
          const c = ciclos[key];
          if (!c || !c.gastos || !c.gastos[idx]) return;
          c.gastos.splice(idx, 1);
          Store.set("ciclos", ciclos);
          this.toast("Lançamento excluído.");
          this.go(this.currentScreen);
        },

        openRecurringDeleteModal(key, idx, gasto) {
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay";
          overlay.onclick = (e) => {
            if (e.target === overlay) this.closeModal();
          };
          const modal = document.createElement("div");
          modal.className = "modal";
          modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Excluir lançamento recorrente</div><div class="modal-subtitle">Escolha o alcance da exclusão para "${FarolHelpers.escapeHtml(gasto.descricao)}".</div></div><button class="modal-close" onclick="App.closeModal()">×</button></div>
        <div style="padding:22px 28px 10px;">
          <div class="structural-list">
            <div class="structural-pill"><div><strong>Somente este mês</strong><span><br>Remove apenas a ocorrência atual e preserva os demais meses.</span></div></div>
            <div class="structural-pill"><div><strong>Deste mês em diante</strong><span><br>Interrompe a recorrência a partir do mês atual.</span></div></div>
            <div class="structural-pill"><div><strong>Todos os meses</strong><span><br>Apaga toda a série recorrente do histórico.</span></div></div>
          </div>
        </div>
        <div class="modal-actions">
          <button class="btn btn-ghost" onclick="App.closeModal()">Cancelar</button>
          <button class="btn btn-outline" onclick="App.confirmRecurringDelete('${key}',${idx},'once')">Só este mês</button>
          <button class="btn btn-primary" onclick="App.confirmRecurringDelete('${key}',${idx},'forward')">Deste mês em diante</button>
          <button class="btn btn-danger" onclick="App.confirmRecurringDelete('${key}',${idx},'all')">Todos</button>
        </div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
        },

        confirmRecurringDelete(key, idx, scope) {
          const ciclos = Store.get("ciclos") || {};
          const c = ciclos[key];
          if (!c || !c.gastos || !c.gastos[idx]) {
            this.closeModal();
            return;
          }
          const g = c.gastos[idx];
          const fixos = Store.get("gastosFixos") || [];
          const tIndex = fixos.findIndex((t) => t.id === g.templateId);
          if (scope === "once") {
            c.gastos.splice(idx, 1);
            if (tIndex >= 0) {
              const skip = new Set(fixos[tIndex].skipMonths || []);
              skip.add(key);
              fixos[tIndex].skipMonths = Array.from(skip);
              Store.set("gastosFixos", fixos);
            }
            Store.set("ciclos", ciclos);
            this.closeModal();
            this.toast("Removido apenas neste mês.");
            this.go(this.currentScreen);
            return;
          }
          if (scope === "forward" && tIndex >= 0) {
            const prevKey = FarolHelpers.shiftMonthKey(key, -1);
            fixos[tIndex].endKey = prevKey;
            Store.set("gastosFixos", fixos);
            Object.keys(ciclos).forEach((k) => {
              if (
                FarolHelpers.keyNum(k) >= FarolHelpers.keyNum(key) &&
                ciclos[k] &&
                ciclos[k].gastos
              )
                ciclos[k].gastos = ciclos[k].gastos.filter(
                  (x) => x.templateId !== g.templateId,
                );
            });
            Store.set("ciclos", ciclos);
            this.closeModal();
            this.toast("× Recorrência interrompida deste mês em diante.");
            this.go(this.currentScreen);
            return;
          }
          const left = fixos.filter((t) => t.id !== g.templateId);
          Store.set("gastosFixos", left);
          Object.keys(ciclos).forEach((k) => {
            const ciclo = ciclos[k];
            if (ciclo && ciclo.gastos)
              ciclo.gastos = ciclo.gastos.filter(
                (x) => x.templateId !== g.templateId,
              );
          });
          Store.set("ciclos", ciclos);
          this.closeModal();
          this.toast("Recorrência removida de todos os meses.");
          this.go(this.currentScreen);
        },

        saveRenda() {
          if (!this._beginSubmit("saveRenda")) return;
          const valor = parseFloat(
            document.getElementById("m-renda-valor")?.value || 0,
          );
          const origemSel =
            document.getElementById("m-renda-origem")?.value?.trim() ||
            "Entrada";
          const origemCustom = (
            document.getElementById("m-renda-origem-custom")?.value || ""
          ).trim();
          const origem =
            origemSel === "_novo_" ? origemCustom || "Entrada" : origemSel;

          // Data: usa SEMPRE o valor digitado pelo usuário no campo.
          // ATENÇÃO: o dia da data define em qual bloco a entrada aparece em "Meu Mês":
          //   - dia 01 a 19 → 1ª entrada (contas até dia 19)
          //   - dia 20 em diante → 2ª entrada (contas do dia 20 em diante)
          // Se dois salários foram lançados no mesmo dia (ex: dia 05), ambos ficam na 1ª entrada.
          // Para um salário aparecer na 2ª entrada, informe uma data com dia >= 20 (ex: 20/07).
          const dataRaw = document.getElementById("m-renda-data")?.value || "";
          // Normaliza para garantir formato YYYY-MM-DD sem influência de timezone
          const data = dataRaw ||
            new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
              .toISOString()
              .split("T")[0];
          if (!valor || valor <= 0) {
            this.toast("Digite o valor");
            return;
          }
          const separacoesRaw = Array.from(
            document.querySelectorAll(".m-sep-row"),
          )
            .map((row) => {
              const selVal =
                row.querySelector(".m-sep-nome-select")?.value || "";
              const nome =
                selVal === "_outro_"
                  ? row.querySelector(".m-sep-nome-custom")?.value?.trim() || ""
                  : selVal;
              const tipo = row.querySelector(".m-sep-tipo")?.value || "valor";
              const valorRaw =
                parseFloat(row.querySelector(".m-sep-valor")?.value || 0) || 0;
              return nome && valorRaw > 0
                ? { nome, tipo, valor: valorRaw }
                : null;
            })
            .filter(Boolean);
          this.saveSeparacaoSuggestions(
            separacoesRaw.map(function (s) {
              return s.nome;
            }),
          );
          // Resolve categoria de cada separação (pergunta se desconhecida)
          const _resolveAll = (seps, idx, result, done) => {
            if (idx >= seps.length) return done(result);
            this._resolveCategoriaSep(seps[idx].nome, (cat) => {
              result.push({ ...seps[idx], categoria: cat });
              _resolveAll(seps, idx + 1, result, done);
            });
          };
          _resolveAll(separacoesRaw, 0, [], (separacoes) => {
            const key = this.getActiveCycleKey();
            const ciclos = Store.get("ciclos") || {};
            if (!ciclos[key])
              ciclos[key] = { renda: 0, gastos: [], decisao: "", fontes: [] };
            if (!Array.isArray(ciclos[key].fontes)) ciclos[key].fontes = [];
            ciclos[key].fontes.push({ origem, valor, data, separacoes });
            ciclos[key].renda = Calc.rendaNoMes(ciclos[key]);
            Store.set("ciclos", ciclos);
            this.closeModal();
            this.toast("Entrada adicionada!");
            this.go(this.currentScreen);
          });
        },

        deleteEntrada(key, idx) {
          const ciclos = Store.get("ciclos") || {};
          const fontes = ciclos[key] && ciclos[key].fontes;
          const entrada = Array.isArray(fontes) ? fontes[idx] : null;
          const nome = entrada
            ? FarolHelpers.escapeHtml(entrada.origem || "Entrada")
            : "esta entrada";
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay-confirm";
          overlay.onclick = (e) => {
            if (e.target === overlay) overlay.remove();
          };
          const modal = document.createElement("div");
          modal.className = "modal";
          modal.style.cssText = "width:min(400px,92vw);";
          modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Excluir entrada</div><div class="modal-subtitle">Deseja realmente excluir <strong>${nome}</strong>?</div></div><button class="modal-close" onclick="this.closest('.overlay').remove()">×</button></div><div class="modal-actions"><button class="btn btn-ghost" onclick="this.closest('.overlay').remove()">Cancelar</button><button class="btn btn-danger" onclick="App.confirmDeleteEntrada('${key}',${idx})">Excluir</button></div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
        },

        confirmDeleteEntrada(key, idx) {
          document.getElementById("modal-overlay-confirm")?.remove();
          const ciclos = Store.get("ciclos") || {};
          if (ciclos[key] && Array.isArray(ciclos[key].fontes)) {
            ciclos[key].fontes.splice(idx, 1);
            ciclos[key].renda = Calc.rendaNoMes(ciclos[key]);
            Store.set("ciclos", ciclos);
          }
          this.closeModal();
          this.toast("Entrada excluída.");
          this.go(this.currentScreen);
        },

        addSeparacaoRow(data) {
          const list = document.getElementById("m-sep-list");
          if (!list) return;
          const tipos = this.getSeparacaoSuggestions();
          const nomeAtual = (data && data.nome) || "";
          const isOutro = nomeAtual && !tipos.includes(nomeAtual);
          const row = document.createElement("div");
          row.className = "m-sep-row";
          row.style.cssText =
            "display:grid;grid-template-columns:1.4fr .8fr .8fr auto;gap:8px;align-items:end;margin-bottom:10px;";
          row.innerHTML = `<div><label class="label">Tipo de separação</label><select class="form-select m-sep-nome-select" onchange="App.toggleSepNomeCustom(this)"><option value="">Selecione…</option>${tipos.map((t) => `<option value="${FarolHelpers.escapeHtml(t)}" ${t === nomeAtual ? "selected" : ""}>${FarolHelpers.escapeHtml(t)}</option>`).join("")}<option value="_outro_" ${isOutro ? "selected" : ""}>Outro…</option></select><input class="form-input m-sep-nome-custom mt-8 ${isOutro ? "" : "hidden"}" placeholder="Nome do tipo" value="${FarolHelpers.escapeHtml(isOutro ? nomeAtual : "")}"></div><div><label class="label">Forma</label><select class="form-select m-sep-tipo" onchange="App.updateRendaSeparationSummary()"><option value="valor" ${data && data.tipo === "percentual" ? "" : "selected"}>R$</option><option value="percentual" ${data && data.tipo === "percentual" ? "selected" : ""}>%</option></select></div><div><label class="label">Valor</label><input class="form-input m-sep-valor" type="number" min="0" step="0.01" placeholder="0,00" value="${data && data.valor ? data.valor : ""}" oninput="App.updateRendaSeparationSummary()"></div><button type="button" class="btn btn-danger btn-sm" onclick="this.parentElement.remove();App.updateRendaSeparationSummary()">×</button>`;
          list.appendChild(row);
          this.updateRendaSeparationSummary();
        },

        toggleSepNomeCustom(sel) {
          const row = sel.closest(".m-sep-row");
          const custom = row?.querySelector(".m-sep-nome-custom");
          if (!custom) return;
          custom.classList.toggle("hidden", sel.value !== "_outro_");
          if (sel.value === "_outro_") custom.focus();
        },

        // Versão genérica do toggle, por ID de elemento — usada no modal "Separar valor"
        toggleSepNomeCustomEl(sel, customId) {
          const custom = document.getElementById(customId);
          if (!custom) return;
          custom.classList.toggle("hidden", sel.value !== "_outro_");
          if (sel.value === "_outro_") custom.focus();
        },

        // Registra uma separação independente, vinculada ao mês (não a uma entrada específica)
        // Resolve a categoria de uma separação — se desconhecida, abre mini-modal para o usuário escolher
        _resolveCategoriaSep(nome, callback) {
          const n = nome.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
          if (["imposto", "tributo", "taxa"].includes(n)) return callback("imposto");
          if (["dízimo", "dizimo"].includes(n)) return callback("devolucao");
          if (["oferta", "ajuda familiar", "doação", "doacao"].includes(n))
            return callback("oferta");
          const mem = Store.get("categorias_separacao") || {};
          if (mem[n]) return callback(mem[n]);
          // Nome desconhecido — pergunta
          const overlay = document.createElement("div");
          overlay.style.cssText =
            "position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;";
          overlay.innerHTML = `
          <div style="background:var(--card-bg,#fff);border-radius:16px;padding:24px;max-width:320px;width:100%;">
            <div style="font-size:15px;font-weight:800;color:var(--navy);margin-bottom:6px;">"${FarolHelpers.escapeHtml(nome)}" é para…</div>
            <div style="font-size:13px;color:var(--grey);margin-bottom:16px;">O sistema vai lembrar sua escolha.</div>
            ${[
              {
                cat: "futuro",
                cor: "#0D8F6E",
                label: "Futuro",
                sub: "Investimento, reserva, poupança",
              },
            ]
              .map(
                (o) => `
              <button data-cat="${o.cat}" style="width:100%;display:flex;align-items:center;gap:12px;padding:12px;border:2px solid var(--grey-l);border-radius:10px;background:transparent;cursor:pointer;margin-bottom:8px;text-align:left;">
                <span style="width:10px;height:10px;border-radius:50%;background:${o.cor};flex-shrink:0;"></span>
                <div>
                  <div style="font-size:14px;font-weight:700;color:var(--navy);">${o.label}</div>
                  <div style="font-size:12px;color:var(--grey);">${o.sub}</div>
                </div>
              </button>`,
              )
              .join("")}
          </div>`;
          document.body.appendChild(overlay);
          overlay.querySelectorAll("button[data-cat]").forEach((btn) => {
            btn.addEventListener("click", () => {
              const cat = btn.dataset.cat;
              // Salva na memória
              const mem2 = Store.get("categorias_separacao") || {};
              mem2[n] = cat;
              Store.set("categorias_separacao", mem2);
              document.body.removeChild(overlay);
              callback(cat);
            });
          });
        },

        saveSeparacaoMes() {
          if (!this._beginSubmit("saveSeparacaoMes")) return;
          const selVal = document.getElementById("m-csep-select")?.value || "";
          const nome =
            selVal === "_outro_"
              ? document.getElementById("m-csep-custom")?.value?.trim() || ""
              : selVal;
          const valor = parseFloat(
            document.getElementById("m-csep-valor")?.value || 0,
          );
          const data = document.getElementById("m-csep-data")?.value;
          if (!nome) {
            this.toast("Selecione o tipo de separação");
            return;
          }
          if (!valor || valor <= 0) {
            this.toast("Digite o valor");
            return;
          }
          if (selVal === "_outro_") this.saveSeparacaoSuggestions([nome]);

          const key = this.getActiveCycleKey();
          const ciclos = Store.get("ciclos") || {};
          if (!ciclos[key])
            ciclos[key] = { renda: 0, gastos: [], decisao: "", fontes: [] };
          if (!Array.isArray(ciclos[key].separacoes))
            ciclos[key].separacoes = [];

          // Verifica se a categoria é conhecida; se não, pergunta antes de salvar
          const dataFinal =
            data ||
            new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
              .toISOString()
              .split("T")[0];
          this._resolveCategoriaSep(nome, (cat) => {
            ciclos[key].separacoes.push({
              nome,
              valor,
              data: dataFinal,
              categoria: cat,
            });
            Store.set("ciclos", ciclos);
            this.closeModal();
            this.toast("Valor separado!");
            this.go(this.currentScreen);
          });
        },

        deleteSeparacaoMes(key, idx) {
          const ciclos = Store.get("ciclos") || {};
          const c = ciclos[key];
          if (!c || !Array.isArray(c.separacoes) || !c.separacoes[idx]) return;
          c.separacoes.splice(idx, 1);
          Store.set("ciclos", ciclos);
          this.toast("Separação removida.");
          this.go(this.currentScreen);
        },

        updateRendaSeparationSummary() {
          const bruto =
            parseFloat(document.getElementById("m-renda-valor")?.value || 0) ||
            0;
          const total = Array.from(
            document.querySelectorAll(".m-sep-row"),
          ).reduce((s, row) => {
            const tipo = row.querySelector(".m-sep-tipo")?.value || "valor";
            const raw =
              parseFloat(row.querySelector(".m-sep-valor")?.value || 0) || 0;
            return s + (tipo === "percentual" ? bruto * (raw / 100) : raw);
          }, 0);
          const totalEl = document.getElementById("m-renda-sep-total");
          const baseEl = document.getElementById("m-renda-base");
          if (totalEl) totalEl.textContent = Calc.fmt(total);
          if (baseEl) baseEl.textContent = Calc.fmt(Math.max(0, bruto - total));
        },

        async saveObjetivo() {
          if (!this._beginSubmit("saveObjetivo")) return;
          const nome = document.getElementById("m-obj-nome")?.value?.trim();
          const valor = parseFloat(
            document.getElementById("m-obj-valor")?.value || 0,
          );
          const pago = parseFloat(
            document.getElementById("m-obj-pago")?.value || 0,
          );
          const prazo = document.getElementById("m-obj-prazo")?.value;
          const prio = document.getElementById("m-obj-prio")?.value || "media";

          if (!nome) {
            this.toast("Digite o nome");
            return;
          }
          if (!valor || valor <= 0) {
            this.toast("Digite o valor");
            return;
          }

          try {
            // Passo 1: Salvar localmente primeiro (para feedback imediato)
            const objs = Store.get("objetivos") || [];
            const novoObj = {
              nome,
              valor: valor, // Nota: renomeado de 'meta' para 'valor'
              valorPago: Math.max(pago, 0), // Nota: renomeado de 'atual' para 'valorPago'
              prazo: prazo ? `${prazo}-01` : "",
              prioridade: prio,
              concluido: false,
              order: objs.length, // Adicionar ordem
            };
            objs.push(novoObj);
            objs.sort(
              (a, b) =>
                ({ alta: 0, media: 1, baixa: 2 })[a.prioridade] -
                { alta: 0, media: 1, baixa: 2 }[b.prioridade],
            );
            Store.set("objetivos", objs);

            // Passo 2: Sincronizar com Supabase (se conectado)
            if (supa && CloudSync.session) {
              const wsId = Store.get("workspaceId");
              if (!wsId) {
                console.warn("workspace_id não encontrado");
                this.toast(
                  "⚠️ Objetivo salvo localmente (sem sincronização com servidor)",
                );
                this.closeModal();
                this.go("objetivos");
                return;
              }

              const { data: insertedObjs, error } = await supa
                .from("objetivos")
                .insert([
                  {
                    workspace_id: wsId,
                    nome: nome,
                    valor_meta: valor,
                    valor_atual: Math.max(pago, 0),
                    prazo: prazo ? `${prazo}-01` : null,
                    concluido: false,
                    prioridade: prio,
                    ordem: objs.length - 1,
                  },
                ])
                .select();

              if (error) {
                console.error("Erro ao salvar no Supabase:", error);
                this.toast(
                  "⚠️ Salvo localmente, erro ao sincronizar com servidor",
                );
              } else {
                // Guardar o ID retornado pelo banco para atualizações futuras
                if (insertedObjs && insertedObjs.length > 0) {
                  objs[objs.length - 1].id = insertedObjs[0].id;
                  Store.set("objetivos", objs);
                }
                this.toast("✅ Objetivo salvo com sucesso!");
              }
            } else {
              this.toast("Objetivo criado (modo offline)");
            }

            this.closeModal();
            this.go("objetivos");
          } catch (err) {
            console.error("Erro ao salvar objetivo:", err);
            this.toast(
              "❌ Erro ao salvar objetivo: " + (err.message || "desconhecido"),
            );
          }
        },

        deleteObj(idx) {
          const objs = Store.get("objetivos") || [];
          const obj = objs[idx];
          if (!obj) return;
          const nome = FarolHelpers.escapeHtml(obj.nome || "este objetivo");
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay-confirm";
          overlay.onclick = (e) => {
            if (e.target === overlay) overlay.remove();
          };
          const modal = document.createElement("div");
          modal.className = "modal";
          modal.style.cssText = "width:min(400px,92vw);";
          modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Excluir objetivo</div><div class="modal-subtitle">Deseja realmente excluir <strong>${nome}</strong>?</div></div><button class="modal-close" onclick="this.closest('.overlay').remove()">×</button></div><div class="modal-actions"><button class="btn btn-ghost" onclick="this.closest('.overlay').remove()">Cancelar</button><button class="btn btn-danger" onclick="App.confirmDeleteObj(${idx})">Excluir</button></div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
        },
        async confirmDeleteObj(idx) {
          document.getElementById("modal-overlay-confirm")?.remove();
          const objs = Store.get("objetivos") || [];
          const obj = objs[idx];

          if (!obj) return;

          try {
            // Deletar do Supabase se tiver ID
            if (supa && obj.id && CloudSync.session) {
              const wsId = Store.get("workspaceId");
              const { error } = await supa
                .from("objetivos")
                .delete()
                .eq("id", obj.id)
                .eq("workspace_id", wsId);

              if (error) {
                console.error("Erro ao deletar do banco:", error);
                this.toast("⚠️ Erro ao sincronizar com servidor");
                return;
              }
            }

            // Deletar localmente
            objs.splice(idx, 1);
            Store.set("objetivos", objs);
            this.toast("✅ Objetivo excluído.");
            this.go("objetivos");
          } catch (err) {
            console.error("Erro ao excluir objetivo:", err);
            this.toast("❌ Erro ao excluir");
          }
        },
        editObj(idx) {
          this.openGoalEditModal(idx);
        },

        addToObj(idx) {
          this.openGoalFundingModal(idx);
        },

        toggleParcelaCartaoField(val) {
          document
            .getElementById("m-p-cartao-wrap")
            ?.classList.toggle("hidden", val !== "cartao");
        },

        async saveParcela() {
          if (!this._beginSubmit("saveParcela")) return;
          const nome = document.getElementById("m-p-nome")?.value?.trim();
          const sub = document.getElementById("m-p-sub")?.value?.trim() || "";
          const dia = parseInt(
            document.getElementById("m-p-dia")?.value || "1",
            10,
          );
          const valor = parseFloat(
            document.getElementById("m-p-valor")?.value || 0,
          );
          const inicio = document.getElementById("m-p-inicio")?.value;
          const fim = document.getElementById("m-p-fim")?.value;
          const origem =
            document.getElementById("m-p-origem")?.value || "separado";
          const cartaoId =
            origem === "cartao"
              ? document.getElementById("m-p-cartao")?.value || ""
              : "";
          if (!nome) {
            this.toast("Digite o nome");
            return;
          }
          if (!valor || valor <= 0) {
            this.toast("Digite o valor");
            return;
          }
          if (!inicio || !fim) {
            this.toast("Informe início e término");
            return;
          }
          if (origem === "cartao" && !cartaoId) {
            this.toast("Selecione o cartão ou cadastre um em Cartões");
            return;
          }

          const dataInicio = inicio + "-01";
          const dataFim = fim + "-28";

          try {
            // Passo 1: salvar localmente primeiro (feedback imediato)
            const parcelas = Store.get("parcelas") || [];
            const novaParcela = {
              id: "p_" + Date.now(),
              nome,
              subcategoria: sub,
              diaVencimento: dia,
              valor,
              dataInicio,
              dataFim,
              origem,
              cartaoId,
            };
            parcelas.push(novaParcela);
            Store.set("parcelas", parcelas);

            // Passo 2: sincronizar com Supabase (se conectado)
            if (supa && CloudSync.session) {
              const wsId = Store.get("workspaceId");
              if (!wsId) {
                console.warn("workspace_id não encontrado");
                this.toast(
                  "⚠️ Parcela salva localmente (sem sincronização com servidor)",
                );
                this.closeModal();
                this.go("parcelas");
                return;
              }

              const { data: inserted, error } = await supa
                .from("parcelas")
                .insert([
                  {
                    workspace_id: wsId,
                    nome: nome,
                    descricao: nome,
                    subcategoria: sub,
                    valor_parcela: valor,
                    dia_vencimento: dia,
                    data_inicio: dataInicio,
                    data_fim: dataFim,
                    mes_inicio: inicio,
                    origem: origem,
                    cartao_id: origem === "cartao" ? cartaoId : null,
                    quitada: false,
                  },
                ])
                .select();

              if (error) {
                console.error("Erro ao salvar parcela no Supabase:", error);
                this.toast(
                  "⚠️ Salva localmente, erro ao sincronizar com servidor",
                );
              } else if (inserted && inserted.length > 0) {
                // Substitui o id local temporário pelo id real do banco
                const idx = parcelas.findIndex((p) => p.id === novaParcela.id);
                if (idx >= 0) {
                  const oldId = parcelas[idx].id;
                  const newId = inserted[0].id;
                  parcelas[idx].id = newId;
                  Store.set("parcelas", parcelas);

                  // Atualiza o templateId de gastos já gerados nos ciclos
                  // (gerados com o id temporário) para o id real do banco —
                  // senão, na próxima renderização syncRecurring não reconhece
                  // o templateId antigo e gera um gasto duplicado.
                  const oldTid = `parcela:${oldId}`;
                  const newTid = `parcela:${newId}`;
                  const ciclos = Store.get("ciclos") || {};
                  Object.keys(ciclos).forEach((k) => {
                    const c = ciclos[k];
                    if (c && Array.isArray(c.gastos)) {
                      c.gastos.forEach((g) => {
                        if (g.templateId === oldTid) g.templateId = newTid;
                      });
                    }
                  });
                  Store.set("ciclos", ciclos);
                }
                this.toast("✅ Parcela registrada!");
              }
            } else {
              this.toast("Parcela registrada (modo offline)");
            }

            this.closeModal();
            this.go("parcelas");
          } catch (err) {
            console.error("Erro ao salvar parcela:", err);
            this.toast(
              "❌ Erro ao salvar parcela: " + (err.message || "desconhecido"),
            );
          }
        },

        deleteParcela(idx) {
          this.openParcelaDeleteModal(idx);
        },

        openParcelaDeleteModal(idx) {
          const p = Store.get("parcelas") || [];
          const parcela = p[idx];
          if (!parcela) {
            this.toast("Parcela não encontrada");
            return;
          }
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay";
          overlay.onclick = (e) => {
            if (e.target === overlay) this.closeModal();
          };
          const modal = document.createElement("div");
          modal.className = "modal";
          const key = this.getActiveCycleKey();
          modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Excluir parcela</div><div class="modal-subtitle">Como deseja excluir "${FarolHelpers.escapeHtml(parcela.nome)}"?</div></div><button class="modal-close" onclick="App.closeModal()">×</button></div>
        <div style="padding:22px 28px 10px;">
          <div class="structural-list">
            <div class="structural-pill"><div><strong>Somente neste mês</strong><span><br>Remove a cobrança de ${FarolHelpers.monthLabelByKey(key)} e preserva os demais meses.</span></div></div>
            <div class="structural-pill"><div><strong>Excluir do cadastro inteiro</strong><span><br>Remove a parcela de todos os meses e do histórico.</span></div></div>
          </div>
        </div>
        <div class="modal-actions">
          <button class="btn btn-ghost" onclick="App.closeModal()">Cancelar</button>
          <button class="btn btn-outline" onclick="App.confirmParcelaDelete(${idx},'once')">Só este mês</button>
          <button class="btn btn-danger" onclick="App.confirmParcelaDelete(${idx},'all')">Excluir tudo</button>
        </div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
        },

        async confirmParcelaDelete(idx, scope) {
          const p = Store.get("parcelas") || [];
          const parcela = p[idx];
          if (!parcela) {
            this.closeModal();
            return;
          }
          const key = this.getActiveCycleKey();

          if (scope === "once") {
            // "Só este mês": adiciona o mês ao skipMonths e atualiza no banco
            parcela.skipMonths = Array.from(
              new Set([...(parcela.skipMonths || []), key]),
            );
            Store.set("parcelas", p);
            const ciclos = Store.get("ciclos") || {};
            const c = ciclos[key];
            const tid = `parcela:${parcela.id}`;
            if (c && c.gastos)
              c.gastos = c.gastos.filter((g) => g.templateId !== tid);
            Store.set("ciclos", ciclos);

            // Persiste skipMonths no banco (se o id não for temporário local)
            if (
              supa &&
              CloudSync.session &&
              parcela.id &&
              !String(parcela.id).startsWith("p_")
            ) {
              const wsId = Store.get("workspaceId");
              const { error } = await supa
                .from("parcelas")
                .update({ skip_months: parcela.skipMonths })
                .eq("id", parcela.id)
                .eq("workspace_id", wsId);
              if (error)
                console.error("Erro ao atualizar skipMonths no banco:", error);
            }

            this.closeModal();
            this.toast("Removido apenas neste mês.");
            this.go("parcelas");
            return;
          }

          // "Excluir tudo": remove do banco e do Store local
          const tid = `parcela:${parcela.id}`;

          if (
            supa &&
            CloudSync.session &&
            parcela.id &&
            !String(parcela.id).startsWith("p_")
          ) {
            const wsId = Store.get("workspaceId");
            const { error } = await supa
              .from("parcelas")
              .delete()
              .eq("id", parcela.id)
              .eq("workspace_id", wsId);
            if (error)
              console.error("Erro ao excluir parcela do banco:", error);
          }

          p.splice(idx, 1);
          Store.set("parcelas", p);
          const ciclos = Store.get("ciclos") || {};
          Object.keys(ciclos).forEach((k) => {
            const c = ciclos[k];
            if (c && c.gastos)
              c.gastos = c.gastos.filter((g) => g.templateId !== tid);
          });
          Store.set("ciclos", ciclos);
          this.closeModal();
          this.toast("✅ Parcela excluída do cadastro.");
          this.go("parcelas");
        },

        openParcelMonthDeleteModal(key, idx, gasto) {
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay";
          overlay.onclick = (e) => {
            if (e.target === overlay) this.closeModal();
          };
          const modal = document.createElement("div");
          modal.className = "modal";
          modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Excluir parcela recorrente</div><div class="modal-subtitle">Escolha o alcance para "${FarolHelpers.escapeHtml(gasto.descricao)}".</div></div><button class="modal-close" onclick="App.closeModal()">×</button></div>
        <div style="padding:22px 28px 10px;">
          <div class="structural-list">
            <div class="structural-pill"><div><strong>Somente este mês</strong><span><br>Remove apenas a ocorrência de ${FarolHelpers.monthLabelByKey(key)} e preserva os demais meses.</span></div></div>
            <div class="structural-pill"><div><strong>Excluir do cadastro inteiro</strong><span><br>Remove a parcela de todos os meses e do histórico.</span></div></div>
          </div>
        </div>
        <div class="modal-actions">
          <button class="btn btn-ghost" onclick="App.closeModal()">Cancelar</button>
          <button class="btn btn-outline" onclick="App.confirmParcelMonthDelete('${key}',${idx},'once')">Só este mês</button>
          <button class="btn btn-danger" onclick="App.confirmParcelMonthDelete('${key}',${idx},'all')">Excluir tudo</button>
        </div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
        },

        confirmParcelMonthDelete(key, idx, scope) {
          const ciclos = Store.get("ciclos") || {};
          const c = ciclos[key];
          if (!c || !c.gastos || !c.gastos[idx]) {
            this.closeModal();
            return;
          }
          const g = c.gastos[idx];
          const tid = g.templateId;
          const parcelaId =
            tid && tid.startsWith("parcela:")
              ? tid.replace("parcela:", "")
              : null;
          if (scope === "once") {
            c.gastos.splice(idx, 1);
            Store.set("ciclos", ciclos);
            if (parcelaId) {
              const p = Store.get("parcelas") || [];
              const parcela = p.find((x) => x.id === parcelaId);
              if (parcela) {
                parcela.skipMonths = Array.from(
                  new Set([...(parcela.skipMonths || []), key]),
                );
                Store.set("parcelas", p);
              }
            }
            this.closeModal();
            this.toast("Removido apenas neste mês.");
            this.go(this.currentScreen);
            return;
          }
          if (parcelaId) {
            const p = Store.get("parcelas") || [];
            const pIdx = p.findIndex((x) => x.id === parcelaId);
            if (pIdx >= 0) {
              p.splice(pIdx, 1);
              Store.set("parcelas", p);
            }
            Object.keys(ciclos).forEach((k) => {
              const ciclo = ciclos[k];
              if (ciclo && ciclo.gastos)
                ciclo.gastos = ciclo.gastos.filter((x) => x.templateId !== tid);
            });
            Store.set("ciclos", ciclos);
          }
          // tratar parcelado_fixo (templateId começa com pfx_)
          if (tid && tid.startsWith("pfx_")) {
            const fixos = Store.get("gastosFixos") || [];
            const nFixos = fixos.filter((t) => t.id !== tid);
            Store.set("gastosFixos", nFixos);
            Object.keys(ciclos).forEach((k) => {
              const ciclo = ciclos[k];
              if (ciclo && ciclo.gastos)
                ciclo.gastos = ciclo.gastos.filter((x) => x.templateId !== tid);
            });
            Store.set("ciclos", ciclos);
          }
          this.closeModal();
          this.toast("Parcelamento excluído.");
          this.go(this.currentScreen);
        },

        async saveRecebimento() {
          if (!this._beginSubmit("saveRecebimento")) return;
          const nome = document.getElementById("m-r-nome")?.value?.trim();
          const tipo = document.getElementById("m-r-tipo")?.value || "fixo";
          const dia = parseInt(
            document.getElementById("m-r-dia")?.value || "1",
            10,
          );
          const valor = parseFloat(
            document.getElementById("m-r-valor")?.value || 0,
          );

          if (!nome) {
            this.toast("Digite o nome");
            return;
          }

          if (tipo !== "extra" && (!dia || dia < 1 || dia > 31)) {
            this.toast("Informe um dia de recebimento válido.");
            return;
          }

          const recs = Store.get("recebimentos") || [];
          recs.push({
            id:
              "r" +
              Date.now().toString(36) +
              Math.random().toString(36).slice(2, 5),
            nome,
            tipo,
            dia: tipo === "extra" ? null : dia,
            valor: isNaN(valor) ? 0 : valor,
            criadoEm: new Date().toISOString(),
            atualizadoEm: new Date().toISOString(),
          });

          Store.set("recebimentos", recs);

          // Força sincronização imediata para não perder o cadastro ao atualizar a página.
          if (window.CloudSync && CloudSync.status === "connected") {
            const result = await CloudSync.push();
            if (!result?.ok) {
              this.toast("Recebimento salvo na tela, mas ainda não sincronizou.");
            }
          }

          this.closeModal();
          this.toast("Recebimento cadastrado!");
          this.go("recebimentos");
        },

        deleteRecebimento(idx) {
          const recs = Store.get("recebimentos") || [];
          const rec = recs[idx];
          if (!rec) return;
          const nome = FarolHelpers.escapeHtml(rec.nome || "este recebimento");
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay-confirm";
          overlay.onclick = (e) => {
            if (e.target === overlay) overlay.remove();
          };
          const modal = document.createElement("div");
          modal.className = "modal";
          modal.style.cssText = "width:min(400px,92vw);";
          modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Excluir recebimento</div><div class="modal-subtitle">Deseja excluir <strong>${nome}</strong>?</div></div><button class="modal-close" onclick="this.closest('.overlay').remove()">×</button></div><div class="modal-actions"><button class="btn btn-ghost" onclick="this.closest('.overlay').remove()">Cancelar</button><button class="btn btn-danger" onclick="App.confirmDeleteRecebimento(${idx})">Excluir</button></div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
        },
        async confirmDeleteRecebimento(idx) {
          document.getElementById("modal-overlay-confirm")?.remove();
          const r = Store.get("recebimentos") || [];
          r.splice(idx, 1);
          Store.set("recebimentos", r);

          // Força sincronização imediata para refletir a exclusão no banco.
          if (window.CloudSync && CloudSync.status === "connected") {
            await CloudSync.push();
          }

          this.toast("Recebimento excluído.");
          this.go("recebimentos");
        },

        // ─── CARTÕES DE CRÉDITO ──────────────────────────────────
        async saveCartao() {
          if (!this._beginSubmit("saveCartao")) return;
          const idxRaw = document.getElementById("m-cart-idx")?.value;
          const idx =
            idxRaw !== "" && idxRaw != null ? parseInt(idxRaw, 10) : null;
          const nome =
            document.getElementById("m-cart-nome")?.value?.trim() || "Cartão";
          const dataVencimento = document.getElementById("m-cart-vencimento")?.value || "";
          const faturaAtual =
            parseFloat(
              document.getElementById("m-cart-inicial")?.value || 0,
            ) || 0;
          const parseData = (iso) => {
            const [y, m, d] = (iso || "").split("-").map(Number);
            if (!y || !m || !d) return null;
            const dt = new Date(y, m - 1, d);
            return isNaN(dt) ? null : dt;
          };
          const vencimentoDt = parseData(dataVencimento);

          if (!vencimentoDt) {
            this.toast("Informe o vencimento da fatura");
            return;
          }
          const diaVencimento = vencimentoDt.getDate();
          // dataFechamento/diaFechamento mantidos só por compatibilidade com
          // dados antigos e telas que ainda leem esses campos — o MVP não pede
          // fechamento ao usuário, então usamos a mesma data do vencimento.
          const dataFechamento = dataVencimento;
          const diaFechamento = diaVencimento;

          const cartoes = Store.get("cartoes") || [];

          if (idx !== null && cartoes[idx]) {
            cartoes[idx] = {
              ...cartoes[idx],
              nome,
              dataFechamento,
              dataVencimento,
              diaFechamento,
              diaVencimento,
              faturaAtual,
              faturaStatus: faturaAtual > 0 ? (cartoes[idx].faturaStatus || "aberta") : "paga",
            };
          } else {
            const novo = {
              id:
                "c" +
                Date.now().toString(36) +
                Math.random().toString(36).slice(2, 5),
              nome,
              dataFechamento,
              dataVencimento,
              // Mantidos para compatibilidade com telas/cálculos antigos e dados já salvos.
              diaFechamento,
              diaVencimento,
              faturaAtual,
              faturaStatus: faturaAtual > 0 ? "aberta" : "paga",
              historico:
                faturaAtual > 0
                  ? [
                      {
                        data: new Date(
                          Date.now() - new Date().getTimezoneOffset() * 60000,
                        )
                          .toISOString()
                          .split("T")[0],
                        valorAnterior: 0,
                        valorNovo: faturaAtual,
                        diferenca: faturaAtual,
                      },
                    ]
                  : [],
              faturasFechadas: [],
            };
            cartoes.push(novo);
          }
          Store.set("cartoes", cartoes);

          // Importante:
          // Store.set() agenda sincronização em nuvem, mas se o usuário atualizar
          // a página imediatamente, o pull() pode trazer o valor antigo do banco.
          // Por isso, no cadastro/edição de cartão fazemos um push imediato.
          if (window.CloudSync && CloudSync.status === "connected") {
            const result = await CloudSync.push();
            if (!result?.ok) {
              this.toast("Cartão salvo na tela, mas ainda não sincronizou.");
            }
          }

          this.closeModal();
          this.toast(
            idx !== null ? "Cartão atualizado!" : "Cartão cadastrado!",
          );
          this.go("cartoes");
        },

        deleteCartao(idx) {
          const cartoes = Store.get("cartoes") || [];
          const c = cartoes[idx];
          if (!c) return;
          const nome = FarolHelpers.escapeHtml(c.nome || "este cartão");
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay-confirm";
          overlay.onclick = (e) => {
            if (e.target === overlay) overlay.remove();
          };
          const modal = document.createElement("div");
          modal.className = "modal";
          modal.style.cssText = "width:min(400px,92vw);";
          modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Excluir cartão</div><div class="modal-subtitle">Deseja excluir <strong>${nome}</strong>? O histórico de atualizações será perdido.</div></div><button class="modal-close" onclick="this.closest('.overlay').remove()">×</button></div><div class="modal-actions"><button class="btn btn-ghost" onclick="this.closest('.overlay').remove()">Cancelar</button><button class="btn btn-danger" onclick="App.confirmDeleteCartao(${idx})">Excluir</button></div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
        },
        confirmDeleteCartao(idx) {
          document.getElementById("modal-overlay-confirm")?.remove();
          const cartoes = Store.get("cartoes") || [];
          cartoes.splice(idx, 1);
          Store.set("cartoes", cartoes);
          this.toast("Cartão excluído.");
          this.go("cartoes");
        },

        saveFaturaUpdate() {
          if (!this._beginSubmit("saveFaturaUpdate")) return;
          const idx = parseInt(
            document.getElementById("m-fat-idx")?.value || "-1",
            10,
          );
          const novoValor = parseFloat(
            document.getElementById("m-fat-valor")?.value || 0,
          );
          if (isNaN(novoValor) || novoValor < 0) {
            this.toast("Digite um valor válido");
            return;
          }
          const cartoes = Store.get("cartoes") || [];
          const c = cartoes[idx];
          if (!c) return;
          const valorAnterior = c.faturaAtual || 0;
          const diferenca = novoValor - valorAnterior;
          if (!Array.isArray(c.historico)) c.historico = [];
          c.historico.push({
            data: new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
              .toISOString()
              .split("T")[0],
            valorAnterior,
            valorNovo: novoValor,
            diferenca,
          });
          c.faturaAtual = novoValor;
          c.faturaStatus = novoValor > 0 ? "aberta" : "paga";
          if (c.faturaVencimento) c.faturaVencimento.valor = novoValor;
          cartoes[idx] = c;
          Store.set("cartoes", cartoes);
          this.closeModal();
          this.toast("Fatura atualizada!");
          this.go("cartoes");
        },

        saveFaturaVencimento() {
          if (!this._beginSubmit("saveFaturaVencimento")) return;
          const idx = parseInt(
            document.getElementById("m-prev-idx")?.value || "-1",
            10,
          );
          const valor = parseFloat(
            document.getElementById("m-prev-valor")?.value || 0,
          );
          const data = document.getElementById("m-prev-data")?.value;
          if (!data) {
            this.toast("Informe a data de vencimento");
            return;
          }
          if (isNaN(valor) || valor <= 0) {
            this.toast("Digite um valor válido");
            return;
          }
          const cartoes = Store.get("cartoes") || [];
          const c = cartoes[idx];
          if (!c) return;
          c.faturaVencimento = { data, valor };
          c.faturaAtual = valor;
          c.faturaStatus = "fechada";
          this._upsertLancamentoFatura(c, valor, data, false);
          cartoes[idx] = c;
          Store.set("cartoes", cartoes);
          CloudSync.scheduleSync();
          this.closeModal();
          this.toast("✅ Fatura lançada!");
          this.go("cartoes");
        },

        clearFaturaVencimento(idx) {
          const cartoes = Store.get("cartoes") || [];
          const c = cartoes[idx];
          if (!c) return;
          c.faturaVencimento = null;
          c.faturaStatus = (parseFloat(c.faturaAtual) || 0) > 0 ? "aberta" : "paga";
          cartoes[idx] = c;
          Store.set("cartoes", cartoes);
          CloudSync.scheduleSync();
          this.closeModal();
          this.toast("Lançamento removido");
          this.go("cartoes");
        },

        // Confirma o fechamento da fatura: registra o valor como gasto do mês
        // (lançamento de saída sem categoria) e zera a fatura para o próximo ciclo
        confirmarFechamentoFatura(idx) {
          if (!this._beginSubmit("confirmarFechamentoFatura")) return;
          const cartoes = Store.get("cartoes") || [];
          const c = cartoes[idx];
          if (!c) return;
          const valor = c.faturaAtual || 0;
          const now = new Date();
          const key = `${now.getFullYear()}-${now.getMonth()}`;
          const dataStr = new Date(Date.now() - now.getTimezoneOffset() * 60000)
            .toISOString()
            .split("T")[0];
          // Data de vencimento da fatura: usa a data completa do cartão quando existir.
          // Se o cartão for antigo, cai no cálculo mensal pelo dia de vencimento.
          const vencimentoDate = FarolHelpers.proximoVencimento(c, now);
          const vencimentoStr = FarolHelpers._dateToISO
            ? FarolHelpers._dateToISO(vencimentoDate)
            : `${vencimentoDate.getFullYear()}-${String(vencimentoDate.getMonth() + 1).padStart(2, "0")}-${String(vencimentoDate.getDate()).padStart(2, "0")}`;

          // Registra como gasto do mês (categoria oculta — modo simples não exibe categorias)
          const ciclos = Store.get("ciclos") || {};
          if (!ciclos[key])
            ciclos[key] = { renda: 0, gastos: [], decisao: "", fontes: [] };
          if (!Array.isArray(ciclos[key].gastos)) ciclos[key].gastos = [];
          if (valor > 0) {
            ciclos[key].gastos.push({
              descricao: `Fatura ${c.nome}`,
              valor,
              categoria: "V",
              data: vencimentoStr,
              pago: false,
              origem: "cartao",
              cartaoId: c.id,
            });
          }
          Store.set("ciclos", ciclos);

          // Marca a fatura como fechada e zera o acumulado
          if (!Array.isArray(c.faturasFechadas)) c.faturasFechadas = [];
          c.faturasFechadas.push({ mesRef: key, valor, fechadaEm: dataStr });
          if (!Array.isArray(c.historico)) c.historico = [];
          if (valor > 0) {
            c.historico.push({
              data: dataStr,
              valorAnterior: valor,
              valorNovo: 0,
              diferenca: -valor,
              fechamento: true,
            });
          }
          c.faturaAtual = 0;
          cartoes[idx] = c;
          Store.set("cartoes", cartoes);

          this.toast("Fatura fechada e registrada como gasto do mês!");
          this.go("cartoes");
        },

        _cartaoVencimentoISO(c) {
          if (c && c.dataVencimento) return c.dataVencimento;
          const dia = Math.min(Math.max(parseInt((c && c.diaVencimento) || 1, 10), 1), 28);
          const hoje = new Date();
          return `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, "0")}-${String(dia).padStart(2, "0")}`;
        },

        _cicloKeyFromISO(data) {
          const [y, m] = String(data || "").split("-").map(Number);
          if (!y || !m) return Calc.cicloAtual();
          return Calc.mesKey(y, m - 1);
        },

        _upsertLancamentoFatura(c, valor, data, pago) {
          const ciclos = Store.get("ciclos") || {};
          const key = this._cicloKeyFromISO(data);
          if (!ciclos[key]) ciclos[key] = { renda: 0, gastos: [], decisao: "", fontes: [] };
          if (!Array.isArray(ciclos[key].gastos)) ciclos[key].gastos = [];
          const faturaId = `fat_${c.id}_${String(data || "").slice(0, 7)}`;
          const descFatura = `Fatura ${c.nome || "Cartão"}`;
          const existente = ciclos[key].gastos.findIndex((g) => {
            if (!g || g.origem !== "cartao") return false;
            const mesmoId = g.faturaId === faturaId || (c.id && g.cartaoId === c.id);
            const mesmaDescricao = String(g.descricao || "").trim().toLowerCase() === descFatura.trim().toLowerCase();
            const mesmoMes = String(g.data || "").slice(0, 7) === String(data || "").slice(0, 7);
            return mesmoMes && (mesmoId || mesmaDescricao);
          });
          const lanc = {
            descricao: descFatura,
            valor,
            categoria: "V",
            data,
            pago: !!pago,
            status: pago ? "pago" : "fechada",
            origem: "cartao",
            cartaoId: c.id,
            faturaId,
          };
          if (existente >= 0) ciclos[key].gastos[existente] = { ...ciclos[key].gastos[existente], ...lanc };
          else ciclos[key].gastos.push(lanc);
          Store.set("ciclos", ciclos);
          return { key, faturaId };
        },

        fecharFatura(idx) {
          if (!this._beginSubmit("fecharFatura")) return;
          const cartoes = Store.get("cartoes") || [];
          const c = cartoes[idx];
          if (!c) return;
          const valor = parseFloat((c.faturaVencimento && c.faturaVencimento.valor) || c.faturaAtual || 0) || 0;
          const data = (c.faturaVencimento && c.faturaVencimento.data) || this._cartaoVencimentoISO(c);
          if (!valor || valor <= 0) {
            this.toast("Informe o valor da fatura antes de fechar.");
            this.openModal("faturaUpdate", idx);
            return;
          }
          c.faturaVencimento = { data, valor };
          c.faturaStatus = "fechada";
          if (!Array.isArray(c.faturasFechadas)) c.faturasFechadas = [];
          const mesRef = String(data).slice(0, 7);
          const ja = c.faturasFechadas.findIndex((f) => f.mesRef === mesRef);
          const reg = { mesRef, valor, data, fechadaEm: new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().split("T")[0] };
          if (ja >= 0) c.faturasFechadas[ja] = reg; else c.faturasFechadas.push(reg);
          this._upsertLancamentoFatura(c, valor, data, false);
          cartoes[idx] = c;
          Store.set("cartoes", cartoes);
          if (window.CloudSync) CloudSync.scheduleSync();
          this.toast("Fatura fechada e lançada no Meu Mês.");
          this.go(this.currentScreen === "dashboard" ? "dashboard" : "cartoes");
        },

        pagarFatura(idx) {
          if (!this._beginSubmit("pagarFatura")) return;
          const cartoes = Store.get("cartoes") || [];
          const c = cartoes[idx];
          if (!c) return;
          const valor = parseFloat((c.faturaVencimento && c.faturaVencimento.valor) || c.faturaAtual || 0) || 0;
          const data = (c.faturaVencimento && c.faturaVencimento.data) || this._cartaoVencimentoISO(c);
          if (!valor || valor <= 0) {
            this.toast("Não há fatura para pagar.");
            return;
          }
          this._upsertLancamentoFatura(c, valor, data, true);
          c.faturaStatus = "paga";
          c.ultimaFaturaPaga = { data, valor, pagaEm: new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().split("T")[0] };
          c.faturaAtual = 0;
          c.faturaVencimento = null;
          if (!Array.isArray(c.historico)) c.historico = [];
          c.historico.push({ data: c.ultimaFaturaPaga.pagaEm, valorAnterior: valor, valorNovo: 0, diferenca: -valor, pagamento: true });
          cartoes[idx] = c;
          Store.set("cartoes", cartoes);
          if (window.CloudSync) CloudSync.scheduleSync();
          this.toast("Fatura marcada como paga.");
          this.go(this.currentScreen === "dashboard" ? "dashboard" : "cartoes");
        },

        saveDecisao() {
          const t = document.getElementById("decisao-text")?.value || "";
          const key = App.getActiveCycleKey
            ? App.getActiveCycleKey()
            : Calc.cicloAtual();
          const ciclos = Store.get("ciclos") || {};
          if (!ciclos[key])
            ciclos[key] = { renda: 0, gastos: [], decisao: "", fontes: [] };
          ciclos[key].decisao = t;
          Store.set("ciclos", ciclos);
          this.toast("Decisão salva!");
          this.go("decisao");
        },

        // ── ADMIN ────────────────────────────────────────────────────
        _adminUsers: [],

        async loadAdmin() {
          if (!supa || !CloudSync.isAdmin()) return;
          // Usa RPC para buscar todos os profiles (bypassa RLS via security definer)
          const { data: profiles, error } = await supa.rpc(
            "admin_get_all_profiles",
          );
          if (error) {
            console.error("[admin] erro ao buscar profiles:", error);
            const el = document.getElementById("admin-users-list");
            if (el)
              el.innerHTML = `<div style="color:var(--red);font-size:13px;padding:12px;">Erro: ${error.message}</div>`;
            return;
          }
          if (!profiles) return;
          this._adminUsers = profiles;
          this._renderAdminStats(profiles);
          this._renderAdminUsers(profiles);
        },

        _renderAdminStats(profiles) {
          const now = new Date();
          const in7 = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
          const ativos = profiles.filter(
            (p) => p.status === "ativo" && p.plano === "ativo",
          ).length;
          const trial = profiles.filter(
            (p) => p.plano === "free" && p.status === "ativo",
          ).length;
          const expirando = profiles.filter((p) => {
            if (!p.trial_expires_at) return false;
            const exp = new Date(p.trial_expires_at);
            return exp > now && exp <= in7;
          }).length;
          const el = (id, v) => {
            const e = document.getElementById(id);
            if (e) e.textContent = v;
          };
          el("admin-total", profiles.length);
          el("admin-ativos", ativos);
          el("admin-trial", trial);
          el("admin-expirando", expirando);
        },

        _renderAdminUsers(profiles) {
          const el = document.getElementById("admin-users-list");
          if (!el) return;
          if (!profiles.length) {
            el.innerHTML =
              '<div style="text-align:center;padding:20px;color:var(--grey);font-size:13px;">Nenhum usuário encontrado.</div>';
            return;
          }
          const now = new Date();
          el.innerHTML = profiles
            .map((p) => {
              const exp = p.trial_expires_at
                ? new Date(p.trial_expires_at)
                : null;
              const diasRestantes = exp
                ? Math.ceil((exp - now) / (1000 * 60 * 60 * 24))
                : null;
              const statusColor =
                p.status === "ativo"
                  ? "var(--green)"
                  : p.status === "suspenso"
                    ? "var(--amber)"
                    : "var(--red)";
              const planoLabel =
                p.plano === "ativo"
                  ? "Pago"
                  : p.plano === "free"
                    ? `Trial${diasRestantes !== null ? ` (${diasRestantes}d)` : ""}`
                    : p.plano;
              return `<div style="padding:12px 0;border-bottom:1px solid var(--grey-xl);" data-email="${(p.email || "").toLowerCase()}" data-status="${p.plano || "free"}">
            <div class="flex justify-between items-start" style="gap:8px;">
              <div style="flex:1;min-width:0;">
                <div style="font-size:13px;font-weight:700;color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${FarolHelpers.escapeHtml(p.nome || "—")}</div>
                <div style="font-size:11px;color:var(--grey);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${FarolHelpers.escapeHtml(p.email || "—")}</div>
                <div style="font-size:11px;color:var(--grey);margin-top:2px;">Cadastro: ${p.criado_em ? new Date(p.criado_em).toLocaleDateString("pt-BR") : "—"}</div>
              </div>
              <div style="text-align:right;flex-shrink:0;">
                <div style="font-size:11px;font-weight:700;color:${statusColor};">${p.status?.toUpperCase() || "—"}</div>
                <div style="font-size:11px;color:var(--grey);">${planoLabel}</div>
              </div>
            </div>
            <div class="flex gap-6" style="margin-top:8px;flex-wrap:wrap;">
              <button onclick="App.adminExtendTrial('${p.id}',30)" style="font-size:11px;padding:4px 8px;background:var(--teal);color:#fff;border:none;border-radius:6px;cursor:pointer;">+30 dias</button>
              <button onclick="App.adminExtendTrial('${p.id}',90)" style="font-size:11px;padding:4px 8px;background:var(--teal);color:#fff;border:none;border-radius:6px;cursor:pointer;">+90 dias</button>
              <button onclick="App.adminSetPlan('${p.id}','ativo')" style="font-size:11px;padding:4px 8px;background:var(--green);color:#fff;border:none;border-radius:6px;cursor:pointer;">Ativar</button>
              <button onclick="App.adminToggleSuspend('${p.id}','${p.status}')" style="font-size:11px;padding:4px 8px;background:${p.status === "suspenso" ? "var(--green)" : "var(--amber)"};color:#fff;border:none;border-radius:6px;cursor:pointer;">${p.status === "suspenso" ? "Reativar" : "Suspender"}</button>
              <button onclick="App.adminDeleteUser('${p.id}','${FarolHelpers.escapeHtml(p.email || "")}')" style="font-size:11px;padding:4px 8px;background:var(--red);color:#fff;border:none;border-radius:6px;cursor:pointer;">Excluir</button>
            </div>
          </div>`;
            })
            .join("");
        },

        adminFilter() {
          const search = (
            document.getElementById("admin-search")?.value || ""
          ).toLowerCase();
          const status =
            document.getElementById("admin-filter-status")?.value || "";
          let filtered = this._adminUsers;
          if (search)
            filtered = filtered.filter(
              (p) =>
                (p.email || "").toLowerCase().includes(search) ||
                (p.nome || "").toLowerCase().includes(search),
            );
          if (status) filtered = filtered.filter((p) => p.plano === status);
          this._renderAdminUsers(filtered);
          this._renderAdminStats(filtered);
        },

        async adminExtendTrial(userId, days) {
          const { data: prof } = await supa
            .from("profiles")
            .select("trial_expires_at")
            .eq("id", userId)
            .single();
          const base = prof?.trial_expires_at
            ? new Date(prof.trial_expires_at)
            : new Date();
          if (base < new Date()) base.setTime(new Date().getTime());
          base.setDate(base.getDate() + days);
          const { data: updated, error } = await supa
            .from("profiles")
            .update({ trial_expires_at: base.toISOString() })
            .eq("id", userId)
            .select("id");
          if (error) {
            this.toast("Erro ao estender trial: " + error.message);
            return;
          }
          if (!updated || updated.length === 0) {
            this.toast(
              "Nada foi alterado (provável bloqueio de permissão/RLS no banco).",
            );
            return;
          }
          this.toast(`Trial estendido por ${days} dias!`);
          setTimeout(() => this.loadAdmin(), 500);
        },

        async adminSetPlan(userId, plano) {
          const { data: updated, error } = await supa
            .from("profiles")
            .update({ plano, status: "ativo" })
            .eq("id", userId)
            .select("id");
          if (error) {
            this.toast("Erro ao atualizar plano: " + error.message);
            return;
          }
          if (!updated || updated.length === 0) {
            this.toast(
              "Nada foi alterado (provável bloqueio de permissão/RLS no banco).",
            );
            return;
          }
          this.toast("Plano atualizado!");
          setTimeout(() => this.loadAdmin(), 500);
        },

        async adminToggleSuspend(userId, currentStatus) {
          const newStatus = currentStatus === "suspenso" ? "ativo" : "suspenso";
          const { data: updated, error } = await supa
            .from("profiles")
            .update({ status: newStatus })
            .eq("id", userId)
            .select("id");
          if (error) {
            this.toast("Erro: " + error.message);
            return;
          }
          if (!updated || updated.length === 0) {
            this.toast(
              "Nada foi alterado (provável bloqueio de permissão/RLS no banco).",
            );
            return;
          }
          this.toast(
            newStatus === "suspenso"
              ? "Usuário suspenso."
              : "Usuário reativado!",
          );
          setTimeout(() => this.loadAdmin(), 500);
        },

        async adminDeleteUser(userId, email) {
          if (
            !confirm(
              `Excluir permanentemente o usuário ${email}? Todos os dados serão apagados.`,
            )
          )
            return;
          // Apaga dados do workspace do usuário
          const { data: ws } = await supa
            .from("workspaces")
            .select("id")
            .eq("owner_id", userId)
            .maybeSingle();
          if (ws) {
            await supa.from("gastos").delete().eq("workspace_id", ws.id);
            await supa.from("entradas").delete().eq("workspace_id", ws.id);
            await supa
              .from("separacoes_mes")
              .delete()
              .eq("workspace_id", ws.id);
            await supa.from("ciclos").delete().eq("workspace_id", ws.id);
            await supa.from("gastos_fixos").delete().eq("user_id", userId);
            await supa
              .from("workspace_members")
              .delete()
              .eq("workspace_id", ws.id);
            await supa.from("workspaces").delete().eq("id", ws.id);
          }
          await supa.from("profiles").delete().eq("id", userId);
          this.toast("Usuário excluído.");
          setTimeout(() => this.loadAdmin(), 500);
        },

        async redefinirSenha() {
          if (!supa || !CloudSync.session) return;
          const email = CloudSync.session.user.email;
          const { error } = await supa.auth.resetPasswordForEmail(email, {
            redirectTo: getAuthRedirectUrl(),
          });
          if (error) {
            this.toast("Erro: " + error.message);
            return;
          }
          this.toast("Link enviado para " + email + "!");
        },

        // Pull periódico a cada 5 minutos (padrão apps financeiros)
        startPeriodicSync() {
          if (this._periodicTimer) clearInterval(this._periodicTimer);
          this._periodicTimer = setInterval(
            async () => {
              if (CloudSync.status === "connected" && !CloudSync._syncing) {
                await CloudSync.pull();
                // Re-renderiza tela atual silenciosamente
                if (this.currentScreen && Screens[this.currentScreen]) {
                  const el = document.getElementById("screen-content");
                  if (el) el.innerHTML = Screens[this.currentScreen]();
                }
              }
            },
            5 * 60 * 1000,
          );
        },

        async desativarConta() {
          if (
            !confirm(
              "Desativar sua conta? Você não conseguirá mais acessar o app, mas seus dados serão preservados.",
            )
          )
            return;
          if (!supa || !CloudSync.session) return;
          const uid = CloudSync.session.user.id;
          await supa
            .from("profiles")
            .update({ status: "suspenso" })
            .eq("id", uid);
          this.toast("Conta desativada.");
          setTimeout(() => this.logout(), 1500);
        },

        async excluirConta() {
          if (
            !confirm(
              "Excluir sua conta permanentemente? Todos os seus dados serão apagados e não poderão ser recuperados.",
            )
          )
            return;
          if (!confirm("Tem certeza? Esta ação é irreversível.")) return;
          if (!supa || !CloudSync.session) return;
          const uid = CloudSync.session.user.id;
          const wsId = Store.get("workspaceId");
          // Apaga dados do workspace
          if (wsId) {
            await supa.from("gastos").delete().eq("workspace_id", wsId);
            await supa.from("entradas").delete().eq("workspace_id", wsId);
            await supa.from("separacoes_mes").delete().eq("workspace_id", wsId);
            await supa.from("ciclos").delete().eq("workspace_id", wsId);
            await supa.from("gastos_fixos").delete().eq("user_id", uid);
            await supa
              .from("workspace_members")
              .delete()
              .eq("workspace_id", wsId);
            await supa.from("workspaces").delete().eq("id", wsId);
          }
          await supa.from("profiles").delete().eq("id", uid);
          await supa.auth.signOut();
          Store.clearLocal();
          this.toast("Conta excluída.");
          setTimeout(() => location.reload(), 1500);
        },

        logout() {
          if (this._periodicPull) {
            clearInterval(this._periodicPull);
            this._periodicPull = null;
          }
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay-confirm";
          overlay.onclick = (e) => {
            if (e.target === overlay) overlay.remove();
          };
          const modal = document.createElement("div");
          modal.className = "modal";
          modal.style.cssText = "width:min(400px,92vw);";
          modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Sair do sistema</div><div class="modal-subtitle">Você precisará entrar novamente com seu e-mail e senha para acessar seus dados.</div></div><button class="modal-close" onclick="this.closest('.overlay').remove()">&#x00D7;</button></div><div class="modal-actions"><button class="btn btn-ghost" onclick="this.closest('.overlay').remove()">Cancelar</button><button class="btn btn-danger" onclick="App.confirmLogout()">Sair</button></div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
        },

        async confirmLogout() {
          document.getElementById("modal-overlay-confirm")?.remove();
          await CloudSync.signOut();
          document.getElementById("app-layout").classList.add("hidden");
          const sc = document.getElementById("screen-content");
          if (sc) sc.innerHTML = "";
          // Limpa estado local para não misturar com a próxima conta
          Store.data = {
            user: null,
            recebimentos: [],
            objetivos: [],
            parcelas: [],
            ciclos: {},
            compromisso: "",
            categorias: [
              {
                id: "E",
                nome: "Essencial",
                cor: "var(--cat-e)",
                bg: "var(--cat-e-t)",
              },
              {
                id: "P",
                nome: "Compromissos",
                cor: "var(--cat-p)",
                bg: "var(--cat-p-t)",
              },
              {
                id: "V",
                nome: "Variável",
                cor: "var(--cat-v)",
                bg: "var(--cat-v-t)",
              },
              {
                id: "F",
                nome: "Construção",
                cor: "var(--cat-f)",
                bg: "var(--cat-f-t)",
              },
            ],
            planoContas: {},
            gastosFixos: [],
            modoLancamento: "simples",
            separacaoSugestoes: [
              "Cofrinho de emergência",
              "Investimento",
              "Objetivo financeiro",
              "Poupança",
              "Dízimo",
              "Imposto",
              "Oferta",
              "Doação",
              "Ajuda familiar",
            ],
            cartoes: [],
          };
          Store.save();
          Login.show();
          Login.switchMode("signin");
        },

        // ── Workspace: carregar membros ──────────────────────────────
        async loadMembers() {
          const el = document.getElementById("members-list");
          if (!el || !supa) return;
          const wsId = Store.get("workspaceId");
          const isAdmin = Store.get("is_admin");
          const uid = this.session?.user?.id;
          if (!wsId) {
            el.innerHTML =
              '<div style="font-size:13px;color:var(--grey);">Workspace não encontrado.</div>';
            return;
          }
          let query = supa
            .from("workspace_members")
            .select("id,invited_email,role,status,accepted_at,invited_by")
            .eq("workspace_id", wsId)
            .neq("status", "removed");
          // Usuário comum só vê os convites que ele mesmo fez
          if (!isAdmin) query = query.eq("invited_by", uid);
          const { data: members } = await query;

          // Atualiza estado do formulário de convite (limite de 1 ativo por usuário comum)
          const wrap = document.getElementById("invite-form-wrap");
          if (wrap && !isAdmin) {
            const temConviteAtivo = (members || []).some(
              (m) => m.status === "pending" || m.status === "active",
            );
            if (temConviteAtivo) {
              wrap.innerHTML =
                '<div style="font-size:13px;color:var(--grey);">Você já utilizou seu convite. Remova-o para convidar outra pessoa.</div>';
            } else {
              wrap.innerHTML = `
                <input id="invite-email" type="email" class="form-input" placeholder="email@exemplo.com" style="flex:1;min-width:180px;font-size:14px;padding:10px 12px;">
                <button class="btn btn-primary btn-sm" onclick="App.inviteMember()">Convidar</button>`;
            }
          }

          if (!members || !members.length) {
            el.innerHTML =
              '<div style="font-size:13px;color:var(--grey);">Nenhum membro convidado ainda.</div>';
            return;
          }
          el.innerHTML = members
            .map(
              (m) => `
          <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--grey-xl);">
            <div style="flex:1;">
              <div style="font-size:13px;font-weight:600;color:var(--navy);">${FarolHelpers.escapeHtml(m.invited_email)}</div>
              <div style="font-size:11px;color:${m.status === "active" ? "var(--green)" : "var(--amber)"};">${m.status === "active" ? "Ativo" : "Convite pendente"}</div>
            </div>
            ${m.role !== "owner" && (isAdmin || m.invited_by === uid) ? `<button onclick="App.removeMember('${m.id}')" style="font-size:12px;color:var(--red);background:none;border:none;cursor:pointer;">Remover</button>` : ""}
          </div>`,
            )
            .join("");
        },

        async inviteMember() {
          const email = (document.getElementById("invite-email")?.value || "")
            .trim()
            .toLowerCase();
          const msg = document.getElementById("invite-msg");
          if (!email || !email.includes("@")) {
            if (msg)
              ((msg.style.color = "var(--red)"),
                (msg.textContent = "Email inválido."));
            return;
          }
          const wsId = Store.get("workspaceId");
          if (!wsId) {
            if (msg) msg.textContent = "Workspace não encontrado.";
            return;
          }
          const isAdmin = Store.get("is_admin");
          const uid = this.session?.user?.id;

          // Usuário comum: limite de 1 convite ativo por vez
          if (!isAdmin) {
            const { data: meusConvites } = await supa
              .from("workspace_members")
              .select("id,status")
              .eq("workspace_id", wsId)
              .eq("invited_by", uid)
              .in("status", ["pending", "active"]);
            if (meusConvites && meusConvites.length > 0) {
              if (msg)
                ((msg.style.color = "var(--red)"),
                  (msg.textContent =
                    "Você já tem um convite ativo. Remova-o antes de convidar outra pessoa."));
              return;
            }
          }

          if (msg) msg.textContent = "Enviando convite…";
          const { error } = await supa.from("workspace_members").upsert(
            {
              workspace_id: wsId,
              invited_email: email,
              invited_by: uid,
              role: "member",
              status: "pending",
            },
            { onConflict: "workspace_id,invited_email" },
          );
          if (error) {
            if (msg)
              ((msg.style.color = "var(--red)"),
                (msg.textContent = "Erro: " + error.message));
            return;
          }
          if (msg)
            ((msg.style.color = "var(--green)"),
              (msg.textContent =
                "Convite registrado! Peça para " +
                email +
                " criar uma conta com este email."));
          const emailInput = document.getElementById("invite-email");
          if (emailInput) emailInput.value = "";
          setTimeout(() => this.loadMembers(), 500);
        },

        async removeMember(memberId) {
          if (!confirm("Remover este membro?")) return;
          const isAdmin = Store.get("is_admin");
          const uid = this.session?.user?.id;
          let query = supa
            .from("workspace_members")
            .update({ status: "removed" })
            .eq("id", memberId);
          // Usuário comum só pode remover convite que ele mesmo fez
          if (!isAdmin) query = query.eq("invited_by", uid);
          await query;
          this.loadMembers();
        },

        async cloudPush() {
          this.toast("Enviando dados…");
          const r = await CloudSync.push();
          this.toast(r.ok ? "Dados enviados!" : "Falha: " + (r.msg || ""));
          this.go("nuvem");
        },

        async cloudPull() {
          this.toast("Buscando dados da nuvem…");
          const r = await CloudSync.pull();
          if (r.ok) {
            this.toast("Dados restaurados!");
            setTimeout(() => this.go("dashboard"), 800);
          } else {
            this.toast("Falha: " + (r.msg || ""));
          }
          this.go("nuvem");
        },

        // ─── Marcar/desmarcar lançamento como pago ────────────
        toggleGastoPago(key, idx) {
          const ciclos = Store.get("ciclos") || {};
          const g = ciclos[key]?.gastos?.[idx];
          if (!g) return;
          g.pago = !g.pago;
          g.pagoEm = g.pago
            ? new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
                .toISOString()
                .split("T")[0]
            : null;
          Store.set("ciclos", ciclos);
          this.go(this.currentScreen);
        },

        // ─── Edição inline de valor ────────────────────────
        editarValorGasto(key, idx) {
          const ciclos = Store.get("ciclos") || {};
          const g = ciclos[key]?.gastos?.[idx];
          if (!g) return;
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay-editar";
          overlay.onclick = (e) => {
            if (e.target === overlay) overlay.remove();
          };
          const modal = document.createElement("div");
          modal.className = "modal";
          modal.style.cssText = "width:min(360px,92vw);";
          modal.innerHTML = `
          <div class="modal-header">
            <div><div class="modal-title">Editar valor</div><div class="modal-subtitle">${FarolHelpers.escapeHtml(g.descricao)}</div></div>
            <button class="modal-close" onclick="this.closest('.overlay').remove()">×</button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label class="label">Novo valor</label>
              <div class="input-money"><span>R$</span><input id="editar-valor-input" class="form-input" type="number" step="0.01" min="0" value="${g.valor}" placeholder="0,00"></div>
            </div>
          </div>
          <div class="modal-actions">
            <button class="btn btn-ghost" onclick="this.closest('.overlay').remove()">Cancelar</button>
            <button class="btn btn-primary" onclick="App.confirmarEditarValor('${key}',${idx})">Salvar</button>
          </div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
          setTimeout(() => {
            const inp = document.getElementById("editar-valor-input");
            if (inp) {
              inp.focus();
              inp.select();
            }
          }, 80);
        },

        confirmarEditarValor(key, idx) {
          const novoValor = parseFloat(
            document.getElementById("editar-valor-input")?.value || 0,
          );
          if (!novoValor || novoValor <= 0) {
            this.toast("Digite um valor válido");
            return;
          }
          const ciclos = Store.get("ciclos") || {};
          if (ciclos[key]?.gastos?.[idx]) {
            ciclos[key].gastos[idx].valor = novoValor;
            Store.set("ciclos", ciclos);
            document.getElementById("modal-overlay-editar")?.remove();
            this.toast("Valor atualizado!");
            this.go(this.currentScreen);
          }
        },

        // ───Copiar mês anterior ────────────────────────────
        copiarMesAnterior() {
          const key = this.getActiveCycleKey();
          const anteriorKey = FarolHelpers.shiftMonthKey(key, -1);
          const ciclos = Store.get("ciclos") || {};
          const anterior = ciclos[anteriorKey];
          const atual = ciclos[key] || {
            renda: 0,
            gastos: [],
            decisao: "",
            fontes: [],
          };
          if (!anterior || !anterior.gastos || anterior.gastos.length === 0) {
            this.toast("Mês anterior sem lançamentos para copiar.");
            return;
          }
          const jaTemGastos = atual.gastos && atual.gastos.length > 0;
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay-copiar";
          overlay.onclick = (e) => {
            if (e.target === overlay) overlay.remove();
          };
          const modal = document.createElement("div");
          modal.className = "modal";
          modal.style.cssText = "width:min(440px,92vw);";
          const mesAnteriorLabel = FarolHelpers.monthLabelByKey(anteriorKey);
          modal.innerHTML = `
          <div class="modal-header">
            <div><div class="modal-title">Copiar mês anterior</div><div class="modal-subtitle">Copiar ${anterior.gastos.length} lançamento(s) de ${mesAnteriorLabel}</div></div>
            <button class="modal-close" onclick="this.closest('.overlay').remove()">×</button>
          </div>
          <div class="modal-body">
            ${jaTemGastos ? `<div class="box" style="background:var(--amb-t);border:1px solid rgba(183,110,18,.2);padding:12px 14px;border-radius:var(--r);margin-bottom:14px;"><p style="font-size:13px;color:var(--amber);margin:0;"><strong>Atenção:</strong> O mês atual já tem ${atual.gastos.length} lançamento(s). A cópia será adicionada por cima.</p></div>` : ""}
            <div style="max-height:200px;overflow-y:auto;">
              ${anterior.gastos
                .slice(0, 20)
                .map(
                  (g) =>
                    `<div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--grey-xl);font-size:13px;"><span style="color:var(--navy);font-weight:600;">${FarolHelpers.escapeHtml(g.descricao)}</span><span style="color:var(--grey);font-weight:700;">${Calc.fmt(g.valor)}</span></div>`,
                )
                .join("")}
              ${anterior.gastos.length > 20 ? `<div style="font-size:12px;color:var(--grey);padding-top:8px;text-align:center;">+${anterior.gastos.length - 20} lançamentos...</div>` : ""}
            </div>
          </div>
          <div class="modal-actions">
            <button class="btn btn-ghost" onclick="this.closest('.overlay').remove()">Cancelar</button>
            <button class="btn btn-primary" onclick="App.confirmarCopiarMes('${key}','${anteriorKey}')">Copiar ${anterior.gastos.length} lançamento(s)</button>
          </div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
        },

        confirmarCopiarMes(key, anteriorKey) {
          document.getElementById("modal-overlay-copiar")?.remove();
          const ciclos = Store.get("ciclos") || {};
          const anterior = ciclos[anteriorKey];
          if (!anterior?.gastos) return;
          if (!ciclos[key])
            ciclos[key] = { renda: 0, gastos: [], decisao: "", fontes: [] };
          // copiar apenas gastos sem templateId (avulsos) e os templates que ainda estão ativos
          // Para não duplicar os gerados pelo syncRecurring
          const [y, m] = key.split("-").map(Number);
          anterior.gastos.forEach((g) => {
            if (g.templateId) return; // recorrentes já são gerados por syncRecurring
            const jaExiste = ciclos[key].gastos.some(
              (x) => x.descricao === g.descricao && x.valor === g.valor,
            );
            if (!jaExiste) {
              const dia = g.data ? g.data.split("-")[2] : "01";
              const novaData = `${y}-${String(m + 1).padStart(2, "0")}-${dia}`;
              ciclos[key].gastos.push({
                ...g,
                data: novaData,
                templateId: undefined,
              });
            }
          });
          Store.set("ciclos", ciclos);
          this.toast(
            `${anterior.gastos.filter((g) => !g.templateId).length} lançamento(s) copiado(s)!`,
          );
          this.go(this.currentScreen);
        },

        // ─── Alternar modo de lançamento ───────────────────
        alternarModoLancamento() {
          const atual = Store.get("modoLancamento") || "simples";
          const novo = atual === "simples" ? "detalhado" : "simples";
          Store.set("modoLancamento", novo);
          this.toast(
            novo === "simples"
              ? "Modo simplificado ativado"
              : "Modo detalhado ativado",
          );
          this.go("meumes");
        },

        toggleSidebar() {
          const s = document.getElementById("sidebar");
          const b = document.getElementById("sidebar-backdrop");
          const willOpen = !s.classList.contains("open");
          s.classList.toggle("open", willOpen);
          b.classList.toggle("open", willOpen);
          if (window.innerWidth <= 1024) {
            if (willOpen) {
              this._scrollY = window.scrollY || window.pageYOffset || 0;
              document.body.classList.add("sidebar-open");
              document.body.style.top = `-${this._scrollY}px`;
            } else {
              document.body.classList.remove("sidebar-open");
              document.body.style.top = "";
              window.scrollTo(0, this._scrollY || 0);
            }
          }
        },
        closeSidebar() {
          const wasOpen = document
            .getElementById("sidebar")
            ?.classList.contains("open");
          document.getElementById("sidebar")?.classList.remove("open");
          document.getElementById("sidebar-backdrop")?.classList.remove("open");
          if (wasOpen && document.body.classList.contains("sidebar-open")) {
            document.body.classList.remove("sidebar-open");
            document.body.style.top = "";
            window.scrollTo(0, this._scrollY || 0);
          }
        },

        // Goal funding modal
        openGoalFundingModal(idx, returnScreen) {
          const objs = Store.get("objetivos") || [];
          const obj = objs[idx];
          this._goalFundingReturnScreen = returnScreen || "objetivos";
          if (!obj) {
            this.toast("Objetivo não encontrado");
            return;
          }
          const key = Calc.cicloAtual();
          const mes = Calc.getCiclo(key);
          const disponivel = Math.max(
            Calc.rendaNoMes(mes) - Calc.totalGastos(mes.gastos || []),
            0,
          );
          const restante = Math.max((obj.valor || 0) - (obj.valorPago || 0), 0);
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay";
          overlay.onclick = (e) => {
            if (e.target === overlay) this.closeModal();
          };
          const modal = document.createElement("div");
          modal.className = "modal panel-modal";
          modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Aplicar valor ao objetivo</div><div class="modal-subtitle">Direcione o disponível com clareza.</div></div><button class="modal-close" onclick="App.closeModal()">×</button></div>
        <div class="modal-body">
          <div class="goal-spotlight mb-16"><div class="goal-headline"><div><div class="obj-name">${FarolHelpers.escapeHtml(obj.nome)}</div><div class="obj-meta">${FarolHelpers.goalStatus(obj)}</div></div><span class="obj-priority ${obj.prioridade || "media"}">${obj.prioridade || "média"}</span></div><div class="goal-inline-progress"><div class="progress-wrap" style="flex:1;"><div class="progress-bar" style="width:${Calc.objPct(obj)}%;"></div></div><strong>${Math.round(Calc.objPct(obj))}%</strong></div></div>
          <div class="funding-availability"><div class="funding-box good"><div class="tag">Disponível no mês</div><div class="amount">${Calc.fmt(disponivel)}</div></div><div class="funding-box target"><div class="tag">Falta para concluir</div><div class="amount">${Calc.fmt(restante)}</div></div></div>
          <div class="form-group"><label class="label">Quanto aplicar</label><input id="goal-funding-value" class="form-input" type="number" min="0" step="0.01" value="${Math.min(disponivel, restante) || ""}" placeholder="0,00"></div>
        </div>
        <div class="modal-actions"><button class="btn btn-ghost" onclick="App.closeModal()">Cancelar</button><button class="btn btn-gold" onclick="App.confirmGoalFunding(${idx})">Confirmar →</button></div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
          setTimeout(
            () => document.getElementById("goal-funding-value")?.focus(),
            80,
          );
        },

        async confirmGoalFunding(idx) {
          const objs = Store.get("objetivos") || [];
          if (!objs[idx]) return;
          const key = Calc.cicloAtual();
          const mes = Calc.getCiclo(key);
          const disponivel = Math.max(
            Calc.rendaNoMes(mes) - Calc.totalGastos(mes.gastos || []),
            0,
          );
          const restante = Math.max(
            (objs[idx].valor || 0) - (objs[idx].valorPago || 0),
            0,
          );
          const valor = parseFloat(
            document.getElementById("goal-funding-value")?.value || 0,
          );
          if (!valor || valor <= 0) {
            this.toast("Digite um valor válido");
            return;
          }
          if (valor > disponivel) {
            this.toast("Valor maior do que o disponível");
            return;
          }
          objs[idx].valorPago =
            (objs[idx].valorPago || 0) + Math.min(valor, restante || valor);
          Store.set("objetivos", objs);

          // Sincronizar valor_atual atualizado com o banco
          if (supa && objs[idx].id && CloudSync.session) {
            const wsId = Store.get("workspaceId");
            const { error } = await supa
              .from("objetivos")
              .update({ valor_atual: objs[idx].valorPago })
              .eq("id", objs[idx].id)
              .eq("workspace_id", wsId);
            if (error)
              console.error("Erro ao atualizar valor_atual no banco:", error);
          }

          const returnScreen = this._goalFundingReturnScreen || "objetivos";
          this._goalFundingReturnScreen = null;
          this.closeModal();
          this.toast("✅ Valor aplicado!");
          this.go(returnScreen);
        },

        openGoalEditModal(idx) {
          const objs = Store.get("objetivos") || [];
          const obj = objs[idx];
          if (!obj) return;
          const overlay = document.createElement("div");
          overlay.className = "overlay center";
          overlay.id = "modal-overlay";
          overlay.onclick = (e) => {
            if (e.target === overlay) this.closeModal();
          };
          const modal = document.createElement("div");
          modal.className = "modal panel-modal";
          modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Editar objetivo</div></div><button class="modal-close" onclick="App.closeModal()">×</button></div>
        <div class="modal-body">
          <div class="form-group"><label class="label">Nome</label><input id="goal-edit-name" class="form-input" value="${FarolHelpers.escapeHtml(obj.nome)}"></div>
          <div class="funding-availability"><div class="form-group" style="margin:0;"><label class="label">Valor da meta</label><input id="goal-edit-target" class="form-input" type="number" step="0.01" value="${obj.valor || 0}"></div><div class="form-group" style="margin:0;"><label class="label">Valor acumulado</label><input id="goal-edit-paid" class="form-input" type="number" step="0.01" value="${obj.valorPago || 0}"></div></div>
          <div class="funding-availability"><div class="form-group" style="margin:0;"><label class="label">Prazo</label><input id="goal-edit-deadline" class="form-input" type="month" value="${obj.prazo ? String(obj.prazo).slice(0, 7) : ""}"></div><div class="form-group" style="margin:0;"><label class="label">Prioridade</label><select id="goal-edit-priority" class="form-select"><option value="alta" ${obj.prioridade === "alta" ? "selected" : ""}>Alta</option><option value="media" ${obj.prioridade === "media" ? "selected" : ""}>Média</option><option value="baixa" ${obj.prioridade === "baixa" ? "selected" : ""}>Baixa</option></select></div></div>
        </div>
        <div class="modal-actions"><button class="btn btn-ghost" onclick="App.closeModal()">Cancelar</button><button class="btn btn-primary" onclick="App.saveGoalEdit(${idx})">Salvar</button></div>`;
          overlay.appendChild(modal);
          document.getElementById("overlay-container").appendChild(overlay);
          setTimeout(
            () => document.getElementById("goal-edit-name")?.focus(),
            80,
          );
        },

        async saveGoalEdit(idx) {
          const objs = Store.get("objetivos") || [];
          if (!objs[idx]) return;
          const nome = document.getElementById("goal-edit-name")?.value?.trim();
          const valor = parseFloat(
            document.getElementById("goal-edit-target")?.value || 0,
          );
          const pago = parseFloat(
            document.getElementById("goal-edit-paid")?.value || 0,
          );
          const prazo = document.getElementById("goal-edit-deadline")?.value;
          const prio =
            document.getElementById("goal-edit-priority")?.value || "media";
          if (!nome) {
            this.toast("Nome obrigatório");
            return;
          }
          if (!valor || valor <= 0) {
            this.toast("Valor obrigatório");
            return;
          }

          try {
            // Atualizar localmente
            objs[idx] = {
              ...objs[idx],
              nome,
              valor,
              valorPago: Math.max(pago, 0),
              prazo: prazo ? `${prazo}-01` : objs[idx].prazo,
              prioridade: prio,
            };
            objs.sort(
              (a, b) =>
                ({ alta: 0, media: 1, baixa: 2 })[a.prioridade] -
                { alta: 0, media: 1, baixa: 2 }[b.prioridade],
            );
            Store.set("objetivos", objs);

            // Atualizar no Supabase se tiver ID
            if (supa && objs[idx].id && CloudSync.session) {
              const wsId = Store.get("workspaceId");
              const { error } = await supa
                .from("objetivos")
                .update({
                  nome: nome,
                  valor_meta: valor,
                  valor_atual: Math.max(pago, 0),
                  prazo: prazo ? `${prazo}-01` : null,
                  concluido: objs[idx].concluido || false,
                  prioridade: prio,
                })
                .eq("id", objs[idx].id)
                .eq("workspace_id", wsId);

              if (error) {
                console.error("Erro ao atualizar no banco:", error);
                this.toast("⚠️ Atualizado localmente, erro ao sincronizar");
              } else {
                this.toast("✅ Objetivo atualizado!");
              }
            } else {
              this.toast("Objetivo atualizado (modo offline)");
            }

            this.closeModal();
            this.go("objetivos");
          } catch (err) {
            console.error("Erro ao editar objetivo:", err);
            this.toast("❌ Erro ao atualizar");
          }
        },

        applySobraToGoal(idx) {
          this.openGoalFundingModal(idx);
        },
      };

      // Medal icon renderer
      function getMedalSvg(iconName, size, color) {
        var paths = {
          leaf: '<path d="M17 8C8 10 5.9 16.17 3.82 22"/><path d="M3.82 22c2-5 5.5-8 11.18-8c2 0 4.82-1 6-4"/>',
          calendar:
            '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
          check: '<polyline points="20 6 9 17 4 12"/>',
          save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/>',
          target:
            '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
          trophy:
            '<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 17 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2z"/>',
          chart:
            '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
          star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
          unlock:
            '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
          shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
        };
        var lockPath =
          '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>';
        var p = paths[iconName] || paths["star"];
        return (
          '<svg width="' +
          size +
          '" height="' +
          size +
          '" viewBox="0 0 24 24" fill="none" stroke="' +
          color +
          '" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
          p +
          "</svg>"
        );
      }
      function getMedalLockSvg(size) {
        return (
          '<svg width="' +
          size +
          '" height="' +
          size +
          '" viewBox="0 0 24 24" fill="none" stroke="#9FB0C0" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>'
        );
      }


/* V14 — previsão, edição, duplicação, exclusão e status */
(function(){
  const todayISO = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().split('T')[0];
  const keyFromISO = (iso) => {
    const [y,m] = String(iso || '').split('-').map(Number);
    return y && m ? `${y}-${m-1}` : (App.getActiveCycleKey ? App.getActiveCycleKey() : Calc.cicloAtual());
  };
  const ensureCycle = (key) => {
    const ciclos = Store.get('ciclos') || {};
    if (!ciclos[key]) ciclos[key] = { renda:0, gastos:[], decisao:'', fontes:[] };
    if (!Array.isArray(ciclos[key].fontes)) ciclos[key].fontes = [];
    if (!Array.isArray(ciclos[key].gastos)) ciclos[key].gastos = [];
    return { ciclos, ciclo:ciclos[key] };
  };
  const recalc = (ciclo) => { ciclo.renda = Calc.rendaNoMes(ciclo); return ciclo; };
  const collectEntradaSeparacoes = () => Array.from(document.querySelectorAll('.m-sep-row')).map((row) => {
    const selVal = row.querySelector('.m-sep-nome-select')?.value || '';
    const nome = selVal === '_outro_' ? (row.querySelector('.m-sep-nome-custom')?.value || '').trim() : selVal;
    const tipo = row.querySelector('.m-sep-tipo')?.value || 'valor';
    const valor = parseFloat(row.querySelector('.m-sep-valor')?.value || 0) || 0;
    if (!nome || valor <= 0) return null;
    const n = String(nome || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
    let categoria = 'futuro';
    if (n.includes('imposto') || n.includes('tributo') || n.includes('taxa')) categoria = 'imposto';
    else if (n.includes('dizimo') || n.includes('devolucao')) categoria = 'devolucao';
    else if (n.includes('oferta') || n.includes('doacao') || n.includes('ajuda familiar') || n.includes('igreja')) categoria = 'oferta';
    else if (n.includes('objetivo') || n.includes('meta') || n.includes('viagem') || n.includes('notebook') || n.includes('carro')) categoria = 'objetivo';
    else categoria = 'futuro';
    return { nome, tipo, valor, categoria };
  }).filter(Boolean);

  App.saveRenda = function(){
    if (!this._beginSubmit('saveRenda')) return;
    const valor = parseFloat(document.getElementById('m-renda-valor')?.value || 0);
    const origemSel = document.getElementById('m-renda-origem')?.value?.trim() || 'Entrada';
    const origemCustom = (document.getElementById('m-renda-origem-custom')?.value || '').trim();
    const origem = origemSel === '_novo_' ? (origemCustom || 'Entrada') : origemSel;
    const data = document.getElementById('m-renda-data')?.value || todayISO();
    const status = document.getElementById('m-renda-status')?.value || 'previsto';
    if (!valor || valor <= 0) { this.toast('Digite o valor'); return; }
    const key = keyFromISO(data);
    this.activeCycleKey = key;
    const separacoes = collectEntradaSeparacoes();
    if (separacoes.length && this.saveSeparacaoSuggestions) this.saveSeparacaoSuggestions(separacoes.map(s => s.nome));
    const { ciclos, ciclo } = ensureCycle(key);
    ciclo.fontes.push({ id:'e'+Date.now().toString(36)+Math.random().toString(36).slice(2,5), origem, valor, data, status, separacoes });
    recalc(ciclo);
    Store.set('ciclos', ciclos);
    this.closeModal(); this.toast(status === 'previsto' ? 'Entrada prevista adicionada!' : 'Entrada adicionada!'); this.go(this.currentScreen || 'meumes');
  };

  App.updateEntrada = function(){
    if (!this._beginSubmit('updateEntrada')) return;
    const oldKey = document.getElementById('m-edit-key')?.value;
    const idx = parseInt(document.getElementById('m-edit-idx')?.value || '-1', 10);
    const valor = parseFloat(document.getElementById('m-renda-valor')?.value || 0);
    const data = document.getElementById('m-renda-data')?.value || todayISO();
    const status = document.getElementById('m-renda-status')?.value || 'previsto';
    const origemSel = document.getElementById('m-renda-origem')?.value?.trim() || 'Entrada';
    const origemCustom = (document.getElementById('m-renda-origem-custom')?.value || '').trim();
    const origem = origemSel === '_novo_' ? (origemCustom || 'Entrada') : origemSel;
    if (!valor || valor <= 0) { this.toast('Digite o valor'); return; }
    const ciclos = Store.get('ciclos') || {};
    const old = ciclos[oldKey]?.fontes?.[idx];
    if (!old) return this.toast('Entrada não encontrada.');
    ciclos[oldKey].fontes.splice(idx, 1); recalc(ciclos[oldKey]);
    const newKey = keyFromISO(data); this.activeCycleKey = newKey;
    if (!ciclos[newKey]) ciclos[newKey] = { renda:0, gastos:[], decisao:'', fontes:[] };
    if (!Array.isArray(ciclos[newKey].fontes)) ciclos[newKey].fontes = [];
    const separacoes = collectEntradaSeparacoes();
    if (separacoes.length && this.saveSeparacaoSuggestions) this.saveSeparacaoSuggestions(separacoes.map(s => s.nome));
    ciclos[newKey].fontes.push({ ...old, origem, valor, data, status, separacoes }); recalc(ciclos[newKey]);
    Store.set('ciclos', ciclos); this.closeModal(); this.toast('Entrada atualizada.'); this.go(this.currentScreen || 'meumes');
  };

  App.editEntrada = function(key, idx){
    const ciclos = Store.get('ciclos') || {}; const e = ciclos[key]?.fontes?.[idx];
    if (!e) return this.toast('Entrada não encontrada.');
    this.openModal('renda', { kind:'entrada', key, idx, item:e });
  };
  App.duplicateEntrada = function(key, idx){
    const ciclos = Store.get('ciclos') || {}; const e = ciclos[key]?.fontes?.[idx];
    if (!e) return;
    ciclos[key].fontes.push({ ...e, id:'e'+Date.now().toString(36), origem:(e.origem || 'Entrada') + ' (cópia)' }); recalc(ciclos[key]);
    Store.set('ciclos', ciclos); this.toast('Entrada duplicada.'); this.go(this.currentScreen || 'meumes');
  };

  App.saveGasto = function(){
    if (!this._beginSubmit('saveGasto')) return;
    const valor = parseFloat(document.getElementById('m-valor')?.value || 0);
    const descricao = (document.getElementById('m-desc')?.value || '').trim() || 'Gasto';
    const data = document.getElementById('m-data')?.value || todayISO();
    const status = document.getElementById('m-gasto-status')?.value || 'pendente';
    const categoria = document.getElementById('m-cat')?.value || 'V';
    if (!valor || valor <= 0) { this.toast('Digite o valor'); return; }
    const key = keyFromISO(data); this.activeCycleKey = key;
    const { ciclos, ciclo } = ensureCycle(key);
    ciclo.gastos.push({ id:'g'+Date.now().toString(36)+Math.random().toString(36).slice(2,5), descricao, valor, data, categoria, status, pago: status === 'pago' });
    Store.set('ciclos', ciclos); this.closeModal(); this.toast(status === 'pago' ? 'Gasto pago salvo!' : (status === 'cancelado' ? 'Gasto cancelado.' : 'Conta a pagar salva!')); this.go(this.currentScreen || 'meumes');
  };
  App.updateGasto = function(){
    if (!this._beginSubmit('updateGasto')) return;
    const oldKey = document.getElementById('m-edit-key')?.value;
    const idx = parseInt(document.getElementById('m-edit-idx')?.value || '-1', 10);
    const valor = parseFloat(document.getElementById('m-valor')?.value || 0);
    const descricao = (document.getElementById('m-desc')?.value || '').trim() || 'Gasto';
    const data = document.getElementById('m-data')?.value || todayISO();
    const status = document.getElementById('m-gasto-status')?.value || 'pendente';
    const ciclos = Store.get('ciclos') || {}; const old = ciclos[oldKey]?.gastos?.[idx];
    if (!old) return this.toast('Gasto não encontrado.');
    if (!valor || valor <= 0) { this.toast('Digite o valor'); return; }
    ciclos[oldKey].gastos.splice(idx, 1);
    const newKey = keyFromISO(data); this.activeCycleKey = newKey;
    if (!ciclos[newKey]) ciclos[newKey] = { renda:0, gastos:[], decisao:'', fontes:[] };
    if (!Array.isArray(ciclos[newKey].gastos)) ciclos[newKey].gastos = [];
    ciclos[newKey].gastos.push({ ...old, descricao, valor, data, status, pago: status === 'pago' });
    Store.set('ciclos', ciclos); this.closeModal(); this.toast('Gasto atualizado.'); this.go(this.currentScreen || 'meumes');
  };
  App.editGasto = function(key, idx){
    const ciclos = Store.get('ciclos') || {}; const g = ciclos[key]?.gastos?.[idx];
    if (!g) return this.toast('Gasto não encontrado.');
    this.openModal('gasto', { kind:'gasto', key, idx, item:g });
  };
  App.markGastoPago = function(key, idx){
    const ciclos = Store.get('ciclos') || {}; const g = ciclos[key]?.gastos?.[idx];
    if (!g) return this.toast('Gasto não encontrado.');
    g.status = 'pago';
    g.pago = true;
    g.pago_em = todayISO();
    Store.set('ciclos', ciclos);
    this.toast('Marcado como pago.');
    this.go(this.currentScreen || 'meumes');
  };

  App.duplicateGasto = function(key, idx){
    const ciclos = Store.get('ciclos') || {}; const g = ciclos[key]?.gastos?.[idx];
    if (!g) return;
    ciclos[key].gastos.push({ ...g, id:'g'+Date.now().toString(36), descricao:(g.descricao || g.desc || 'Gasto') + ' (cópia)' });
    Store.set('ciclos', ciclos); this.toast('Gasto duplicado.'); this.go(this.currentScreen || 'meumes');
  };

  const oldSaveRecebimento = App.saveRecebimento;
  App.saveRecebimento = async function(){
    if (!this._beginSubmit('saveRecebimentoV14')) return;
    const idxRaw = document.getElementById('m-r-idx')?.value;
    const idx = idxRaw !== '' && idxRaw != null ? parseInt(idxRaw, 10) : null;
    const nome = document.getElementById('m-r-nome')?.value?.trim();
    const tipo = document.getElementById('m-r-tipo')?.value || 'fixo';
    const dia = parseInt(document.getElementById('m-r-dia')?.value || '1', 10);
    const valor = parseFloat(document.getElementById('m-r-valor')?.value || 0) || 0;
    const status = document.getElementById('m-r-status')?.value || 'previsto';
    if (!nome) return this.toast('Digite a origem.');
    const recs = Store.get('recebimentos') || [];
    const item = { ...(idx !== null && recs[idx] ? recs[idx] : {}), id: (idx !== null && recs[idx]?.id) || ('r'+Date.now().toString(36)), nome, tipo, dia: tipo === 'extra' ? null : dia, valor, status, atualizadoEm:new Date().toISOString() };
    if (idx !== null && recs[idx]) recs[idx] = item; else recs.push(item);
    Store.set('recebimentos', recs); if (window.CloudSync) CloudSync.scheduleSync();
    this.closeModal(); this.toast(idx !== null ? 'Recebimento atualizado.' : 'Recebimento previsto salvo.'); this.go('recebimentos');
  };
  App.editRecebimento = function(idx){ this.openModal('recebimento', idx); };

  App.extratoActions = function(tipo, key, idx){
    const overlay = document.createElement('div'); overlay.className='overlay center'; overlay.id='modal-overlay-actions'; overlay.onclick=e=>{ if(e.target===overlay) overlay.remove(); };
    const isEntrada = tipo === 'entrada';
    const modal = document.createElement('div'); modal.className='modal'; modal.style.cssText='width:min(360px,92vw);';
    modal.innerHTML = `<div class="modal-header"><div><div class="modal-title">Ações do lançamento</div><div class="modal-subtitle">Editar, duplicar ou excluir</div></div><button class="modal-close" onclick="this.closest('.overlay').remove()">×</button></div>
      <div style="display:grid;gap:10px;"><button class="btn btn-primary btn-full" onclick="document.getElementById('modal-overlay-actions')?.remove();App.${isEntrada?'editEntrada':'editGasto'}('${key}',${idx})">Editar</button><button class="btn btn-ghost btn-full" onclick="document.getElementById('modal-overlay-actions')?.remove();App.${isEntrada?'duplicateEntrada':'duplicateGasto'}('${key}',${idx})">Duplicar</button><button class="btn btn-danger btn-full" onclick="document.getElementById('modal-overlay-actions')?.remove();App.${isEntrada?'deleteEntrada':'deleteGasto'}('${key}',${idx})">Excluir</button></div>`;
    overlay.appendChild(modal); document.getElementById('overlay-container').appendChild(overlay);
  };
})();


/* ═══════════════════════════════════════════════════════
   V19 — Separação neutra na entrada: Cofrinho x Destinação
   - Dízimo/Oferta/Doação/Ajuda familiar são "destinação/devolução".
   - Reduzem o disponível, aparecem no Meu Mês, mas não entram em Gastos nem Cofrinho.
   ═══════════════════════════════════════════════════════ */
(function(){
  if (!window.App) return;
  const esc = (v) => (window.FarolHelpers && FarolHelpers.escapeHtml ? FarolHelpers.escapeHtml(String(v ?? '')) : String(v ?? '').replace(/[&<>"]/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m])));
  const todayISO = () => new Date(Date.now() - new Date().getTimezoneOffset()*60000).toISOString().split('T')[0];
  const keyFromISO = (iso) => { const d = iso ? new Date(iso+'T00:00:00') : new Date(); return `${d.getFullYear()}-${d.getMonth()}`; };
  const norm = (v) => String(v || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();
  const categoriaAutomatica = (nome, fallback) => {
    const n = norm(nome);
    if (fallback && fallback !== 'auto') return fallback;
    if (n.includes('imposto') || n.includes('tributo') || n.includes('taxa')) return 'imposto';
    if (n.includes('dizimo') || n.includes('devolucao')) return 'devolucao';
    if (n.includes('oferta') || n.includes('doacao') || n.includes('ajuda familiar') || n.includes('igreja') || n.includes('missao') || n.includes('social')) return 'destinacao';
    if (n.includes('objetivo') || n.includes('meta') || n.includes('viagem') || n.includes('notebook') || n.includes('carro')) return 'objetivo';
    return 'cofrinho';
  };
  const categoriaLabel = (cat, nome) => {
    const n = norm(nome);
    if (cat === 'imposto' || n.includes('imposto') || n.includes('tributo') || n.includes('taxa')) return 'Imposto';
    if (cat === 'devolucao' || n.includes('dizimo')) return 'Devolução';
    if (cat === 'destinacao' || cat === 'oferta') return 'Destinação';
    if (cat === 'objetivo') return 'Objetivo';
    return 'Cofrinho';
  };
  const ensureCycle = (key) => {
    const ciclos = Store.get('ciclos') || {};
    if (!ciclos[key]) ciclos[key] = { renda:0, gastos:[], decisao:'', fontes:[], separacoes:[] };
    if (!Array.isArray(ciclos[key].fontes)) ciclos[key].fontes = [];
    if (!Array.isArray(ciclos[key].gastos)) ciclos[key].gastos = [];
    if (!Array.isArray(ciclos[key].separacoes)) ciclos[key].separacoes = [];
    return { ciclos, ciclo:ciclos[key] };
  };
  const recalc = (ciclo) => { ciclo.renda = Calc.rendaNoMes(ciclo); return ciclo; };
  const valorSeparacao = (sep, bruto) => {
    const raw = parseFloat(sep && sep.valor || 0) || 0;
    return Math.max(0, (sep && sep.tipo) === 'percentual' ? (parseFloat(bruto)||0) * (raw/100) : raw);
  };

  App.addSeparacaoRow = function(data){
    const list = document.getElementById('m-sep-list');
    if (!list) return;
    const tipos = this.getSeparacaoSuggestions ? this.getSeparacaoSuggestions() : ['Cofrinho de emergência','Investimento','Poupança','Dízimo','Imposto','Oferta','Doação','Ajuda familiar'];
    const nomeAtual = (data && data.nome) || '';
    const catAtual = (data && data.categoria) || categoriaAutomatica(nomeAtual, 'auto');
    const isOutro = nomeAtual && !tipos.includes(nomeAtual);
    const row = document.createElement('div');
    row.className = 'm-sep-row';
    row.style.cssText = 'display:grid;grid-template-columns:1fr 1.25fr .75fr .85fr auto;gap:8px;align-items:end;margin-bottom:10px;';
    row.innerHTML = `
      <div><label class="label">Destino</label><select class="form-select m-sep-categoria" onchange="App.updateRendaSeparationSummary()">
        <option value="cofrinho" ${catAtual==='cofrinho'||catAtual==='futuro'?'selected':''}>Cofrinho</option>
        <option value="devolucao" ${catAtual==='devolucao'?'selected':''}>Devolução</option>
        <option value="imposto" ${catAtual==='imposto'?'selected':''}>Imposto</option>
        <option value="destinacao" ${catAtual==='destinacao'||catAtual==='oferta'?'selected':''}>Destinação</option>
        <option value="objetivo" ${catAtual==='objetivo'?'selected':''}>Objetivo</option>
      </select></div>
      <div><label class="label">Nome</label><select class="form-select m-sep-nome-select" onchange="App.toggleSepNomeCustom(this);App.updateRendaSeparationSummary()"><option value="">Selecione…</option>${tipos.map(t=>`<option value="${esc(t)}" ${t===nomeAtual?'selected':''}>${esc(t)}</option>`).join('')}<option value="_outro_" ${isOutro?'selected':''}>Outro…</option></select><input class="form-input m-sep-nome-custom mt-8 ${isOutro?'':'hidden'}" placeholder="Ex: Dízimo, Doação, Investimento" value="${esc(isOutro?nomeAtual:'')}" oninput="App.updateRendaSeparationSummary()"></div>
      <div><label class="label">Forma</label><select class="form-select m-sep-tipo" onchange="App.updateRendaSeparationSummary()"><option value="valor" ${data && data.tipo==='percentual'?'':'selected'}>R$</option><option value="percentual" ${data && data.tipo==='percentual'?'selected':''}>%</option></select></div>
      <div><label class="label">Valor</label><input class="form-input m-sep-valor" type="number" min="0" step="0.01" placeholder="0,00" value="${data && data.valor ? esc(data.valor) : ''}" oninput="App.updateRendaSeparationSummary()"></div>
      <button type="button" class="btn btn-danger btn-sm" onclick="this.parentElement.remove();App.updateRendaSeparationSummary()">×</button>`;
    list.appendChild(row);
    this.updateRendaSeparationSummary && this.updateRendaSeparationSummary();
  };

  const collectSeparacoesV19 = () => Array.from(document.querySelectorAll('.m-sep-row')).map((row) => {
    const selVal = row.querySelector('.m-sep-nome-select')?.value || '';
    const nome = selVal === '_outro_' ? (row.querySelector('.m-sep-nome-custom')?.value || '').trim() : selVal;
    const tipo = row.querySelector('.m-sep-tipo')?.value || 'valor';
    const valor = parseFloat(row.querySelector('.m-sep-valor')?.value || 0) || 0;
    const catSel = row.querySelector('.m-sep-categoria')?.value || 'auto';
    if (!nome || valor <= 0) return null;
    return { nome, tipo, valor, categoria: categoriaAutomatica(nome, catSel) };
  }).filter(Boolean);

  App.updateRendaSeparationSummary = function(){
    const bruto = parseFloat(document.getElementById('m-renda-valor')?.value || 0) || 0;
    const seps = collectSeparacoesV19();
    const total = seps.reduce((s, sep) => s + valorSeparacao(sep, bruto), 0);
    const cofre = seps.filter(s => ['cofrinho','futuro'].includes(s.categoria)).reduce((a,s)=>a+valorSeparacao(s, bruto),0);
    const dest = seps.filter(s => ['devolucao','destinacao','oferta','imposto'].includes(s.categoria)).reduce((a,s)=>a+valorSeparacao(s, bruto),0);
    const obj = seps.filter(s => s.categoria === 'objetivo').reduce((a,s)=>a+valorSeparacao(s, bruto),0);
    const totalEl = document.getElementById('m-renda-sep-total');
    const baseEl = document.getElementById('m-renda-base');
    if (totalEl) totalEl.innerHTML = `${Calc.fmt(total)}<div style="font-size:11px;color:var(--grey);font-weight:600;margin-top:3px;">Cofrinho ${Calc.fmt(cofre)} · Destinação ${Calc.fmt(dest)}${obj ? ' · Objetivos '+Calc.fmt(obj) : ''}</div>`;
    if (baseEl) baseEl.textContent = Calc.fmt(Math.max(0, bruto - total));
  };

  App.saveRenda = function(){
    if (!this._beginSubmit('saveRenda')) return;
    const valor = parseFloat(document.getElementById('m-renda-valor')?.value || 0);
    const origemSel = document.getElementById('m-renda-origem')?.value?.trim() || 'Entrada';
    const origemCustom = (document.getElementById('m-renda-origem-custom')?.value || '').trim();
    const origem = origemSel === '_novo_' ? (origemCustom || 'Entrada') : origemSel;
    const data = document.getElementById('m-renda-data')?.value || todayISO();
    const status = document.getElementById('m-renda-status')?.value || 'previsto';
    if (!valor || valor <= 0) { this.toast('Digite o valor'); this._endSubmit && this._endSubmit('saveRenda'); return; }
    const key = keyFromISO(data); this.activeCycleKey = key;
    const separacoes = collectSeparacoesV19();
    if (separacoes.length && this.saveSeparacaoSuggestions) this.saveSeparacaoSuggestions(separacoes.map(s => s.nome));
    const { ciclos, ciclo } = ensureCycle(key);
    ciclo.fontes.push({ id:'e'+Date.now().toString(36)+Math.random().toString(36).slice(2,5), origem, valor, data, status, separacoes });
    recalc(ciclo); Store.set('ciclos', ciclos); if (window.CloudSync) CloudSync.scheduleSync();
    this.closeModal(); this.toast('Entrada salva com separações.'); this.go(this.currentScreen || 'meumes');
  };

  App.updateEntrada = function(){
    if (!this._beginSubmit('updateEntrada')) return;
    const oldKey = document.getElementById('m-edit-key')?.value;
    const idx = parseInt(document.getElementById('m-edit-idx')?.value || '-1', 10);
    const valor = parseFloat(document.getElementById('m-renda-valor')?.value || 0);
    const data = document.getElementById('m-renda-data')?.value || todayISO();
    const status = document.getElementById('m-renda-status')?.value || 'previsto';
    const origemSel = document.getElementById('m-renda-origem')?.value?.trim() || 'Entrada';
    const origemCustom = (document.getElementById('m-renda-origem-custom')?.value || '').trim();
    const origem = origemSel === '_novo_' ? (origemCustom || 'Entrada') : origemSel;
    if (!valor || valor <= 0) { this.toast('Digite o valor'); this._endSubmit && this._endSubmit('updateEntrada'); return; }
    const ciclos = Store.get('ciclos') || {};
    const old = ciclos[oldKey]?.fontes?.[idx];
    if (!old) return this.toast('Entrada não encontrada.');
    ciclos[oldKey].fontes.splice(idx, 1); recalc(ciclos[oldKey]);
    const newKey = keyFromISO(data); this.activeCycleKey = newKey;
    if (!ciclos[newKey]) ciclos[newKey] = { renda:0, gastos:[], decisao:'', fontes:[], separacoes:[] };
    if (!Array.isArray(ciclos[newKey].fontes)) ciclos[newKey].fontes = [];
    const separacoes = collectSeparacoesV19();
    if (separacoes.length && this.saveSeparacaoSuggestions) this.saveSeparacaoSuggestions(separacoes.map(s => s.nome));
    ciclos[newKey].fontes.push({ ...old, origem, valor, data, status, separacoes }); recalc(ciclos[newKey]);
    Store.set('ciclos', ciclos); if (window.CloudSync) CloudSync.scheduleSync();
    this.closeModal(); this.toast('Entrada atualizada.'); this.go(this.currentScreen || 'meumes');
  };
})();


/* V33 REAL — exclusão imediata de entrada
   Remove do Store e, se houver db_id, apaga também do Supabase na hora.
   Não altera status para confirmado.
*/
(function(){
  if (!window.App || !window.Store || !window.Calc) return;
  const recalc = (ciclo) => { ciclo.renda = Calc.rendaNoMes(ciclo); return ciclo; };

  App.confirmDeleteEntrada = async function(key, idx){
    document.getElementById('modal-overlay-confirm')?.remove();
    const ciclos = Store.get('ciclos') || {};
    const ciclo = ciclos[key];
    const fonte = ciclo && Array.isArray(ciclo.fontes) ? ciclo.fontes[idx] : null;
    if (!fonte) { this.toast && this.toast('Entrada não encontrada.'); return; }

    // Apaga primeiro no banco quando o registro já tem ID remoto.
    const dbId = fonte.db_id || fonte.id_banco || fonte.entrada_id;
    let dbOk = true;
    try {
      const client = (typeof supa !== 'undefined' && supa) ? supa : window.supa;
      if (client && dbId) {
        await client.from('separacoes').delete().eq('entrada_id', dbId);
        const resp = await client.from('entradas').delete().eq('id', dbId);
        if (resp && resp.error) throw resp.error;
      }
    } catch(e) {
      console.error('[delete entrada banco]', e);
      dbOk = false;
    }

    ciclo.fontes.splice(idx, 1);
    recalc(ciclo);
    Store.set('ciclos', ciclos);

    // Força push para limpar órfãos quando o item ainda não tinha db_id local.
    try {
      if (window.CloudSync && CloudSync.status === 'connected') {
        if (CloudSync.push) await CloudSync.push();
      }
    } catch(e) { console.error('[push após delete entrada]', e); }

    this.closeModal && this.closeModal();
    this.toast && this.toast(dbOk ? 'Entrada excluída.' : 'Entrada removida da tela; confira a sincronização do banco.');
    this.go && this.go(this.currentScreen || 'meumes');
  };
})();


/* REALTIME_TESTE_01 — operações pontuais para evitar delete-all automático.
   Mantém a UI da V37, mas envia exclusões e gastos fixos diretamente para
   as tabelas novas do meumes-realtime. */
(function(){
  if (!window.App || !window.Store) return;

  const isUuid = (v) => /^[0-9a-f-]{20,}$/i.test(String(v || ''));

  const oldSaveCompromisso = App.saveCompromisso;
  App.saveCompromisso = async function(){
    const before = (Store.get('gastosFixos') || []).map(x => x && (x.db_id || x.id));
    const ret = oldSaveCompromisso ? oldSaveCompromisso.apply(this, arguments) : undefined;
    try {
      const fixos = Store.get('gastosFixos') || [];
      const item = fixos.find(x => !before.includes(x && (x.db_id || x.id))) || fixos[fixos.length - 1];
      if (item && window.CloudSync && CloudSync.upsertGastoFixo && CloudSync.status !== 'disconnected') {
        await CloudSync.upsertGastoFixo(item);
      }
    } catch(e) { console.error('[realtime teste saveCompromisso]', e); this.toast && this.toast('Compromisso salvo na tela; confira a sincronização.'); }
    return ret;
  };

  const oldDeleteCompromisso = App.deleteCompromisso;
  App.deleteCompromisso = async function(idx){
    const fixos = Store.get('gastosFixos') || [];
    const item = fixos[idx];
    const dbId = item && (item.db_id || (isUuid(item.id) ? item.id : null));
    const ret = oldDeleteCompromisso ? oldDeleteCompromisso.apply(this, arguments) : undefined;
    try {
      if (dbId && window.CloudSync && CloudSync.removeGastoFixo && CloudSync.status !== 'disconnected') {
        await CloudSync.removeGastoFixo(dbId);
      }
    } catch(e) { console.error('[realtime teste deleteCompromisso]', e); this.toast && this.toast('Compromisso removido da tela; confira a sincronização.'); }
    return ret;
  };

  const oldConfirmDeleteGasto = App.confirmDeleteGasto;
  App.confirmDeleteGasto = async function(key, idx){
    const ciclos = Store.get('ciclos') || {};
    const g = ciclos[key] && ciclos[key].gastos && ciclos[key].gastos[idx];
    const dbId = g && (g.db_id || (isUuid(g.id) ? g.id : null));
    const ret = oldConfirmDeleteGasto ? oldConfirmDeleteGasto.apply(this, arguments) : undefined;
    try {
      if (dbId && window.CloudSync && CloudSync.removeLancamento && CloudSync.status !== 'disconnected') {
        await CloudSync.removeLancamento(dbId);
      }
    } catch(e) { console.error('[realtime teste deleteGasto]', e); this.toast && this.toast('Lançamento removido da tela; confira a sincronização.'); }
    return ret;
  };

  const oldMarkGastoPago = App.markGastoPago;
  App.markGastoPago = async function(key, idx){
    const ret = oldMarkGastoPago ? oldMarkGastoPago.apply(this, arguments) : undefined;
    try {
      const ciclos = Store.get('ciclos') || {};
      const g = ciclos[key] && ciclos[key].gastos && ciclos[key].gastos[idx];
      if (g && window.CloudSync && CloudSync.upsertLancamento && CloudSync.status !== 'disconnected') {
        await CloudSync.upsertLancamento(key, g);
      }
    } catch(e) { console.error('[realtime teste markGastoPago]', e); }
    return ret;
  };
})();
