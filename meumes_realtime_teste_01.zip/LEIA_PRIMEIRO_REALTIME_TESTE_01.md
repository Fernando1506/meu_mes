# Primeira versão: realtime_teste_01

## Nome da versão

A partir desta entrega, a linha de teste foi renomeada para:

`meumes_realtime_teste_01`

Ela é baseada na V37 enviada, mas começa a migração para o banco novo `meumes-realtime`.

---

## Evidência analisada antes da alteração

Arquivo analisado: `js/05-cloud-sync.js` da V37 enviada.

### Onde o problema estrutural estava

1. `CloudSync.push()` antigo ainda dependia de `workspace_id` e tabelas antigas.
2. O banco novo que você criou usa `user_id`, `mes_referencia` e tabelas separadas.
3. Havia operações de apagar/recriar registros inteiros:
   - entradas órfãs eram deletadas por comparação com o Store local;
   - gastos do ciclo eram apagados antes de reinserir;
   - separações do mês eram apagadas antes de reinserir;
   - gastos fixos eram todos apagados antes de reinserir.

### Trechos responsáveis no código original

No `js/05-cloud-sync.js` original:

```js
await supa.from("recebimentos").delete().eq("workspace_id", wsId);
```

```js
await supa
  .from("gastos")
  .delete()
  .eq("ciclo_id", cicloId)
  .eq("workspace_id", wsId);
```

```js
await supa
  .from("separacoes_mes")
  .delete()
  .eq("ciclo_id", cicloId)
  .eq("workspace_id", wsId);
```

```js
await supa.from("gastos_fixos").delete().eq("workspace_id", wsId);
```

Também havia dependência de tabelas que não existem no schema limpo do `meumes-realtime`:

```js
workspaces
workspace_members
profiles
gastos
separacoes_mes
parcelas
recebimentos
categorias_separacao
```

---

## Causa

A V37 original foi construída para outro modelo de banco: workspace + sincronização em lote.

O banco `meumes-realtime` foi criado com outro modelo:

```text
user_id
mes_referencia
tabelas separadas
Realtime via publication supabase_realtime
```

Por isso, apenas trocar URL/chave do Supabase não bastaria. O app continuaria tentando gravar em colunas e tabelas antigas.

---

## Correção aplicada nesta primeira versão

### 1. `js/05-cloud-sync.js` foi reescrito para o banco novo

Agora usa:

```text
ciclos
entradas
separacoes
lancamentos
gastos_fixos
objetivos
cartoes
faturas
```

E grava usando:

```text
user_id = auth.uid()
mes_referencia = mês do lançamento
```

### 2. Removido `workspace_id` do fluxo principal

A sincronização principal não depende mais de:

```text
workspaces
workspace_members
workspace_id
```

### 3. Removido delete-all automático no push principal

O novo `CloudSync.push()` faz `insert/update` dos registros existentes no Store, mas não apaga tabelas inteiras.

### 4. Criadas operações pontuais

Foram adicionadas funções específicas:

```js
CloudSync.upsertEntrada()
CloudSync.removeEntrada()
CloudSync.upsertLancamento()
CloudSync.removeLancamento()
CloudSync.upsertGastoFixo()
CloudSync.removeGastoFixo()
```

### 5. Ativado listener Realtime no frontend

O app agora assina mudanças nas tabelas:

```text
entradas
gastos_fixos
lancamentos
separacoes
objetivos
cartoes
faturas
```

Quando recebe evento, executa `pull()` e re-renderiza a tela atual.

### 6. Patch em `js/11-app-controller.js`

Foram adicionadas chamadas diretas para exclusões e atualizações críticas:

```text
excluir gasto fixo -> removeGastoFixo()
excluir lançamento -> removeLancamento()
marcar gasto como pago -> upsertLancamento()
```

---

## Importante antes de testar

Você precisa colocar os dados do novo projeto Supabase `meumes-realtime` em:

`js/04-supabase-config.js`

Campos:

```js
const SUPABASE_URL = "COLE_AQUI_A_URL_DO_MEUMES_REALTIME";
const SUPABASE_ANON_KEY = "COLE_AQUI_A_ANON_PUBLIC_KEY";
```

Não use as credenciais do banco antigo nesta versão.

---

## Limitações desta primeira versão

Esta é a primeira base `realtime_teste_01`, não a migração final completa.

Ainda precisam ser revisados depois:

1. Área admin antiga, porque ela ainda referencia `profiles`, `workspaces` e RPCs antigas.
2. Recebimentos, porque o novo SQL inicial ainda não criou uma tabela `recebimentos`.
3. Parcelas, porque o novo SQL inicial ainda não criou uma tabela `parcelas`.
4. Cartões/faturas precisam de validação prática no fluxo real.
5. Gasto fixo preserva campos extras serializando JSON dentro de `descricao`, porque o SQL inicial de `gastos_fixos` ainda não tem coluna `meta_json`.

---

## Testes recomendados

1. Criar usuário teste no Supabase novo.
2. Fazer login.
3. Cadastrar entrada com separações.
4. Atualizar a página e conferir se a entrada volta.
5. Cadastrar gasto fixo.
6. Atualizar a página e conferir se o gasto fixo volta.
7. Cadastrar gasto.
8. Marcar gasto como pago.
9. Excluir gasto.
10. Abrir em duas abas e verificar se uma aba atualiza quando a outra altera algo.
