-- =========================================================
-- MEU MÊS — SETUP COMPLETO DO SUPABASE
-- Execute este arquivo no Supabase: SQL Editor > New query > Run
-- Ele cria as tabelas, índices e políticas RLS usadas pelo app.
-- =========================================================

create extension if not exists "pgcrypto";

-- ---------- Função de atualização updated_at ----------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ---------- Profiles ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text,
  email text,
  is_admin boolean not null default false,
  plano text default 'trial',
  status text default 'trial',
  trial_expires_at timestamptz default (now() + interval '7 days'),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, nome, email, trial_expires_at)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'nome', split_part(new.email, '@', 1)),
    new.email,
    now() + interval '7 days'
  )
  on conflict (id) do update set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- ---------- Workspaces ----------
create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  nome text not null default 'Meu Orçamento',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.workspace_members (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  invited_email text,
  status text not null default 'pending',
  accepted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists workspace_members_user_unique
on public.workspace_members(workspace_id, user_id)
where user_id is not null;

-- Função usada pelas políticas de segurança
create or replace function public.can_access_workspace(p_workspace_id uuid)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.workspaces w
    where w.id = p_workspace_id and w.owner_id = auth.uid()
  )
  or exists (
    select 1 from public.workspace_members wm
    where wm.workspace_id = p_workspace_id
      and wm.user_id = auth.uid()
      and wm.status = 'active'
  );
$$;

-- ---------- Tabelas do app ----------
create table if not exists public.categorias_separacao (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  nome text not null,
  categoria text not null default 'futuro',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (workspace_id, nome)
);

create table if not exists public.recebimentos (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  nome text not null,
  tipo text not null default 'fixo',
  dia integer,
  valor_estimado numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ciclos (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  mes text not null,
  decisao text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (workspace_id, mes)
);

create table if not exists public.entradas (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  ciclo_id uuid not null references public.ciclos(id) on delete cascade,
  origem text not null default 'Entrada',
  valor numeric(12,2) not null default 0,
  data date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.separacoes (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  entrada_id uuid not null references public.entradas(id) on delete cascade,
  nome text not null,
  categoria text not null default 'futuro',
  tipo text not null default 'valor',
  valor numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.gastos (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  ciclo_id uuid not null references public.ciclos(id) on delete cascade,
  descricao text not null default 'Gasto',
  valor numeric(12,2) not null default 0,
  data date,
  categoria text default 'V',
  tipo text default 'variavel',
  pago boolean not null default false,
  extra_json jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.separacoes_mes (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  ciclo_id uuid not null references public.ciclos(id) on delete cascade,
  nome text not null,
  categoria text not null default 'futuro',
  valor numeric(12,2) not null default 0,
  data date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.gastos_fixos (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid references public.workspaces(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  descricao text not null,
  valor numeric(12,2) not null default 0,
  categoria text default 'E',
  tipo text default 'essencial',
  ativo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.objetivos (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  nome text not null,
  valor_meta numeric(12,2) not null default 0,
  valor_atual numeric(12,2) not null default 0,
  prazo date,
  prioridade text default 'media',
  concluido boolean not null default false,
  ordem integer default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.parcelas (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  nome text,
  descricao text,
  subcategoria text,
  dia_vencimento integer default 1,
  valor_parcela numeric(12,2) not null default 0,
  data_inicio date,
  data_fim date,
  mes_inicio text,
  origem text default 'separado',
  cartao_id uuid,
  skip_months jsonb default '[]'::jsonb,
  quitada boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.cartoes (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  nome text not null,
  bandeira text,
  limite numeric(12,2) default 0,
  fatura_atual numeric(12,2) default 0,
  dia_fechamento integer default 1,
  dia_vencimento integer default 10,
  fatura_vencimento_data date,
  fatura_vencimento_valor numeric(12,2) default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);



-- =========================================================
-- MIGRAÇÃO SEGURA PARA BANCOS QUE JÁ TINHAM TABELAS ANTIGAS
-- Motivo: CREATE TABLE IF NOT EXISTS não adiciona colunas novas.
-- Este bloco adiciona colunas ausentes antes de criar políticas RLS.
-- =========================================================

alter table public.profiles add column if not exists nome text;
alter table public.profiles add column if not exists email text;
alter table public.profiles add column if not exists is_admin boolean not null default false;
alter table public.profiles add column if not exists plano text default 'trial';
alter table public.profiles add column if not exists status text default 'trial';
alter table public.profiles add column if not exists trial_expires_at timestamptz default (now() + interval '7 days');
alter table public.profiles add column if not exists created_at timestamptz not null default now();
alter table public.profiles add column if not exists updated_at timestamptz not null default now();

alter table public.workspaces add column if not exists owner_id uuid references auth.users(id) on delete cascade;
alter table public.workspaces add column if not exists nome text default 'Meu Orçamento';
alter table public.workspaces add column if not exists created_at timestamptz not null default now();
alter table public.workspaces add column if not exists updated_at timestamptz not null default now();

alter table public.workspace_members add column if not exists workspace_id uuid references public.workspaces(id) on delete cascade;
alter table public.workspace_members add column if not exists user_id uuid references auth.users(id) on delete cascade;
alter table public.workspace_members add column if not exists invited_email text;
alter table public.workspace_members add column if not exists status text not null default 'pending';
alter table public.workspace_members add column if not exists accepted_at timestamptz;
alter table public.workspace_members add column if not exists created_at timestamptz not null default now();
alter table public.workspace_members add column if not exists updated_at timestamptz not null default now();

alter table public.categorias_separacao add column if not exists workspace_id uuid references public.workspaces(id) on delete cascade;
alter table public.categorias_separacao add column if not exists nome text;
alter table public.categorias_separacao add column if not exists categoria text default 'futuro';
alter table public.categorias_separacao add column if not exists created_at timestamptz not null default now();
alter table public.categorias_separacao add column if not exists updated_at timestamptz not null default now();

alter table public.recebimentos add column if not exists workspace_id uuid references public.workspaces(id) on delete cascade;
alter table public.recebimentos add column if not exists nome text;
alter table public.recebimentos add column if not exists tipo text default 'fixo';
alter table public.recebimentos add column if not exists dia integer;
alter table public.recebimentos add column if not exists valor_estimado numeric(12,2) not null default 0;
alter table public.recebimentos add column if not exists created_at timestamptz not null default now();
alter table public.recebimentos add column if not exists updated_at timestamptz not null default now();

alter table public.ciclos add column if not exists workspace_id uuid references public.workspaces(id) on delete cascade;
alter table public.ciclos add column if not exists mes text;
alter table public.ciclos add column if not exists decisao text default '';
alter table public.ciclos add column if not exists created_at timestamptz not null default now();
alter table public.ciclos add column if not exists updated_at timestamptz not null default now();

alter table public.entradas add column if not exists workspace_id uuid references public.workspaces(id) on delete cascade;
alter table public.entradas add column if not exists ciclo_id uuid references public.ciclos(id) on delete cascade;
alter table public.entradas add column if not exists origem text default 'Entrada';
alter table public.entradas add column if not exists valor numeric(12,2) not null default 0;
alter table public.entradas add column if not exists data date;
alter table public.entradas add column if not exists created_at timestamptz not null default now();
alter table public.entradas add column if not exists updated_at timestamptz not null default now();

alter table public.separacoes add column if not exists workspace_id uuid references public.workspaces(id) on delete cascade;
alter table public.separacoes add column if not exists entrada_id uuid references public.entradas(id) on delete cascade;
alter table public.separacoes add column if not exists nome text;
alter table public.separacoes add column if not exists categoria text default 'futuro';
alter table public.separacoes add column if not exists tipo text default 'valor';
alter table public.separacoes add column if not exists valor numeric(12,2) not null default 0;
alter table public.separacoes add column if not exists created_at timestamptz not null default now();
alter table public.separacoes add column if not exists updated_at timestamptz not null default now();

alter table public.gastos add column if not exists workspace_id uuid references public.workspaces(id) on delete cascade;
alter table public.gastos add column if not exists ciclo_id uuid references public.ciclos(id) on delete cascade;
alter table public.gastos add column if not exists descricao text default 'Gasto';
alter table public.gastos add column if not exists valor numeric(12,2) not null default 0;
alter table public.gastos add column if not exists data date;
alter table public.gastos add column if not exists categoria text default 'V';
alter table public.gastos add column if not exists tipo text default 'variavel';
alter table public.gastos add column if not exists pago boolean not null default false;
alter table public.gastos add column if not exists extra_json jsonb;
alter table public.gastos add column if not exists created_at timestamptz not null default now();
alter table public.gastos add column if not exists updated_at timestamptz not null default now();

alter table public.separacoes_mes add column if not exists workspace_id uuid references public.workspaces(id) on delete cascade;
alter table public.separacoes_mes add column if not exists ciclo_id uuid references public.ciclos(id) on delete cascade;
alter table public.separacoes_mes add column if not exists nome text;
alter table public.separacoes_mes add column if not exists categoria text default 'futuro';
alter table public.separacoes_mes add column if not exists valor numeric(12,2) not null default 0;
alter table public.separacoes_mes add column if not exists data date;
alter table public.separacoes_mes add column if not exists created_at timestamptz not null default now();
alter table public.separacoes_mes add column if not exists updated_at timestamptz not null default now();

alter table public.gastos_fixos add column if not exists workspace_id uuid references public.workspaces(id) on delete cascade;
alter table public.gastos_fixos add column if not exists user_id uuid references auth.users(id) on delete cascade;
alter table public.gastos_fixos add column if not exists descricao text;
alter table public.gastos_fixos add column if not exists valor numeric(12,2) not null default 0;
alter table public.gastos_fixos add column if not exists categoria text default 'E';
alter table public.gastos_fixos add column if not exists tipo text default 'essencial';
alter table public.gastos_fixos add column if not exists ativo boolean not null default true;
alter table public.gastos_fixos add column if not exists created_at timestamptz not null default now();
alter table public.gastos_fixos add column if not exists updated_at timestamptz not null default now();

alter table public.objetivos add column if not exists workspace_id uuid references public.workspaces(id) on delete cascade;
alter table public.objetivos add column if not exists nome text;
alter table public.objetivos add column if not exists valor_meta numeric(12,2) not null default 0;
alter table public.objetivos add column if not exists valor_atual numeric(12,2) not null default 0;
alter table public.objetivos add column if not exists prazo date;
alter table public.objetivos add column if not exists prioridade text default 'media';
alter table public.objetivos add column if not exists concluido boolean not null default false;
alter table public.objetivos add column if not exists ordem integer default 0;
alter table public.objetivos add column if not exists created_at timestamptz not null default now();
alter table public.objetivos add column if not exists updated_at timestamptz not null default now();

alter table public.parcelas add column if not exists workspace_id uuid references public.workspaces(id) on delete cascade;
alter table public.parcelas add column if not exists nome text;
alter table public.parcelas add column if not exists descricao text;
alter table public.parcelas add column if not exists subcategoria text;
alter table public.parcelas add column if not exists dia_vencimento integer default 1;
alter table public.parcelas add column if not exists valor_parcela numeric(12,2) not null default 0;
alter table public.parcelas add column if not exists data_inicio date;
alter table public.parcelas add column if not exists data_fim date;
alter table public.parcelas add column if not exists mes_inicio text;
alter table public.parcelas add column if not exists origem text default 'separado';
alter table public.parcelas add column if not exists cartao_id uuid;
alter table public.parcelas add column if not exists skip_months jsonb default '[]'::jsonb;
alter table public.parcelas add column if not exists quitada boolean not null default false;
alter table public.parcelas add column if not exists created_at timestamptz not null default now();
alter table public.parcelas add column if not exists updated_at timestamptz not null default now();

alter table public.cartoes add column if not exists workspace_id uuid references public.workspaces(id) on delete cascade;
alter table public.cartoes add column if not exists nome text;
alter table public.cartoes add column if not exists bandeira text;
alter table public.cartoes add column if not exists limite numeric(12,2) default 0;
alter table public.cartoes add column if not exists fatura_atual numeric(12,2) default 0;
alter table public.cartoes add column if not exists dia_fechamento integer default 1;
alter table public.cartoes add column if not exists dia_vencimento integer default 10;
alter table public.cartoes add column if not exists fatura_vencimento_data date;
alter table public.cartoes add column if not exists fatura_vencimento_valor numeric(12,2) default 0;
alter table public.cartoes add column if not exists created_at timestamptz not null default now();
alter table public.cartoes add column if not exists updated_at timestamptz not null default now();

-- ---------- Triggers updated_at ----------
do $$
declare t text;
begin
  foreach t in array array[
    'profiles','workspaces','workspace_members','categorias_separacao','recebimentos','ciclos',
    'entradas','separacoes','gastos','separacoes_mes','gastos_fixos','objetivos','parcelas','cartoes'
  ] loop
    execute format('drop trigger if exists trg_%I_updated_at on public.%I', t, t);
    execute format('create trigger trg_%I_updated_at before update on public.%I for each row execute function public.set_updated_at()', t, t);
  end loop;
end $$;

-- ---------- RLS ----------
alter table public.profiles enable row level security;
alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.categorias_separacao enable row level security;
alter table public.recebimentos enable row level security;
alter table public.ciclos enable row level security;
alter table public.entradas enable row level security;
alter table public.separacoes enable row level security;
alter table public.gastos enable row level security;
alter table public.separacoes_mes enable row level security;
alter table public.gastos_fixos enable row level security;
alter table public.objetivos enable row level security;
alter table public.parcelas enable row level security;
alter table public.cartoes enable row level security;

-- Remove políticas antigas com nomes conhecidos, se existirem
do $$
declare r record;
begin
  for r in select schemaname, tablename, policyname from pg_policies where schemaname = 'public' loop
    execute format('drop policy if exists %I on %I.%I', r.policyname, r.schemaname, r.tablename);
  end loop;
end $$;

create policy profiles_select on public.profiles for select using (id = auth.uid());
create policy profiles_insert on public.profiles for insert with check (id = auth.uid());
create policy profiles_update on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

create policy workspaces_select on public.workspaces for select using (owner_id = auth.uid() or public.can_access_workspace(id));
create policy workspaces_insert on public.workspaces for insert with check (owner_id = auth.uid());
create policy workspaces_update on public.workspaces for update using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy workspaces_delete on public.workspaces for delete using (owner_id = auth.uid());

create policy members_select on public.workspace_members for select using (
  user_id = auth.uid()
  or lower(invited_email) = lower(auth.email())
  or exists (select 1 from public.workspaces w where w.id = workspace_id and w.owner_id = auth.uid())
);
create policy members_insert on public.workspace_members for insert with check (
  exists (select 1 from public.workspaces w where w.id = workspace_id and w.owner_id = auth.uid())
);
create policy members_update on public.workspace_members for update using (
  user_id = auth.uid()
  or lower(invited_email) = lower(auth.email())
  or exists (select 1 from public.workspaces w where w.id = workspace_id and w.owner_id = auth.uid())
) with check (true);
create policy members_delete on public.workspace_members for delete using (
  exists (select 1 from public.workspaces w where w.id = workspace_id and w.owner_id = auth.uid())
);

-- Políticas padrão para tabelas por workspace
create policy categorias_sep_all on public.categorias_separacao for all using (public.can_access_workspace(workspace_id)) with check (public.can_access_workspace(workspace_id));
create policy recebimentos_all on public.recebimentos for all using (public.can_access_workspace(workspace_id)) with check (public.can_access_workspace(workspace_id));
create policy ciclos_all on public.ciclos for all using (public.can_access_workspace(workspace_id)) with check (public.can_access_workspace(workspace_id));
create policy entradas_all on public.entradas for all using (public.can_access_workspace(workspace_id)) with check (public.can_access_workspace(workspace_id));
create policy separacoes_all on public.separacoes for all using (public.can_access_workspace(workspace_id)) with check (public.can_access_workspace(workspace_id));
create policy gastos_all on public.gastos for all using (public.can_access_workspace(workspace_id)) with check (public.can_access_workspace(workspace_id));
create policy separacoes_mes_all on public.separacoes_mes for all using (public.can_access_workspace(workspace_id)) with check (public.can_access_workspace(workspace_id));
create policy gastos_fixos_all on public.gastos_fixos for all using (public.can_access_workspace(workspace_id) or user_id = auth.uid()) with check (public.can_access_workspace(workspace_id) or user_id = auth.uid());
create policy objetivos_all on public.objetivos for all using (public.can_access_workspace(workspace_id)) with check (public.can_access_workspace(workspace_id));
create policy parcelas_all on public.parcelas for all using (public.can_access_workspace(workspace_id)) with check (public.can_access_workspace(workspace_id));
create policy cartoes_all on public.cartoes for all using (public.can_access_workspace(workspace_id)) with check (public.can_access_workspace(workspace_id));

-- Índices úteis
create index if not exists idx_ciclos_workspace on public.ciclos(workspace_id);
create index if not exists idx_entradas_ciclo on public.entradas(ciclo_id);
create index if not exists idx_gastos_ciclo on public.gastos(ciclo_id);
create index if not exists idx_sep_mes_ciclo on public.separacoes_mes(ciclo_id);
create index if not exists idx_cartoes_workspace on public.cartoes(workspace_id);

-- Verificação rápida: deve retornar linhas das tabelas criadas
select table_name
from information_schema.tables
where table_schema = 'public'
  and table_name in ('profiles','workspaces','workspace_members','ciclos','entradas','gastos','cartoes','recebimentos')
order by table_name;

-- =====================================================
-- V14 - CAMPOS DE STATUS / PREVISÃO
-- Execute este bloco se o seu banco já existe.
-- Ele não apaga dados; apenas adiciona colunas usadas pela V14.
-- =====================================================

ALTER TABLE public.recebimentos
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'previsto';

ALTER TABLE public.entradas
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'previsto';

ALTER TABLE public.gastos
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'previsto';

ALTER TABLE public.cartoes
  ADD COLUMN IF NOT EXISTS fatura_status text DEFAULT 'aberta';

-- Mantém registros antigos utilizáveis na previsão.
UPDATE public.recebimentos SET status = 'previsto' WHERE status IS NULL;
UPDATE public.entradas SET status = 'confirmado' WHERE status IS NULL;
UPDATE public.gastos SET status = CASE WHEN pago IS TRUE THEN 'pago' ELSE 'previsto' END WHERE status IS NULL;
UPDATE public.cartoes SET fatura_status = 'aberta' WHERE fatura_status IS NULL;
